Run
./compile prettyPictures
To compile.

You may have to install libsdl-dev, sdl etc.

argv1 is for the whole background a random colour (1), or each pixel a random colour (0)
argv2 is for random(0) or truely random colour change(1) [of course this is not _really_ random]
argv3 is for whether the colour changes once it's hit the same colour or once it's hit a different one
