/*****************************************************************************
 * Copyright (C) 2013 J05HYYY
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
 *****************************************************************************/

#include "SDL/SDL.h"
#include <math.h>

int reds, blues, greens, redBlues, redGreens, blueGreens, whites, blacks;

void drawPixel(SDL_Surface *surface, Uint32 pixel, int x, int y)
{
if (x >= 480 || y >= 480 || x < 0 || y < 0) return;
    int bpp = surface->format->BytesPerPixel;
    /* Here p is the address to the pixel we want to set */
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

    switch(bpp) {
    case 1:
        *p = pixel;
        break;

    case 2:
        *(Uint16 *)p = pixel;
        break;

    case 3:
        if(SDL_BYTEORDER == SDL_BIG_ENDIAN) {
            p[0] = (pixel >> 16) & 0xff;
            p[1] = (pixel >> 8) & 0xff;
            p[2] = pixel & 0xff;
        } else {
            p[0] = pixel & 0xff;
            p[1] = (pixel >> 8) & 0xff;
            p[2] = (pixel >> 16) & 0xff;
        }
        break;

    case 4:
        *(Uint32 *)p = pixel;
        break;
    }
}

Uint32 getPixel(SDL_Surface *surface, int x, int y)
{
    int bpp = surface->format->BytesPerPixel;
    /* Here p is the address to the pixel we want to retrieve */
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

    switch(bpp) {
    case 1:
        return *p;
        break;

    case 2:
        return *(Uint16 *)p;
        break;

    case 3:
        if(SDL_BYTEORDER == SDL_BIG_ENDIAN)
            return p[0] << 16 | p[1] << 8 | p[2];
        else
            return p[0] | p[1] << 8 | p[2] << 16;
        break;

    case 4:
        return *(Uint32 *)p;
        break;

    default:
        return 0;       /* shouldn't happen, but avoids warnings */
    }
}

drawWidth(SDL_Surface *surface, Uint32 pixel, int x, int y, int startPointX, int startPointY, int endPointX, int endPointY, int steps, int step){

int width;

	if (step > steps/2)
	{
		width=10-(int)10/((float)steps/step);
	}
	else if (step < steps/2)
	{
		if (step == 0)
		width = 1;
		else
		width=10-(int)10/((float)steps/(steps-step));
	}
	else
	{
		width=10;
	}

width += 5;

	int index;
	for ( index = 0; index < width; ++index)
	{
		drawPixel(surface, pixel, x+index, y);
		drawPixel(surface, pixel, x-index, y);
		drawPixel(surface, pixel, x, y+index);
		drawPixel(surface, pixel, x, y-index);
	}
}

Uint32 drawArc(SDL_Surface *screen, Uint32 *color, double centreX, double centreY, int x1, int y1, int x2, int y2, double **oldValsX, double **oldValsY, int *oldValsSize, short *quitProgram, short *collision, Uint32 *seed, short semiRandom, short life){

SDL_Event event;

double radius = sqrt(pow((double)x2-centreX,2) + pow((double)y2-centreY,2));
double *lastX = malloc(sizeof(double));
double *lastY = malloc(sizeof(double));
int lastSize = 0;
double pixX=x1;
double pixY=y1;
double velocity = 1;
int ticks = velocity;

while ( !(pixX == x2 && pixY == y2) )
{

	if( SDL_PollEvent( &event ) && event.type == SDL_QUIT ) *quitProgram = 1;

SDL_Delay(1);

	
		double best = 9999999999;
		double test = 0;
		int number = 0;

if (pixX < x2 || pixY < y2)
{
		test=sqrt(pow(radius - sqrt(pow((pixX + 1)-centreX,2)+pow((pixY + 1)-centreY,2)),2));
		if (test < best)
		{
			short use = 1;
			int index;
			for (index = 0; index < lastSize; ++index)
			{
				if (lastX[index] == pixX + 1 && lastY[index] == pixY + 1)
				{
					use = -1;
					break;
				}
			}

			if (use == 1)
			{
				best = test;
				number = 1;
			}
		}
}

if (pixX < x2 || pixY > y2)
{
		test=sqrt(pow(radius - sqrt(pow((pixX + 1)-centreX,2)+pow((pixY - 1)-centreY,2)),2));
		if (test < best)
		{
			short use = 1;
			int index;
			for (index = 0; index < lastSize; ++index)
			{
				if (lastX[index] == pixX + 1 && lastY[index] == pixY - 1)
				{
					use = -1;
					break;
				}
			}

			if (use == 1)
			{
				best = test;
				number = 2;
			}
		}
}

if (pixX > x2 || pixY < y2)
{
		test=sqrt(pow(radius - sqrt(pow((pixX - 1)-centreX,2)+pow((pixY + 1)-centreY,2)),2));
		if (test < best)
		{
			short use = 1;
			int index;
			for (index = 0; index < lastSize; ++index)
			{
				if (lastX[index] == pixX - 1 && lastY[index] == pixY + 1)
				{
					use = -1;
					break;
				}
			}

			if (use == 1)
			{
				best = test;
				number = 3;
			}
		}
}

if (pixX > x2 || pixY > y2)
{
		test=sqrt(pow(radius - sqrt(pow((pixX - 1)-centreX,2)+pow((pixY - 1)-centreY,2)),2));
		if (test < best)
		{
			short use = 1;
			int index;
			for (index = 0; index < lastSize; ++index)
			{
				if (lastX[index] == pixX - 1 && lastY[index] == pixY - 1)
				{
					use = -1;
					break;
				}
			}

			if (use == 1)
			{
				best = test;
				number = 4;
			}
		}
}

if (pixX < x2)
{
		test=sqrt(pow(radius - sqrt(pow((pixX + 1)-centreX,2)+pow(pixY-centreY,2)),2));
		if (test < best)
		{
			short use = 1;
			int index;
			for (index = 0; index < lastSize; ++index)
			{
				if (lastX[index] == pixX + 1 && lastY[index] == pixY)
				{
					use = -1;
					break;
				}
			}

			if (use == 1)
			{
				best = test;
				number = 5;
			}
		}
}

if (pixX > x2)
{
		test=sqrt(pow(radius - sqrt(pow((pixX - 1)-centreX,2)+pow(pixY-centreY,2)),2));
		if (test < best)
		{
			short use = 1;
			int index;
			for (index = 0; index < lastSize; ++index)
			{
				if (lastX[index] == pixX - 1 && lastY[index] == pixY)
				{
					use = -1;
					break;
				}
			}

			if (use == 1)
			{
				best = test;
				number = 6;
			}
		}
}

if (pixY < y2)
{
		test=sqrt(pow(radius - sqrt(pow(pixX-centreX,2)+pow((pixY + 1)-centreY,2)),2));
		if (test < best)
		{
			short use = 1;
			int index;
			for (index = 0; index < lastSize; ++index)
			{
				if (lastX[index] == pixX && lastY[index] == pixY + 1)
				{
					use = -1;
					break;
				}
			}

			if (use == 1)
			{
				best = test;
				number = 7;
			}
		}
}

if (pixY > y2)
{
		test=sqrt(pow(radius - sqrt(pow(pixX-centreX,2)+pow((pixY - 1)-centreY,2)),2));
		if (test < best)
		{
			short use = 1;
			int index;
			for (index = 0; index < lastSize; ++index)
			{
				if (lastX[index] == pixX && lastY[index] == pixY - 1)
				{
					use = -1;
					break;
				}
			}

			if (use == 1)
			number = 8;
		}
}

		switch(number){
			case 1:
				pixX=pixX+1;
				pixY=pixY+1;
			break;
			case 2:
				pixX=pixX+1;
				pixY=pixY-1;
			break;
			case 3:
				pixX=pixX-1;
				pixY=pixY+1;
			break;
			case 4:
				pixX=pixX-1;
				pixY=pixY-1;
			break;
			case 5:
				pixX=pixX+1;
				pixY=pixY;
			break;
			case 6:

				pixX=pixX-1;
				pixY=pixY;
			break;
			case 7:
				pixX=pixX;
				pixY=pixY+1;
			break;
			case 8:
				pixX=pixX;
				pixY=pixY-1;
			break;
		}

		lastX = realloc(lastX, sizeof(double) * (lastSize + 1));
		lastX[lastSize] = pixX;
		lastY = realloc(lastY, sizeof(double) * (lastSize + 1));
		lastY[lastSize] = pixY;

		++lastSize;

		if (pixX < 480 && pixX > 0 && pixY < 480 && pixY > 0)
		{

			Uint8 currentRed;
			Uint8 currentGreen;
			Uint8 currentBlue;

			SDL_GetRGB(*color, screen->format, &currentRed, &currentGreen, &currentBlue);

			Uint32 gotColor = getPixel(screen, (int)pixX, (int)pixY);

			Uint8 gotRed;
			Uint8 gotGreen;
			Uint8 gotBlue;

			SDL_GetRGB(gotColor, screen->format, &gotRed, &gotGreen, &gotBlue);

			short match = 0;
			Uint8 switchRed = 3;
			Uint8 switchGreen = 3;
			Uint8 switchBlue = 3;

if (life == 1)
{
			if (gotRed <= 127 && currentRed > 127)
			{
				switchRed = 1;
				++match;
			}
			else if (gotRed > 127 && currentRed <= 127)
			{
				switchRed = 2;
				++match;
			}

			if (gotGreen <= 127 && currentGreen > 127)
			{
				switchGreen = 1;
				++match;
			}
			else if (gotGreen > 127 && currentGreen <= 127)
			{
				switchGreen = 2;
				++match;
			}

			if (gotBlue <= 127 && currentBlue > 127)
			{
				switchBlue = 1;
				++match;
			}
			else if (gotBlue > 127 && currentBlue <= 127)
			{
				switchBlue = 2;
				++match;
			}

}
else
{
			if (gotRed <= 127 && currentRed <= 127)
			{
				switchRed = 1;
				++match;
			}
			else if (gotRed > 127 && currentRed > 127)
			{
				switchRed = 2;
				++match;
			}

			if (gotGreen <= 127 && currentGreen <= 127)
			{
				switchGreen = 1;
				++match;
			}
			else if (gotGreen > 127 && currentGreen > 127)
			{
				switchGreen = 2;
				++match;
			}

			if (gotBlue <= 127 && currentBlue <= 127)
			{
				switchBlue = 1;
				++match;
			}
			else if (gotBlue > 127 && currentBlue > 127)
			{
				switchBlue = 2;
				++match;
			}
}

			if (match == 3 && *collision == 0)
			{
				srand(*seed);
/* to make sure the random seed is iterated */
*seed = rand() % 2147483647 + (rand() % 1);


if (semiRandom == 1)
{
				short which = rand() % 6;

				srand(*seed);
				/* to make sure the random seed is iterated */
				*seed = rand() % 2147483647 + (rand() % 1);

				short randInverse = rand() % 3;

				switch(which)
				{
					case 0:
							if (switchRed == 1) switchRed = 255;
							else if ( switchRed == 2 ) switchRed = 0;

							if (switchGreen == 1) switchGreen = 255;
							else if (switchGreen == 2 ) switchGreen = 0;

							if (switchBlue == 1) switchBlue = 255;
							else if (switchBlue == 2 ) switchBlue = 0;
					break;

					case 1:
					case 2:
						if (randInverse == 0)
						{
							/*inverse red and green*/
							if ( switchRed == 1) switchRed = 255;
							else if ( switchRed == 2 ) switchRed = 0;

							if (switchGreen == 1) switchGreen = 255;
							else if ( switchGreen == 2 ) switchGreen = 0;
						}
						else if (randInverse == 1)
						{
							/*inverse red and blue*/
							if (switchRed == 1) switchRed = 255;
							else if (switchRed == 2 ) switchRed = 0;

							if (switchBlue == 1) switchBlue = 255;
							else if (switchBlue == 2 ) switchBlue = 0;
						}
						else
						{
							/*inverse green and blue*/
							if (switchGreen == 1) switchGreen = 255;
							else if ( switchGreen == 2 ) switchGreen = 0;

							if (switchBlue == 1) switchBlue = 255;
							else if (switchBlue == 2 ) switchBlue = 0;
						}
					break;
					break;

					case 3:
					case 4:
					case 5:
						if (randInverse == 0)
						{
							/*inverse red*/
							if (switchRed == 1) switchRed = 255;
							else if (switchRed == 2 ) switchRed = 0;
						}
	
					else if (randInverse == 1)
						{
							/*inverse green*/
							if (switchGreen == 1) switchGreen = 255;
							else if (switchGreen == 2 ) switchGreen = 0;
						}
						else
						{
							/*inverse blue*/
							if (switchBlue == 1) switchBlue = 255;
							else if (switchBlue == 2 ) switchBlue = 0;
						}
					break;
					break;
					break;
					default:
					break;
				}

}
else
{ /*semirandom == 0;*/
short which = rand() % 7;
				switch(which)
				{
					case 0:
							if (switchRed == 1) switchRed = 255;
							else if (switchRed == 2 ) switchRed = 0;

							if (switchGreen == 1) switchGreen = 255;
							else if (switchGreen == 2 ) switchGreen = 0;

							if (switchBlue == 1) switchBlue = 255;
							else if (switchBlue == 2 ) switchBlue = 0;
					break;
					case 1:
							if (switchRed == 1) switchRed = 255;
							else if ( switchRed == 2 ) switchRed = 0;
					break;
					case 2:
							if (switchGreen == 1) switchGreen = 255;
							else if (switchGreen == 2 ) switchGreen = 0;
					break;
					case 3:
							if (switchBlue == 1) switchBlue = 255;
							else if (switchBlue == 2 ) switchBlue = 0;
					break;
					case 4:
							if (switchRed == 1) switchRed = 255;
							else if (switchRed == 2 ) switchRed = 0;

							if (switchGreen == 1) switchGreen = 255;
							else if ( switchGreen == 2 ) switchGreen = 0;
					break;
					case 5:
							if (switchGreen == 1) switchGreen = 255;
							else if (switchGreen == 2 ) switchGreen = 0;

							if (switchBlue == 1) switchBlue = 255;
							else if (switchBlue == 2 ) switchBlue = 0;
					break;
					case 6:
							if (switchRed == 1) switchRed = 255;
							else if (switchRed == 2 ) switchRed = 0;

							if (switchBlue == 1) switchBlue = 255;
							else if (switchBlue == 2 ) switchBlue = 0;
					break;
				}
}

				double stepRed, stepGreen, stepBlue;

					if (switchRed == 3 )
					{
						stepRed = 0;
						switchRed = currentRed;
					}
					else
					stepRed = (double)(switchRed - currentRed) / *oldValsSize;
					
					if (switchGreen == 3 )
					{
						stepGreen = 0;
						switchGreen = currentGreen;
					}
					else
					stepGreen = (double)(switchGreen - currentGreen) / *oldValsSize;

					if (switchBlue == 3 )
					{
						stepBlue = 0;
						switchBlue = currentBlue;
					}
					else
					stepBlue = (double)(switchBlue - currentBlue) / *oldValsSize;

				int index;

printf("%d %d %d\n",switchRed,switchGreen,switchBlue);

				for (index = 0; index < *oldValsSize; ++index)
				{
					if ((int)(*oldValsX)[index] > 0 && (int)(*oldValsY)[index] > 0 && (int)(*oldValsX)[index] < 480 && (int)(*oldValsY)[index] < 480)
						drawWidth(screen,SDL_MapRGB(screen->format, (Uint8)(currentRed + ((double)stepRed * index)), (Uint8)(currentGreen + ((double)stepGreen * index)),(Uint8)(currentBlue + ((double)stepBlue * index))), (int)(*oldValsX)[index], (int)(*oldValsY)[index], (int)(*oldValsX)[0], (int)(*oldValsY)[0], (int)(*oldValsX)[*oldValsSize-1], (int)(*oldValsY)[*oldValsSize-1], *oldValsSize, index);

				}

				*color = SDL_MapRGB(screen->format, switchRed, switchGreen, switchBlue);


if (switchRed == 255 && switchBlue == 0 && switchGreen == 0) ++reds;
else if (switchBlue == 255 && switchRed == 0 && switchGreen == 0) ++blues;
else if (switchGreen == 255 && switchBlue == 0 && switchRed == 0) ++greens;
else if (switchRed == 255 && switchBlue == 255 && switchGreen == 0) ++redBlues;
else if (switchRed == 255 && switchBlue == 0 && switchGreen == 255) ++redGreens;
else if (switchRed == 0 && switchBlue == 255 && switchGreen == 255) ++blueGreens;
else if (switchRed == 255 && switchBlue == 255 && switchGreen == 255) ++whites;
else ++blacks;

				free(*oldValsX);
				free(*oldValsY);

				*oldValsSize = 0;

				*oldValsX = malloc(sizeof(double));
				*oldValsY = malloc(sizeof(double));

				*collision = 1;
			}
			else if ( match != 3 )
			{
				*collision = 0;
			}

				*oldValsX = realloc(*oldValsX, (*oldValsSize + 1) * sizeof(double));
				*oldValsY = realloc(*oldValsY, (*oldValsSize + 1) * sizeof(double));
				(*oldValsX)[*oldValsSize] = pixX;
				(*oldValsY)[*oldValsSize] = pixY;
				++*oldValsSize;

			drawPixel(screen, *color, (int)pixX, (int)pixY);

			SDL_Flip(screen);
			ticks = (int)velocity;
		}
		else ticks = 0;

	}

free(lastX);
free(lastY);
}


int main( int argc, char* argv[] )
{

if ( argc != 4 ){
printf("argv1 is for the whole background a random colour (1), or each pixel a random colour (0)\n argv2 is for random(0) or truely random colour change(1) [of course this is not _really_ random]\nargv3 is for whether the colour changes once it's hit the same colour or once it's hit a different one");
return -1;
}

    /* Start SDL */
    SDL_Init( SDL_INIT_EVERYTHING );

    /* Set up screen */
    SDL_Surface *screen = SDL_SetVideoMode( 480, 480, 32, SDL_SWSURFACE );

	SDL_WM_SetCaption("Pretty", "Pretty");

short startColor;

Uint32 color;

const Uint32 ticks = SDL_GetTicks();
	srand(ticks);

	Uint32 seed = rand() % 2147483647 + (rand() % 1);

	int iterateX, iterateY;

if (argv[1][0] == '1')
{
	for (iterateX = 0; iterateX < 480; ++iterateX)
	for (iterateY = 0; iterateY < 480; ++iterateY)
	{

		startColor = rand() % 8;

		switch(startColor){

			case 0:
				color = SDL_MapRGB(screen->format, 255, 255, 255);
			break;
			case 1:
				color = SDL_MapRGB(screen->format, 255, 255, 0);
			break;
			case 2:
				color = SDL_MapRGB(screen->format, 255, 0, 255);
			break;
			case 3:
				color = SDL_MapRGB(screen->format, 255, 0, 0);
			break;
			case 4:
				color = SDL_MapRGB(screen->format, 0, 255, 255);
			break;
			case 5:
				color = SDL_MapRGB(screen->format, 0, 0, 255);
			break;
			case 6:
				color = SDL_MapRGB(screen->format, 0, 0, 0);
			break;
			case 7:
				color = SDL_MapRGB(screen->format, 0, 255, 0);
			break;
		}
		drawPixel(screen, color, iterateX, iterateY);

		seed = rand() % 2147483647 + (rand() % 1);
		srand(seed);
	}

	printf("Done processing.\n");
}
else
{ /*argv[1] == 0 */

	startColor = rand() % 8;

	switch(startColor){

	case 0:
	    color = SDL_MapRGB(screen->format, 255, 255, 255);
	break;
	case 1:
	    color = SDL_MapRGB(screen->format, 255, 255, 0);
	break;
	case 2:
	    color = SDL_MapRGB(screen->format, 255, 0, 255);
	break;
	case 3:
	    color = SDL_MapRGB(screen->format, 255, 0, 0);
	break;
	case 4:
	    color = SDL_MapRGB(screen->format, 0, 255, 255);
	break;
	case 5:
	    color = SDL_MapRGB(screen->format, 0, 0, 255);
	break;
	case 6:
	    color = SDL_MapRGB(screen->format, 0, 0, 0);
	break;
	case 7:
	    color = SDL_MapRGB(screen->format, 0, 255, 0);
	break;
	}

	int iterateX, iterateY;
	for (iterateX = 0; iterateX < 480; ++iterateX)
	for (iterateY = 0; iterateY < 480; ++iterateY)
	{
		drawPixel(screen, color, iterateX, iterateY);
	}

	printf("Done processing.\n");

}

short semiRandom, life;
if (argv[2][0] == '1') semiRandom = 1;
else semiRandom = 0;
if (argv[3][0] == '1') life = 1;
else life = 0;

	srand(seed);
/* to make sure the random seed is iterated */
seed = rand() % 2147483647 + (rand() % 1);

	startColor = rand() % 8;

switch(startColor){

case 0:
    color = SDL_MapRGB(screen->format, 255, 255, 255);
break;
case 1:
    color = SDL_MapRGB(screen->format, 255, 255, 0);
break;
case 2:
    color = SDL_MapRGB(screen->format, 255, 0, 255);
break;
case 3:
    color = SDL_MapRGB(screen->format, 255, 0, 0);
break;
case 4:
    color = SDL_MapRGB(screen->format, 0, 255, 255);
break;
case 5:
    color = SDL_MapRGB(screen->format, 0, 0, 255);
break;
case 6:
    color = SDL_MapRGB(screen->format, 0, 255, 0);
case 7:
    color = SDL_MapRGB(screen->format, 0, 0, 255);
break;
}


    double *oldValsX = malloc(sizeof(double));
    double *oldValsY = malloc(sizeof(double));
    int oldValsSize = 0;

    short quitProgram = -1;

    /* initialize random seed: */
    srand(seed);

/* to make sure the random seed is iterated */
seed = rand() % 2147483647 + (rand() % 1);


    int x = rand() % 480;
    int y = rand() % 480;

    int towardX = x;
    int towardY = y;

    int middleX;
    int middleY;
    double gradient;
    double b;

    int centreX;
    int centreY;

    while(quitProgram == -1)
    {
			/* generate new point to travell to */

			short collision = 1;

			while (towardX == x && towardY == y)
			{
				srand(SDL_GetTicks());
/* to make sure the random seed is iterated */
SDL_Delay(1);


				towardX = rand() % 480;
				towardY = rand() % 480;
			}

			/* work out the midpoint */
			if (x > towardX)
				middleX = ((x - towardX)/2) + towardX;
			else
				middleX = ((towardX - x)/2) + x;
			if (y > towardY)
				middleY = ((y - towardY)/2) + towardY;
			else
				middleY = ((towardY - y)/2) + y;

			/* work out the negative reciprocal (gradient) */
			gradient = 0 - (1 / ((double)(towardY - y)/(towardX - x)));

			b = middleY - (gradient * middleX);

			centreX = rand() % 480;
			centreY = gradient*centreX + b;

			drawArc(screen, &color, centreX, centreY, x, y, towardX, towardY, &oldValsX, &oldValsY, &oldValsSize, &quitProgram, &collision, &seed, semiRandom, life);

				x = towardX;
				y = towardY;
    }

    SDL_Quit();

    return 0;
}

