#!/bin/sh
cat www.random.org.txt | java coins3