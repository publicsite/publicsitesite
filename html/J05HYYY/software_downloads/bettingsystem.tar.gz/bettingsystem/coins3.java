/*****************************************************************************
 * Copyright (C) 2013 J05HYYY
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
 *****************************************************************************/

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;

public class coins3 {

	public static void main(String[] args)
	{
		int betNumber = 0;
		double maxGain = 0, maxLoss = 0;
		double winnings = 0, losings = 0;
		double bettingTotal = 0;
		char previousBet = '?'; 
		double previousWager = 0;
		int right = 0;
		int wrong = 0;
		int size = 0;
		Vector<Integer> probabilities = new Vector(0,1);
		Vector<Integer> finishOnHeads = new Vector(0,1);
		Vector<Integer> finishOnTails = new Vector(0,1);
		
		BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));;
		
		int iWasWrong = -1;

		while (true)
		{
			String input;
			char myChar;
			try
			{
				input = stdin.readLine();
				if ( input != null )
					myChar = input.charAt(0);
				else
					myChar = 'q';
			}
			catch (IOException e)
			{
				myChar = 'q';
			}

			if (myChar == 'H' ) myChar = 'h';
			if (myChar == 'T' ) myChar = 't';

				if ( myChar == previousBet )
				{
					bettingTotal += previousWager;
					winnings += previousWager;
					if ( previousWager > maxGain ) maxGain = previousWager;
					right++;
					iWasWrong = -1;
					System.out.println("I was right! Betting total = " + bettingTotal + ", Right: " + right + ", Wrong: " + wrong + ", Winnings: " + winnings + ", Losings:" + losings + ", MaxGain: " + maxGain + ", maxLoss: " + (0 - maxLoss) + ".");
					//System.out.println(bettingTotal);
				}
				else if ( previousBet == '?' )
				{
					System.out.println("No bet was taken. Betting total = " + bettingTotal + ", Right: " + right + ", Wrong: " + wrong + ", Winnings: " + winnings + ", Losings:" + losings + ", MaxGain: " + maxGain + ", maxLoss: " + (0 - maxLoss) + ".");
					//System.out.println(bettingTotal);
					iWasWrong = 0;
				}
				else if ( myChar != previousBet )
				{
					bettingTotal -= previousWager;
//if ( bettingTotal < 0 ) System.out.println (bettingTotal);
					losings += previousWager;
					if ( previousWager > maxLoss ) maxLoss = previousWager;
					wrong++;
					iWasWrong = 1;
					System.out.println("I was wrong. Betting total = " + bettingTotal + ", Right: " + right + ", Wrong: " + wrong + ", Winnings: " + winnings + ", Losings:" + losings + ", MaxGain: " + maxGain + ", maxLoss: " + (0 - maxLoss) + ".");
					//System.out.println(bettingTotal);
				}
			
			double totalProbabilityHeads = 0, totalProbabilityTails = 0;

			switch(myChar)
			{
				case 'Q':
				case 'q':
					break;
				case 'h':
					size++;
					probabilities.addElement(new Integer(2 ^ size));
					finishOnHeads.addElement(new Integer(1));
					finishOnTails.addElement(new Integer(0));
					for (int i = 0; i < size; i++)
					{
						finishOnHeads.set(i, finishOnHeads.get(i) + 1);
						if (probabilities.get(i) > 0)
						{
							totalProbabilityHeads += (double)finishOnHeads.get(i) * ((double)1/probabilities.get(i));
							totalProbabilityTails += (double)finishOnTails.get(i) * ((double)1/probabilities.get(i));
						}
					}
					/*					
					try
					{
						input = stdin.readLine();
						myChar = input.charAt(0);
					}
					catch (IOException e)
					{
						System.out.println(e);
					}
					*/
					

					if (totalProbabilityHeads > totalProbabilityTails)
					{
						totalProbabilityHeads -= totalProbabilityTails;
						//if ( iWasWrong == 1 )
						//	previousWager += previousWager;
						//else if ( iWasWrong == -1 )
							previousWager = totalProbabilityHeads;

						System.out.println("I bet tails, with wager: " + previousWager);
						previousBet = 't';
					}
					else if (totalProbabilityTails > totalProbabilityHeads)
					{
						totalProbabilityTails -= totalProbabilityHeads;
						//if ( iWasWrong == 1 )
						//						previousWager += previousWager;
						//else if ( iWasWrong == -1 )
							previousWager = totalProbabilityTails;
						previousBet = 'h';

						System.out.println("I bet heads,with wager: " + previousWager);
					}
					else
					{
						System.out.println("I don't know.");
						previousBet = '?';
					}
				break;
				case 't':
					size++;
					probabilities.addElement(new Integer(2 ^ size));
					finishOnTails.addElement(new Integer(1));
					finishOnHeads.addElement(new Integer(0));
					for (int i = 0; i < size; i++)
					{
						finishOnTails.set(i, finishOnTails.get(i) + 1);
						if (probabilities.get(i) > 0)
						{
							totalProbabilityHeads += (double)finishOnHeads.get(i) * ((double)1/probabilities.get(i));
							totalProbabilityTails += (double)finishOnTails.get(i) * ((double)1/probabilities.get(i));
						}
					}
					
					if (totalProbabilityHeads > totalProbabilityTails)
					{
						totalProbabilityHeads -= totalProbabilityTails;
						//if ( iWasWrong == 1 )
						//	previousWager += previousWager;
						//else if ( iWasWrong == -1 )
							previousWager = totalProbabilityHeads;
						System.out.println("I bet tails, with wager: " + previousWager);
						previousBet = 't';
					}
					else if (totalProbabilityTails > totalProbabilityHeads)
					{
						totalProbabilityTails -= totalProbabilityHeads;
						//if ( iWasWrong == 1 )
						//						previousWager += previousWager;
						//else if ( iWasWrong == -1 )
							previousWager = totalProbabilityTails;
						System.out.println("I bet heads,with wager: " + previousWager);
						previousBet = 'h';
					}
					else
					{
						System.out.println("I don't know.");
						previousBet = '?';
					}

				break;
			}

			if ( myChar == 'q') break;
			++betNumber;
		}
	}
}
