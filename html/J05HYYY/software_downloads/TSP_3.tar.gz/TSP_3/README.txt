What is TSP_3 ?
TSP_3 is my proof-of-concept solution to the travelling salesman problem.

How does it work?
TSP_3 is a program that firstly, works out the distance from each point to every other point, and stores the distance and joined points into
an array. It then sorts these distances and relations. Finally it goes through the sorted array, finding the first complete route.

What are the benchmarks?
_____time taken to work out route for 17 points on an X60 IBM ThinkPad running Trisquel GNU/Linux_____
--> Time taken to find ?best? =route with TSP_3.c
real	0m23.604s
user	0m22.908s
sys	0m0.395s

How do I compile/run TSP_3.c ?
TSP_3 links with libmath, you can compile using:
gcc TSP_3.c -lm -o TSP_3
You can then run with:
./TSP_3 test.tsp

Does TSP_3 find the shortest route?
I haven't tested TSP_3 to see if it always finds the shortest route. If the algorithm works, I see no reason why it wouldn't. With some slight
modification, I am pretty confident that it will be able to always find the quickest route, if it doesn't already.

Why does TSP_3 run out of memory / why didn't you find more points?
TSP_3 is very memory intensive when finding the first complete route, hence why I chose to only find 17 points. Again, with some modification, it could
probably be used to find routes for more points, for instance, by reading and writing to hard disk using a database
(but then reading and writing from hard disk is mostly slower than reading and writing from ram).

How come there are only n-1 (16) relationships between two points specified and not n (17)?
To make a complete circuit, the missing relation should be joined from the start and end points of the route. I am unsure as to whether this will
have much of an effect on the length of the route. If it does, I see no reason why the code cannot be modified, again, to always find the best route.

Why didn't you parallelize the code?
GPUs more often than not, are very proprietary and have proprietary drivers/firmware. So are FPGAs, which have proprietary toolchains. There are
several different vendor-specific ways of writing code for these types of devices, and I want the code to be as universal as possible. Parallelized
code requires specific hardware to do the parallelization. Parallel code is a different style of algorithms, which although is generally quicker,
I think somewhat defeats the point of the problem.

Could the code be parallelized?
Probably.

Could the code/algorithm be further optimized?
Almost certainly.
