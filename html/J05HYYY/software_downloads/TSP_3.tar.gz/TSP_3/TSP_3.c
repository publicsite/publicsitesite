/*****************************************************************************
 * Copyright (C) 2017 J05HYYY
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
 *****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct{
int linkPointA;
int linkPointB;
float distances;
} pointsAndDistances;

int compare(const void *p1, const void *p2)
{
    const pointsAndDistances *elem1 = p1;    
    const pointsAndDistances *elem2 = p2;

   if (elem1->distances < elem2->distances)
      return -1;
   else if (elem1->distances > elem2->distances)
      return 1;
   else
      return 0;
}

int main(int argc, char *argv[]){

if (argc != 2){
printf("No file path given for argument 1, or too many arguments given!\n");
return -1;
}

    FILE * fp;
    char * line = NULL;
    size_t len = 0;
    ssize_t read;

    fp = fopen(argv[1], "r");
    if (fp == NULL)
        exit(EXIT_FAILURE);

//load the data...

int lineNumber=0;

int *pointsX = malloc(sizeof(double));
				if (!pointsX)
				{
					printf("Malloc Failed! 1\n");
					goto end;
				}
int *pointsY = malloc(sizeof(double));
				if (!pointsY)
				{
					printf("Malloc Failed! 2\n");
					goto end;
				}

    while ((read = getline(&line, &len, fp)) != -1) {

        //printf("Retrieved line of length %zu :\n", read);
if(strcmp(line,"EOF\n") != 0)
{
if (lineNumber > 5)
{
	int startRecording = 0;
	int charPtrXSize = 1;
	int charPtrYSize = 1;
	char *charPtrX = malloc(sizeof(char));
				if (!charPtrX)
				{
					printf("Malloc Failed! 3\n");
					goto end;
				}
	char *charPtrY = malloc(sizeof(char));
				if (!charPtrY)
				{
					printf("Malloc Failed! 4\n");
					goto end;
				}
        int charNumber;
	for (charNumber=0; charNumber < read; ++charNumber)
	{
		if (line[charNumber] == ' ')
		{
			if (startRecording == 0 || startRecording == 1)
			{
				++startRecording;
			}
		}
		else
		{
			if (line[charNumber] == '0' || line[charNumber] == '1' || line[charNumber] == '2' || line[charNumber] == '3' || line[charNumber] == '4' || line[charNumber] == '5' || line[charNumber] == '6' || line[charNumber] == '7' || line[charNumber] == '8' || line[charNumber] == '9' ){
//printf("%c",line[charNumber]);
				if (startRecording == 1)
				{
					charPtrX = realloc(charPtrX, sizeof(char) * charPtrXSize);
					if (!charPtrX)
					{
						printf("Realloc Failed! 5\n");
						goto end;
					}
					charPtrX[charPtrXSize-1] = line[charNumber];
				
					++charPtrXSize;
				}
				else if (startRecording == 2)
				{
					charPtrY = realloc(charPtrY, sizeof(char) * charPtrYSize);
					if (!charPtrY)
					{
						printf("Realloc Failed! 6\n");
						goto end;
					}
					charPtrY[charPtrYSize-1] = line[charNumber];
					
					++charPtrYSize;
				}
			}
		}
	}
		pointsX = realloc(pointsX,sizeof(float) * lineNumber - 5);
				if (!pointsX)
				{
					printf("Realloc Failed! 7\n");
					goto end;
				}
		pointsY = realloc(pointsY,sizeof(float) * lineNumber - 5);
				if (!pointsY)
				{
					printf("Realloc Failed! 8\n");
					goto end;
				}

				charPtrY = realloc(charPtrY, sizeof(char) * charPtrYSize);
				if (!charPtrY)
				{
					printf("Realloc Failed! 9\n");
					goto end;
				}
				charPtrY[charPtrYSize-1] = '\0';

				charPtrX = realloc(charPtrX, sizeof(char) * charPtrXSize);
				if (!charPtrX)
				{
					printf("Realloc Failed! 10\n");
					goto end;
				}
				charPtrX[charPtrXSize-1] = '\0';


		pointsX[lineNumber - 6] = atof(charPtrX);
		pointsY[lineNumber - 6] = atof(charPtrY);
		free(charPtrX);
		free(charPtrY);
}
++lineNumber;
}
    }

    fclose(fp);

lineNumber -= 6;

//Now the fun begins...

pointsAndDistances *PAD = malloc(sizeof(pointsAndDistances));
if (!PAD)
{
	printf("Malloc Failed! 11\n");
	goto end;
}
//PAD.linkPointA = malloc(sizeof(int));
//PAD.linkPointB = malloc(sizeof(int));
//PAD.distances = malloc(sizeof(float));

		int j, PADLength=0;
		for (j = 0; j < lineNumber; ++j)
		{
			int k;
			for (k = j+1; k < lineNumber; ++k)
			{
				PADLength += 1;

				PAD = realloc(PAD, sizeof(pointsAndDistances) * PADLength);
				if (!PAD)
				{
					printf("Realloc Failed! 12\n");
					goto end;
				}

				PAD[PADLength-1].linkPointA = j;
				PAD[PADLength-1].linkPointB = k;
				PAD[PADLength-1].distances = sqrt(pow(pointsX[j] - pointsX[k],2) + pow(pointsY[j] - pointsY[k],2));

				//printf("%d %d %d %d\n", pointsX[j], pointsY[j], pointsX[k], pointsY[k]);	

			}
			//	printf("%d,%d\n",j,l); //j to k
		}

qsort(PAD, PADLength, sizeof(pointsAndDistances), compare);

		for (j = 0; j < PADLength; ++j)
		{
			//printf("%d,%d to %d,%d: %f\n",pointsX[PAD[j].linkPointA], pointsY[PAD[j].linkPointA], pointsX[PAD[j].linkPointB], pointsY[PAD[j].linkPointB],PAD[j].distances);
		}

//the fun continues...
int foundASolution = -1;
int chessNotCheckersSize = 0;
int **chessNotCheckers = malloc(sizeof(int *));
if (!chessNotCheckers)
{
	printf("Malloc Failed! 13\n");
	goto end;
}
int *subArraySizes = malloc(sizeof(int));
if (!subArraySizes)
{
printf("Malloc Failed! 14\n");
	goto end;
}
float *subArrayDistances = malloc(sizeof(float));
if (!subArrayDistances)
{
printf("Malloc Failed! 21\n");
	goto end;
}



		float minDistance = 0;

		for (j = 0; j < PADLength; ++j)
		{
			int added = -1;
			int chessNotCheckersOldSize = chessNotCheckersSize;
			int k;
			for (k=0; k < chessNotCheckersOldSize; ++k)
			{

				if ((foundASolution == 1 && subArrayDistances[k] + (PAD[j].distances*(lineNumber-subArraySizes[k])) >= minDistance) || subArraySizes[k] == lineNumber) {
continue;
}
				int counter = 0;
				int l;
//if (lineNumber < pointsX[PAD[j].linkPointA])
//printf("%d %d\n",lineNumber, PAD[j].linkPointA);

				for (l=0; l < subArraySizes[k]; ++l)
				{
					if (
pointsX[PAD[chessNotCheckers[k][l]].linkPointA] == pointsX[PAD[j].linkPointA] && pointsY[PAD[chessNotCheckers[k][l]].linkPointA] == pointsY[PAD[j].linkPointA] || \
pointsX[PAD[chessNotCheckers[k][l]].linkPointB] == pointsX[PAD[j].linkPointA] && pointsY[PAD[chessNotCheckers[k][l]].linkPointB] == pointsY[PAD[j].linkPointA] || \
pointsX[PAD[chessNotCheckers[k][l]].linkPointB] == pointsX[PAD[j].linkPointB] && pointsY[PAD[chessNotCheckers[k][l]].linkPointB] == pointsY[PAD[j].linkPointB] || \
pointsX[PAD[chessNotCheckers[k][l]].linkPointA] == pointsX[PAD[j].linkPointB] && pointsY[PAD[chessNotCheckers[k][l]].linkPointA] == pointsY[PAD[j].linkPointB] )
					{
						++counter;
//printf("counter:%d\n", counter);
						if (subArraySizes[k] != lineNumber-1 && counter == 2 || counter > 2)
						{

							break;
						}
					}
				}
				if (counter == 1 || (counter == 2 && subArraySizes[k] == lineNumber-1))
				{
					++chessNotCheckersSize;
//printf("%da\n",chessNotCheckersSize);
//fflush(stdout);
					chessNotCheckers = realloc(chessNotCheckers, sizeof(int *) * chessNotCheckersSize);
					if (!chessNotCheckers)
					{
						printf("Realloc Failed! 15\n");
						goto end;
					}
					subArraySizes = realloc(subArraySizes, sizeof(int) * chessNotCheckersSize);
					if (!subArraySizes)
					{
						printf("Realloc Failed! 16\n");
						goto end;
					}
					subArrayDistances = realloc(subArrayDistances, sizeof(float) * chessNotCheckersSize);
					if (!subArrayDistances)
					{
						printf("Realloc Failed! 22\n");
						goto end;
					}
					//copy
					chessNotCheckers[chessNotCheckersSize-1] = malloc(sizeof(int) * (subArraySizes[k] + 1));
					if (!chessNotCheckers[chessNotCheckersSize-1])
					{
						printf("Malloc Failed! 17\n");
						goto end;
					}
					for (l=0; l < subArraySizes[k]; ++l)
					{
						chessNotCheckers[chessNotCheckersSize-1][l] = chessNotCheckers[k][l];
					}
					subArraySizes[chessNotCheckersSize-1] = subArraySizes[k] + 1;
					chessNotCheckers[chessNotCheckersSize-1][subArraySizes[k]] = j;
					subArrayDistances[chessNotCheckersSize-1] = subArrayDistances[k] + PAD[j].distances;
//printf("%d %d\n",subArraySizes[chessNotCheckersSize-1], (lineNumber/2)-1);
//printf("%d %d\n", subArraySizes[chessNotCheckersSize-1], lineNumber);

					added = 1;
				}

				if ( counter == 2 && subArraySizes[chessNotCheckersSize-1] == lineNumber)
				{


						if (foundASolution == -1)
						printf("Solution Found!\n");
						else if (foundASolution == 1 && subArrayDistances[chessNotCheckersSize-1] < minDistance)printf("Found A Better Solution!\n");
else
{
	continue;
}
//float theDistance = 0;
//printf("%f %f\n", subArrayDistances[k] + (PAD[j].distances*(lineNumber-subArraySizes[k])), minDistance);
						for (l=0; l < subArraySizes[chessNotCheckersSize-1]; ++l)
						{
//theDistance += PAD[chessNotCheckers[k][l]].distances;
//printf("%d\n",l);

							printf("%d,%d to %d,%d: %f\n", \
pointsX[PAD[chessNotCheckers[chessNotCheckersSize-1][l]].linkPointA], \
pointsY[PAD[chessNotCheckers[chessNotCheckersSize-1][l]].linkPointA], \
pointsX[PAD[chessNotCheckers[chessNotCheckersSize-1][l]].linkPointB], \
pointsY[PAD[chessNotCheckers[chessNotCheckersSize-1][l]].linkPointB], \
PAD[chessNotCheckers[chessNotCheckersSize-1][l]].distances);

//printf("%d\n",l);
//fflush(stdout);
						}
minDistance = subArrayDistances[chessNotCheckersSize-1];
printf("DISTANCE: %f\n",subArrayDistances[chessNotCheckersSize-1]);

//printf("%f\n",theDistance);
foundASolution = 1;
				}
			}

//			if (added != 1)
//			{


			if ((foundASolution == 1 && (minDistance/lineNumber) > PAD[j].distances) || foundASolution != 1)
			{
					++chessNotCheckersSize;
//printf("%db\n",chessNotCheckersSize);
//fflush(stdout);
					chessNotCheckers = realloc(chessNotCheckers, sizeof(int *) * chessNotCheckersSize);
					if (!chessNotCheckers)
					{
						printf("Realloc Failed! 18\n");
						goto end;
					}

					subArraySizes = realloc(subArraySizes, sizeof(int) * chessNotCheckersSize);
					if (!subArraySizes)
					{
						printf("Realloc Failed! 19\n");
						goto end;
					}

					subArrayDistances = realloc(subArrayDistances, sizeof(float) * chessNotCheckersSize);
					if (!subArrayDistances)
					{
						printf("Realloc Failed! 23\n");
						goto end;
					}

					//copy
					chessNotCheckers[chessNotCheckersSize-1] = malloc(sizeof(int));
					if (!chessNotCheckers[chessNotCheckersSize-1])
					{
						printf("Malloc Failed! 20\n");
						goto end;
					}

					subArraySizes[chessNotCheckersSize-1] = 1;
					chessNotCheckers[chessNotCheckersSize-1][0] = j;
					subArrayDistances[chessNotCheckersSize-1] = PAD[j].distances;
			}
if (chessNotCheckersSize == chessNotCheckersOldSize) break;
//			}
			//printf("%d,%d to %d,%d: %f\n",pointsX[PAD[j].linkPointA], pointsY[PAD[j].linkPointA], pointsX[PAD[j].linkPointB], pointsY[PAD[j].linkPointB],PAD[j].distances);
		}

end:
for (j=0;j < chessNotCheckersSize; ++j)
if (chessNotCheckers[j]) free(chessNotCheckers[j]);

if (chessNotCheckers) free(chessNotCheckers);

if (subArraySizes) free(subArraySizes);

if (subArrayDistances) free(subArrayDistances);

   if (line)
        free(line);

					if (pointsX)
					{
						free(pointsX);
					}
					if (pointsY)
					{
						free(pointsY);
					}
					if (PAD)
					{
						free(PAD);
					}
return 0;
}
