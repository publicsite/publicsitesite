This is a couple of scripts, one modified, and one based heavily on the linux-sunxi wiki
(that probably has bugs).

So far first,

olinuxinoLime.sh
is supposed to build a toolchain, compile uboot and a kernel. etc

and then

sudo ./sunxi-media-create.sh /dev/sdX ArchLinuxARM-sun4i-latest.tar.gz
is supposed to install Arch Linux ARM to an sdcard.