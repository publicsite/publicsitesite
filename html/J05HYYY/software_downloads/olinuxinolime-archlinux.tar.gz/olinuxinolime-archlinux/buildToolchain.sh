#!/bin/sh
cd crosstool-ng*
./ct-ng build
cd ..