#*****************************************************************************
 # Copyright (C) 2013 J05HYYY
 #
 # This program is free software; you can redistribute it and/or modify
 # it under the terms of the GNU General Public License as published by
 # the Free Software Foundation; either version 2 of the License, or
 # (at your option) any later version.
 #
 # This program is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 # GNU General Public License for more details.
 #
 # You should have received a copy of the GNU General Public License
 # along with this program; if not, write to the Free Software
 # Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
#*****************************************************************************

#!/bin/sh
# phatFTP - Recursively downloading FTP files with this script is phat :P

output_helpusage(){
helpusage=\
"
PhatFTP is a program for downloading ftp files and folders recursively.
_______________________________________________________________________

USAGE:
${0##*/} [Server Name] [Remote Directory] [Local Directory] [User Name]
_______________________________________________________________________

Server Name:
This is the name of the host you are connecting to eg. ftp.someserver.org
Remote Directory:
This is the path of the directory on the server you want to download recursively eg. this/is/some/directory/
Local Directory:
This is the path of the directory on your machine you want the files to be downloaded into.
If it does not already exist, it will be created.
User Name:
This is the user name you should use to identify yourself to the remote FTP server.

(NOTE: A password will be asked for twice during the download.)
"
echo "$helpusage"
exit
}

case $1 in
"-h"|"--h"|"-help"|"--help"|"--args"|"-args"|"-arguments"|"--arguments"|"")
output_helpusage;;
esac

if [ $2 = NULL ] ; then
output_helpusage
fi

if [ $3 = NULL ] ; then
output_helpusage
fi

if [ $4 = NULL ] ; then
output_helpusage
fi

server=$1
directory=$2
loco=$3
username=$4
password=$5

#read -p "Server: " server
#read -p "Remote Directory: " directory
#read -p "Local Directory: " loco
#read -p "Username: " username

i=0

if [ -d $loco ] ; then #if the local directory doesn't exist yet
cd $loco
else
mkdir $loco #create it
cd $loco
fi

basedir=$PWD

getfiles () {
while read lineout
do
$lineout
done
}

readlines () {
while read linein
do
if [ $i = 0 ] ; then
echo "ftp -n $server"
echo "user $username $password"
echo "cd $directory"
i=1
fi
linetoread=$linein
if ! [ "$linetoread" = "" ] ; then #if the line does not equal nothing
index=$(expr "$linetoread" : '.*/' - $(expr "/" : '.*') + 1) #get position of /

   if [ "$index" -gt "0" ] ; then # if it contains a /
   firsttwochars=`echo "$linetoread" | cut -c 1-2` #get the first 2 characters

      if [ "$firsttwochars" = "./" ] ; then # and if the line has ./ at the start
      linelength=$((${#linetoread}-1)) #get the length -1 (the colon)
      thefolder=`echo "$linetoread" | cut -c 3-$linelength` #trim off the colon and the ./
         

         if ! [ -d $thefolder ] ; then #if the folder doesn't exist
         mkdir $thefolder #create it
         fi

         echo "cd /$directory$thefolder"
      fi
   elif [ "$index" = "0" ] ; then # if it doesn't contain a / linetoread is a file
   echo "get $linetoread $basedir/$thefolder/$linetoread"
   fi
fi

done
echo "bye"
}

ftp -n -i $server <<endftpone | readlines | getfiles
user $username $password
cd $directory
ls -pR1
bye
endftpone