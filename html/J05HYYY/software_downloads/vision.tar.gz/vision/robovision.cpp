/*****************************************************************************
 * Copyright (C) 2013 J05HYYY
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
 *****************************************************************************/

#include <iostream>
#include <string>
#include <math.h>
#include <opencv2/opencv.hpp>

#define PI 3.14159265

using namespace cv;
using namespace std;

struct typeAngles{
double A;
double B;
double C;
};

bool compareResponse (const KeyPoint &a, const KeyPoint &b)
{
return a.response > b.response;
}

struct typeTriangle{
vector<Vec6f> points;
vector<typeAngles> angles;
vector<Scalar> color;
};

bool sortChannel1 (const Scalar &a, const Scalar &b)
{
return a[0] > b[0];
}

bool sortChannel2 (const Scalar &a, const Scalar &b)
{
return a[1] > b[1];
}

bool sortChannel3 (const Scalar &a, const Scalar &b)
{
return a[2] > b[2];
}

bool sortAngleA (const typeAngles &a, const typeAngles &b)
{
return a.A > b.A;
}

bool sortAngleB (const typeAngles &a, const typeAngles &b)
{
return a.B > b.B;
}

bool sortAngleC (const typeAngles &a, const typeAngles &b)
{
return a.C > b.C;
}

typeAngles getAngles (Point A, Point B, Point C){

typeAngles angles;

double tempSide1 = sqrt(pow((double)A.x - (double)B.x, 2) + pow((double)A.y - (double)B.y, 2));

double tempSide2 = sqrt(pow((double)B.x - (double)C.x, 2) + pow((double)B.y - (double)C.y, 2));

double tempSide3 = sqrt(pow((double)A.x - (double)C.x, 2) + pow((double)A.y - (double)C.y, 2));

double sideX, sideY, sideZ;
	if (tempSide1 >= tempSide2 && tempSide1 >= tempSide3)
	{
		sideY = tempSide1;
		sideX = tempSide2;
		sideZ = tempSide3;
	}
	else if (tempSide2 >= tempSide3 && tempSide2 >= tempSide1)
	{
		sideY = tempSide2;
		sideX = tempSide1;
		sideZ = tempSide3;
	}
	else if (tempSide3 >= tempSide1 && tempSide3 >= tempSide2)
	{
		sideY = tempSide3;
		sideX = tempSide2;
		sideZ = tempSide1;
	}

double tempAngle1, tempAngle2, tempAngle3;

double tempAngle1Radians = acos((pow(sideX,2)+pow(sideZ,2)-pow(sideY,2))/(2*sideX*sideZ));
//printf("%f\n",tempAngle1Radians);
tempAngle1 = tempAngle1Radians * 180.0 / PI;
double tempAngle2Radians = asin((sideZ*sin(tempAngle1Radians))/sideY);
tempAngle2 = tempAngle2Radians * 180.0 / PI;
tempAngle3 = 180 - tempAngle1 - tempAngle2;

	if (tempAngle1 >= tempAngle2 && tempAngle2 > tempAngle3)
	{
		angles.A = tempAngle1;
		angles.B = tempAngle2;
		angles.C = tempAngle3;
	}
	else if (tempAngle1 >= tempAngle3 && tempAngle3 > tempAngle2)
	{
		angles.A = tempAngle1;
		angles.B = tempAngle3;
		angles.C = tempAngle2;
	}
	else if (tempAngle2 >= tempAngle1 && tempAngle1 > tempAngle3)
	{
		angles.A = tempAngle2;
		angles.B = tempAngle1;
		angles.C = tempAngle3;
	}
	else if (tempAngle2 >= tempAngle3 && tempAngle3 > tempAngle1)
	{
		angles.A = tempAngle2;
		angles.B = tempAngle3;
		angles.C = tempAngle1;
	}
	else if (tempAngle3 >= tempAngle1 && tempAngle1 > tempAngle2)
	{
		angles.A = tempAngle3;
		angles.B = tempAngle1;
		angles.C = tempAngle2;
	}
	else if (tempAngle3 >= tempAngle2 && tempAngle2 > tempAngle1)
	{
		angles.A = tempAngle3;
		angles.B = tempAngle2;
		angles.C = tempAngle1;
	}
	else
	{
		angles.A = tempAngle3;
		angles.B = tempAngle2;
		angles.C = tempAngle1;
	}

//printf("A=%f,B=%f,C=%f\n",angles.A, angles.B, angles.C);
return angles;
}

typedef struct {
long channel1;
long channel2;
long channel3;
int pixelcount;
} typeColors;

int Sign(double x) {
    if (x < 0)
	{
		return -1;
	}
    else
	{
		return 1;
	}
}

typeColors getLine(Mat3b img, typeColors colors, Point pt1, Point pt2)
{
Size s = img.size();
    int x1 = pt1.x;
    int y1 = pt1.y;
    int x2 = pt2.x;
    int y2 = pt2.y;
    int dy = y2 - y1;
    int dx = x2 - x1;
   int y, x;
    if (fabs(dy) > fabs(dx)) 
	{
        for( y = y1; y != y2; y += Sign( dy ) ) 
		{
            x = x1 + ( y - y1 ) * dx / dy;
int printx, printy;
if (x >= s.width) printx = s.width - 1;
else if (x <= 0) printx = 1;
else printx = x;
if (y >= s.height) printy = s.height - 1;
else if (y <= 0) printy = 1;
else printy = y;
					const Vec3b& bgr = img(Point(printx,printy));
					colors.channel1+=bgr[0];
					colors.channel2+=bgr[1];
					colors.channel3+=bgr[2];
					++colors.pixelcount;
        }
    }
   
    else 
	{
        for( x = x1; x != x2; x += Sign( dx ) ) 
		{
            y = y1 + ( x - x1 ) * dy / dx;
int printx, printy;
if (x >= s.width) printx = s.width - 1;
else if (x <= 0) printx = 1;
else printx = x;
if (y >= s.height) printy = s.height - 1;
else if (y <= 0) printy = 1;
else printy = y;
					const Vec3b& bgr = img(Point(printx,printy));
					colors.channel1+=bgr[0];
					colors.channel2+=bgr[1];
					colors.channel3+=bgr[2];
					++colors.pixelcount;	
	
        }
    }

int printx, printy;
if (x2 >= s.width) printx = s.width - 1;
else if (x2 <= 0) printx = 1;
else printx = x2;
if (y2 >= s.height) printy = s.height - 1;
else if (y2 <= 0) printy = 1;
else printy = y2;

					const Vec3b& bgr = img(Point(printx,printy));
					colors.channel1+=bgr[0];
					colors.channel2+=bgr[1];
					colors.channel3+=bgr[2];
					++colors.pixelcount;
return colors;	
}

#define  XY_SHIFT  16
#define  XY_ONE    (1 << XY_SHIFT)

Scalar getConvexPoly( Mat& img, const Point* v, int npts )
{

Scalar returnColor(255,255,255);
int pixelcount=0;
long channel1 = 0, channel2 = 0, channel3 = 0;
    struct
    {
        int idx, di;
        int x, dx, ye;
    }
    edge[2];

    int shift = 0;
    int delta = shift ? 1 << (shift - 1) : 0;
    int i, y, imin = 0, left = 0, right = 1, x1, x2;
    int edges = npts;
    int xmin, xmax, ymin, ymax;
    int ptr = 0;
    Size size = img.size();
    int pix_size = (int)img.elemSize();
    Point p0;
    int delta1, delta2;

    if( 8 < CV_AA )
        delta1 = delta2 = XY_ONE >> 1;
    else
        delta1 = XY_ONE - 1, delta2 = 0;

    p0 = v[npts - 1];
    p0.x <<= XY_SHIFT - shift;
    p0.y <<= XY_SHIFT - shift;

    assert( 0 <= shift && shift <= XY_SHIFT );
    xmin = xmax = v[0].x;
    ymin = ymax = v[0].y;

    for( i = 0; i < npts; i++ )
    {
        Point p = v[i];
        if( p.y < ymin )
        {
            ymin = p.y;
            imin = i;
        }

        ymax = std::max( ymax, p.y );
        xmax = std::max( xmax, p.x );
        xmin = MIN( xmin, p.x );

        p.x <<= XY_SHIFT - shift;
        p.y <<= XY_SHIFT - shift;

            if( shift == 0 )
            {
                Point pt0, pt1;
                pt0.x = p0.x >> XY_SHIFT;
                pt0.y = p0.y >> XY_SHIFT;
                pt1.x = p.x >> XY_SHIFT;
                pt1.y = p.y >> XY_SHIFT;
		typeColors colors;
		colors.channel1=channel1;
		colors.channel2=channel2;
		colors.channel3=channel3;
		colors.pixelcount=pixelcount;
                colors = getLine( img, colors, pt0, pt1);
		channel1=colors.channel1;
		channel2=colors.channel2;
		channel3=colors.channel3;
		pixelcount=colors.pixelcount;
            }
            else
		{
		typeColors colors;
		colors.channel1=channel1;
		colors.channel2=channel2;
		colors.channel3=channel3;
		colors.pixelcount=pixelcount;
                colors = getLine( img, colors, p0, p);
		channel1=colors.channel1;
		channel2=colors.channel2;
		channel3=colors.channel3;
		pixelcount=colors.pixelcount;
		}

        p0 = p;
    }

    xmin = (xmin + delta) >> shift;
    xmax = (xmax + delta) >> shift;
    ymin = (ymin + delta) >> shift;
    ymax = (ymax + delta) >> shift;

    if( npts < 3 || xmax < 0 || ymax < 0 || xmin >= size.width || ymin >= size.height )
        return returnColor;

    ymax = MIN( ymax, size.height - 1 );
    edge[0].idx = edge[1].idx = imin;

    edge[0].ye = edge[1].ye = y = ymin;
    edge[0].di = 1;
    edge[1].di = npts - 1;

    ptr += y;

    do
    {
        if( 8 < CV_AA || y < ymax || y == ymin )
        {
            for( i = 0; i < 2; i++ )
            {
                if( y >= edge[i].ye )
                {
                    int idx = edge[i].idx, di = edge[i].di;
                    int xs = 0, xe, ye, ty = 0;

                    for(;;)
                    {
                        ty = (v[idx].y + delta) >> shift;
                        if( ty > y || edges == 0 )
                            break;
                        xs = v[idx].x;
                        idx += di;
                        idx -= ((idx < npts) - 1) & npts;   /* idx -= idx >= npts ? npts : 0 */
                        edges--;
                    }

                    ye = ty;
                    xs <<= XY_SHIFT - shift;
                    xe = v[idx].x << (XY_SHIFT - shift);

                    /* no more edges */
                    if( y >= ye )
if (pixelcount != 0)
{
returnColor[0] = (double)(channel1/pixelcount);
returnColor[1] = (double)(channel2/pixelcount);
returnColor[2] = (double)(channel3/pixelcount);
return returnColor;
}
else return returnColor;

                    edge[i].ye = ye;
                    edge[i].dx = ((xe - xs)*2 + (ye - y)) / (2 * (ye - y));
                    edge[i].x = xs;
                    edge[i].idx = idx;
                }
            }
        }

        if( edge[left].x > edge[right].x )
        {
            left ^= 1;
            right ^= 1;
        }

        x1 = edge[left].x;
        x2 = edge[right].x;

        if( y >= 0 )
        {
            int xx1 = (x1 + delta1) >> XY_SHIFT;
            int xx2 = (x2 + delta2) >> XY_SHIFT;

            if( xx2 >= 0 && xx1 < size.width )
            {
                if( xx1 < 0 )
                    xx1 = 0;
                if( xx2 >= size.width )
                    xx2 = size.width - 1;
                //ICV_HLINE( ptr, xx1, xx2, color, pix_size );
                Point pt0, pt1;
                pt0.x = xx1;
                pt0.y = y;
                pt1.x = xx2;
                pt1.y = y;
		typeColors colors;
		colors.channel1=channel1;
		colors.channel2=channel2;
		colors.channel3=channel3;
		colors.pixelcount=pixelcount;
                colors = getLine( img, colors, pt0, pt1);
		channel1=colors.channel1;
		channel2=colors.channel2;
		channel3=colors.channel3;
		pixelcount=colors.pixelcount;
            }
        }

        x1 += edge[left].dx;
        x2 += edge[right].dx;

        edge[left].x = x1;
        edge[right].x = x2;
        ++ptr;
    }
    while( ++y <= ymax );

if (pixelcount != 0)
{
returnColor[0] = (double)(channel1/pixelcount);
returnColor[1] = (double)(channel2/pixelcount);
returnColor[2] = (double)(channel3/pixelcount);
return returnColor;
}
}

int main()
{

	VideoCapture cap(0); // open the default camera
	if(!cap.isOpened())  // check if we succeeded
	return -1;

	Mat img;
	Scalar delaunay_color(255,255,255);

	namedWindow("Img"); 
	namedWindow("Img2");
	namedWindow("Img3");

    BackgroundSubtractorMOG2 bg_model;
bool update_bg_model = true;

Mat mask;

int objectsCaptured = 0;

vector <typeTriangle> triangleLists;
    triangleLists.resize(1);
    vector<vector<Point> > contours;

	for(;;)
	{
		cap >> img; // get a new img from camera

		if (img.empty())
		{
			cout << "Image empty.\n";
			return -1;
		}

	if (update_bg_model)
		bg_model(img, mask, -1);
	else
		bg_model(img, mask, 0.000000000000000000000001);

	Size s = img.size();
	Mat3b display(s.height,s.width, CV_32SC3);

		int key = waitKey(30);
		if( key == 32 && !update_bg_model) //space has been pressed
		{

int Threshl=3;
int Octaves=4; //(pyramid layer) from which the keypoint has been extracted
float PatternScales=1;

BRISK  BRISKD(Threshl,Octaves,PatternScales);//initialize algoritm

	Rect rect(0,0,s.width,s.height);
	Subdiv2D subdiv(rect);

        Mat3b foreImg;
        img.copyTo(foreImg, mask);
	Mat foreGray;
	cvtColor(foreImg, foreGray, CV_BGR2GRAY);

		vector<KeyPoint> foregroundKeyPoints;
		BRISKD.detect(foreGray, foregroundKeyPoints);

for(size_t i = 0; i < foregroundKeyPoints.size(); ++i)
{
	subdiv.insert(foregroundKeyPoints[i].pt);
}

    subdiv.getTriangleList(triangleLists[objectsCaptured].points);

    for( size_t i = 0; i < triangleLists[objectsCaptured].points.size(); i++ )
    {
    	Point pt[3];
        pt[0] = Point(cvRound(triangleLists[objectsCaptured].points[i][0]), cvRound(triangleLists[objectsCaptured].points[i][1]));
        pt[1] = Point(cvRound(triangleLists[objectsCaptured].points[i][2]), cvRound(triangleLists[objectsCaptured].points[i][3]));
        pt[2] = Point(cvRound(triangleLists[objectsCaptured].points[i][4]), cvRound(triangleLists[objectsCaptured].points[i][5]));
	
	Scalar color = getConvexPoly( foreImg, pt, 3);
	fillConvexPoly( display, pt, 3, color, 8, 0);
color[0] = 0.299 * color[0] + 0.587 * color[1] + 0.114 * color[2];
color[1] = -0.147 * color[0] - 0.289 * color[1] + 0.436 * color[2];
color[2] = 0.615 * color [0] - 0.515 * color[1] - 0.100 * color[2];
	triangleLists[objectsCaptured].color.push_back(color);
	triangleLists[objectsCaptured].angles.push_back(getAngles(pt[0],pt[1],pt[2]));
    }


double diffChannel1[objectsCaptured], diffChannel2[objectsCaptured], diffChannel3[objectsCaptured];
double diffAngleA[objectsCaptured], diffAngleB[objectsCaptured], diffAngleC[objectsCaptured];

//
// COLORS
//

// get difference for color channel 1
sort(triangleLists[objectsCaptured].color.begin(), triangleLists[objectsCaptured].color.end(), sortChannel1);
for ( size_t i = 0; i < objectsCaptured; ++i )
{
	diffChannel1[i] = 0;
	sort(triangleLists[i].color.begin(), triangleLists[i].color.end(), sortChannel1);
	for (size_t j = 0; j < triangleLists[i].color.size() && j < triangleLists[objectsCaptured].color.size(); ++j)
	{
		if (triangleLists[objectsCaptured].color[j][0] > triangleLists[i].color[j][0])
		diffChannel1[i] += triangleLists[objectsCaptured].color[j][0] - triangleLists[i].color[j][0];
			else if (triangleLists[i].color[j][0] > triangleLists[objectsCaptured].color[j][0])
		diffChannel1[i] += triangleLists[i].color[j][0] - triangleLists[objectsCaptured].color[j][0];
	}
}


// get difference for color channel 2
sort(triangleLists[objectsCaptured].color.begin(), triangleLists[objectsCaptured].color.end(), sortChannel2);
for ( size_t i = 0; i < objectsCaptured; ++i )
{
	diffChannel2[i] = 0;
	sort(triangleLists[i].color.begin(), triangleLists[i].color.end(), sortChannel2);
	for (size_t j = 0; j < triangleLists[i].color.size() && j < triangleLists[objectsCaptured].color.size(); ++j)
	{
		if (triangleLists[objectsCaptured].color[j][1] > triangleLists[i].color[j][1])
			diffChannel2[i] += triangleLists[objectsCaptured].color[j][1] - triangleLists[i].color[j][1];
		else if (triangleLists[i].color[j][1] > triangleLists[objectsCaptured].color[j][1])
			diffChannel2[i] += triangleLists[i].color[j][1] - triangleLists[objectsCaptured].color[j][1];
	}
}

// get difference for color channel 3
sort(triangleLists[objectsCaptured].color.begin(), triangleLists[objectsCaptured].color.end(), sortChannel3);
for ( size_t i = 0; i < objectsCaptured; ++i )
{
	diffChannel3[i] = 0;
	sort(triangleLists[i].color.begin(), triangleLists[i].color.end(), sortChannel3);
	for (size_t j = 0; j < triangleLists[i].color.size() && j < triangleLists[objectsCaptured].color.size(); ++j)
	{
		if (triangleLists[objectsCaptured].color[j][2] > triangleLists[i].color[j][2])
			diffChannel3[i] += triangleLists[objectsCaptured].color[j][2] - triangleLists[i].color[j][2];
		else if (triangleLists[i].color[j][2] > triangleLists[objectsCaptured].color[j][2])
			diffChannel3[i] += triangleLists[i].color[j][2] - triangleLists[objectsCaptured].color[j][2];
	}

}

//
// ANGLES
//

// get difference for angle A
sort(triangleLists[objectsCaptured].angles.begin(), triangleLists[objectsCaptured].angles.end(), sortAngleA);
for ( size_t i = 0; i < objectsCaptured; ++i )
{
	diffAngleA[i] = 0;
	sort(triangleLists[i].angles.begin(), triangleLists[i].angles.end(), sortAngleA);
	for (size_t j = 0; j < triangleLists[i].angles.size() && j < triangleLists[objectsCaptured].angles.size(); ++j)
	{
		if (triangleLists[objectsCaptured].angles[j].A > triangleLists[i].angles[j].A)
		diffAngleA[i] += triangleLists[objectsCaptured].angles[j].A - triangleLists[i].angles[j].A;
			else if (triangleLists[i].angles[j].A > triangleLists[objectsCaptured].angles[j].A)
		diffAngleA[i] += triangleLists[i].angles[j].A - triangleLists[objectsCaptured].angles[j].A;
	}
}

// get difference for angle B
sort(triangleLists[objectsCaptured].angles.begin(), triangleLists[objectsCaptured].angles.end(), sortAngleB);
for ( size_t i = 0; i < objectsCaptured; ++i )
{
	diffAngleB[i] = 0;
	sort(triangleLists[i].angles.begin(), triangleLists[i].angles.end(), sortAngleB);
	for (size_t j = 0; j < triangleLists[i].angles.size() && j < triangleLists[objectsCaptured].angles.size(); ++j)
	{
		if (triangleLists[objectsCaptured].angles[j].B > triangleLists[i].angles[j].B)
			diffAngleB[i] += triangleLists[objectsCaptured].angles[j].B - triangleLists[i].angles[j].B;
		else if (triangleLists[i].angles[j].B > triangleLists[objectsCaptured].angles[j].B)
			diffAngleB[i] += triangleLists[i].angles[j].B - triangleLists[objectsCaptured].angles[j].B;
	}
}

// get difference for angle C
sort(triangleLists[objectsCaptured].angles.begin(), triangleLists[objectsCaptured].angles.end(), sortAngleC);
for ( size_t i = 0; i < objectsCaptured; ++i )
{
	diffAngleC[i] = 0;
	sort(triangleLists[i].angles.begin(), triangleLists[i].angles.end(), sortAngleC);
	for (size_t j = 0; j < triangleLists[i].angles.size() && j < triangleLists[objectsCaptured].angles.size(); ++j)
	{
		if (triangleLists[objectsCaptured].angles[j].C > triangleLists[i].angles[j].C)
			diffAngleC[i] += triangleLists[objectsCaptured].angles[j].C - triangleLists[i].angles[j].C;
		else if (triangleLists[i].angles[j].C > triangleLists[objectsCaptured].angles[j].C)
			diffAngleC[i] += triangleLists[i].angles[j].C - triangleLists[objectsCaptured].angles[j].C;
	}

}

double lowestDifference = 999999;
int mostLikely = -1;
for ( size_t i = 0; i < objectsCaptured; ++i )
{
	double colorDifference = ((diffChannel1[i] + diffChannel2[i] + diffChannel3[i])/triangleLists[i].color.size())/3;
	double angleDifference = ((diffAngleA[i] + diffAngleB[i] + diffAngleC[i])/triangleLists[i].angles.size())/3;
	double totalDifference =colorDifference*angleDifference;
	cout << i+1 << " " << colorDifference << " " << angleDifference << " " << totalDifference << "\n";
	if (totalDifference < lowestDifference)
	{
		lowestDifference = totalDifference;
		mostLikely = i + 1;
	}
}
//printf("%f %f %f\n", diffAngleA[i], diffAngleB[i], diffAngleC[i]);

cout << "Registered object " << objectsCaptured+1 << "\n";
if (objectsCaptured > 0)
cout << "Most likely to be object " << mostLikely << " with difference being " << lowestDifference << "\n";
cout << "\n";
    ++objectsCaptured;
    triangleLists.resize(objectsCaptured+1);

			imshow("Img2",display);
			imshow("Img3",foreImg);
		}
		else if( key == 10) //return has been pressed
		{
			update_bg_model = !update_bg_model;

			if(update_bg_model)
				cout << "Background update is on.\n";
			else
				cout << "Background update is off.\n";
		}
		else if( key == 27) break; //escape has been pressed

			imshow("Img", img);
	}

 // the camera will be deinitialized automatically in VideoCapture destructor
 return 0;
}
