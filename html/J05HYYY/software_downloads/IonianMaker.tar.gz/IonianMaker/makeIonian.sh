#!/bin/sh
apt-get clean

apt-get update

#download programs for installation
apt-get -d install xorg --no-install-recommends --reinstall -y
apt-get -d install openbox --no-install-recommends --reinstall -y
apt-get -d install obconf --no-install-recommends --reinstall -y
apt-get -d install gnome-menus --no-install-recommends --reinstall -y
apt-get -d install pcmanfm --no-install-recommends --reinstall -y
apt-get -d install wmbattery --no-install-recommends --reinstall -y
apt-get -d install leafpad --no-install-recommends --reinstall -y
apt-get -d install vlc --no-install-recommends --reinstall -y
apt-get -d install vlc-plugin-pulse --no-install-recommends --reinstall -y
apt-get -d install libreoffice-gtk3 --no-install-recommends --reinstall -y
apt-get -d install xdm --no-install-recommends --reinstall -y
apt-get -d install htop --no-install-recommends --reinstall -y
apt-get -d install linphone --no-install-recommends --reinstall -y
apt-get -d install gnome-paint --no-install-recommends --reinstall -y
apt-get -d install isomaster --no-install-recommends --reinstall -y
apt-get -d install gparted --no-install-recommends --reinstall -y
apt-get -d install evince-gtk --no-install-recommends --reinstall -y
apt-get -d install roxterm-gtk3 --no-install-recommends --reinstall -y
apt-get -d install python-xdg --no-install-recommends --reinstall -y
apt-get -d install sudo --no-install-recommends --reinstall -y
apt-get -d install pulseaudio --reinstall -y
apt-get -d install libao4 --reinstall -y
apt-get -d install paprefs --reinstall -y
apt-get -d install libpulse-mainloop-glib0 --reinstall -y
apt-get -d install pulseaudio-module-jack --reinstall -y
apt-get -d install pavucontrol --reinstall -y
apt-get -d install pulseaudio-module-hal --reinstall -y
apt-get -d install pulseaudio-module-x11 --reinstall -y
apt-get -d install gstreamer0.10-pulseaudio --reinstall -y
apt-get -d install pulseaudio-utils --reinstall -y
apt-get -d install libasound2-plugins --reinstall -y
apt-get -d install paman --reinstall -y
apt-get -d install pulseaudio-module-gconf --reinstall -y
apt-get -d install libgconfmm-2.6-1c2 --reinstall -y
apt-get -d install libpulse-browse0 --reinstall -y
apt-get -d install pavumeter --reinstall -y
apt-get -d install libglademm-2.4-1c2a --reinstall -y
apt-get -d install pulseaudio-esound-compat --reinstall -y
apt-get -d install libpulse0 --reinstall -y
apt-get -d install libpulse-dev --reinstall -y
apt-get -d install pulseaudio-module-bluetooth --reinstall -y
apt-get -d install pulseaudio-module-zeroconf --reinstall -y
apt-get -d install padevchooser --reinstall -y
apt-get -d install gksu --reinstall -y
apt-get -d install wicd --reinstall -y
apt-get -d install gnome-brave-icon-theme --no-install-recommends --reinstall -y
apt-get -d install grandr --no-install-recommends --reinstall -y
apt-get -d install gvfs --reinstall -y
apt-get -d install gvfs-fuse --reinstall -y
apt-get -d install policykit-1 --reinstall -y
apt-get -d install policykit-1-gnome --reinstall -y
apt-get -d install xarchiver --reinstall -y
apt-get -d install mirage --no-install-recommends --reinstall -y
apt-get -d install transmission --no-install-recommends --reinstall -y
apt-get -d install galculator --no-install-recommends --reinstall -y
apt-get -d install default-jre --no-install-recommends --reinstall -y
apt-get -d install feh myspell-en-gb --no-install-recommends --reinstall -y
apt-get -d install gnash --no-install-recommends --reinstall -y
apt-get -d install chromium-browser --no-install-recommends --reinstall -y
apt-get -d install audacity --no-install-recommends --reinstall -y
apt-get -d install gimp --no-install-recommends --reinstall -y
apt-get -d install xchat --no-install-recommends --reinstall -y
apt-get -d install gftp --no-install-recommends --reinstall -y
apt-get -d install gtk-gnutella --no-install-recommends --reinstall -y
apt-get -d install wine --no-install-recommends --reinstall -y
apt-get -d install fbpanel --no-install-recommends --reinstall -y
apt-get -d install icedove --no-install-recommends --reinstall -y
apt-get -d install enigmail --no-install-recommends --reinstall -y
apt-get -d install streamtuner2 --no-install-recommends --reinstall -y
#version 0.1
apt-get -d install gnunet-gtk --no-install-recommends --reinstall -y
apt-get -d install blueman --no-install-recommends --reinstall -y
apt-get -d install dosfstools --no-install-recommends --reinstall -y
#version 0.2
apt-get -d install clipit --no-install-recommends --reinstall -y
apt-get -d install get-flash-videos --no-install-recommends --reinstall -y
#addition to come:
#apt-get -d install vlc-plugin-pulse --no-install-recommends --reinstall -y

#make a tar of all programs installed
tar -czvf archives.tar.gz /var/cache/apt/archives

apt-get install dpkg-dev -y
basepwd=$PWD
cd /var/cache/apt/archives
dpkg-scanpackages ./ /dev/null |gzip > $basepwd/Packages.gz

apt-get clean

