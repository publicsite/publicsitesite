#!/bin/sh

NETINSTNAME="$1"
CDOUTFILENAME="$2"

if [ ! -f $NETINSTNAME ]; then
echo "Argument 1; Netinst name not found, exiting."
exit
fi
if [ -z "$CDOUTFILENAME" ]; then
echo "Argument 2; CD iso outfile name not found, exiting."
exit
fi

basepwd=$PWD
#Make a tempoary folder to mount the original iso in
mkdir ./iso
#Mount the original iso
mount -t iso9660 $NETINSTNAME ./iso -o loop
#Make the doors folder
mkdir ./Doors
#Make an iso folder to copy the contents of the cd into
mkdir ./Doors/iso
#Copy the iso into the folder
cp -a ./iso ./Doors/
#Copy finisher into iso copy
cp -R finisher ./Doors/iso/
#Enter the finisher directory
cd ./Doors/iso/finisher
#Extract archives
gzip -dc $basepwd/archives.tar.gz | tar xf -
#Copy Packages.gz into correct folder
cp $basepwd/Packages.gz ./var/cache/apt/archives/
#Enter the base working directory
cd $basepwd

#Make directory to extract initrd into
mkdir ./Doors/initrd
#Enter that directory
cd ./Doors/initrd
#Extract initrd from copied iso
gzip -dc ../iso/install.386/initrd.gz | cpio -id
#Copy the preseed file into the initrd
cp $basepwd/preseed.cfg .
#Remove the initrd from the iso copy
rm ../iso/install.386/initrd.gz
#Make a directory to compress the new initrd into
mkdir ../newinitrd
#Create the cpio
find ./ | cpio -H newc -o > ../newinitrd/initrd
cd ..
#Make a .gz of the cpio
gzip ./newinitrd/initrd
#Copy the new compressed initrd into the iso copy
cp ./newinitrd/initrd.gz ./iso/install.386/
#make the file read only to all users
chmod 555 ./iso/install.386/initrd.gz
#Clean up by removing the initrd directory and contents
rm -r ./initrd

#Get mkisofs to make the new iso with
apt-get install genisoimage 
#Make the new iso image
genisoimage -D -r -cache-inodes -J -l -b isolinux/isolinux.bin -c isolinux/boot.cat -no-emul-boot -boot-load-size 4 -boot-info-table -o $basepwd/$CDOUTFILENAME $basepwd/Doors/iso/

#Clean up by removing the Doors folder and it's contents
rm -r $basepwd/Doors
#Unmount the iso
umount $basepwd/iso
#Delete the iso folder
rm -r $basepwd/iso/
