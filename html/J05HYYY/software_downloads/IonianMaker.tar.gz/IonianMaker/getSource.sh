#!bin/bash

apt-get install apt-rdepends

mkdir source
cd source

for line in $(apt-rdepends xorg -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends openbox -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends obconf -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends gnome-menus -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends pcmanfm -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends wmbattery -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends leafpad -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends vlc -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends libreoffice-gtk3 -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends xdm -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends htop -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends gnome-paint -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends linphone -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends isomaster -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends gparted -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends evince-gtk -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends roxterm-gtk3 -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends python-xdg -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends sudo -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends pulseaudio -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends libao4 -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends paprefs -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends libpulse-mainloop-glib0 -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends pulseaudio-module-jack -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends pavucontrol -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends pulseaudio-module-hal -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends pulseaudio-module-x11 -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends gstreamer0.10-pulseaudio -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends pulseaudio-utils -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends libasound2-plugins -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends paman -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends pulseaudio-module-gconf -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends libgconfmm-2.6-1c2 -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends libpulse-browse0 -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends pavumeter -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends libglademm-2.4-1c2a -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends pulseaudio-esound-compat -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends libpulse0 -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends libpulse-dev -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends pulseaudio-module-bluetooth -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends pulseaudio-module-zeroconf -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends padevchooser -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends gksu -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends wicd -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends gnome-brave-icon-theme -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends grandr -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends gvfs -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends gvfs-fuse -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends policykit-1 -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends policykit-1-gnome -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends xarchiver -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends mirage -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends transmission -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends galculator -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends default-jre -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends feh myspell-en-gb -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends gnash -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends chromium-browser -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends audacity -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends gimp -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends xchat -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends gftp -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends gtk-gnutella -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends wine -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends dosbox -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends fbpanel -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends icedove -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends enigmail -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends streamtuner2 -show=DEPENDS); do
apt-get source $line
done

#version 0.1

for line in $(apt-rdepends gnunet-gtk -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends blueman -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends dosfstools -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends clipit -show=DEPENDS); do
apt-get source $line
done

for line in $(apt-rdepends get-flash-videos -show=DEPENDS); do
apt-get source $line
done

#addition to come:
#for line in $(apt-rdepends vlc-plugin-pulse -show=DEPENDS); do
#apt-get source $line
#done
