#!/bin/sh
# Copyright (C) 2015 J05HYYY

###BUILD THE TOOLCHAIN###

#get and configure crosstool-ng
. ./getCrossTool.sh

#patch to make it libre!
patch -p0 < ctng-libre.patch

#set toolchain type
toolChainType="i686-nptl-linux-gnu"

#include
. ./configureForKernel.sh

#configure crosstool-ng for our sunxi kernel
configureForKernel "$toolChainType"

#build our toolchain
. ./buildToolchain.sh
