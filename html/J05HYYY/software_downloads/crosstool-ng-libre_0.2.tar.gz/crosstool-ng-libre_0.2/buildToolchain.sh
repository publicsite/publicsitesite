#!/bin/sh
# Copyright (C) 2015 J05HYYY
cd crosstool-ng*
CT_DEBUG_CT=y CT_DEBUG_CT_SAVE_STEPS=y CT_DEBUG_CT_SAVE_STEPS_GZIP=y ./ct-ng build
cd ..
