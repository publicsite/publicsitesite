/*****************************************************************************
 * Copyright (C) 2013 J05HYYY
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
 *****************************************************************************/

#include <stdio.h>
#include <math.h>

main()
{

int a,b,x,newx,bitsize,howmany,numeralsystem,amounttocopy,index,y,z;
int combination=0,pulse=0;
numeralsystem=2;
bitsize=3;
a=pow(numeralsystem, bitsize);
int Combinations[a][bitsize];

x=0;
newx=x;
while (newx < bitsize)
{
newx=x + 1;
howmany=pow(numeralsystem, x);
combination=0;
b=pow(numeralsystem, newx);
amounttocopy=a / b;
index=0;
while (index < amounttocopy)
{
y=0;
while (y < numeralsystem)
{
z=0;
while (z<howmany)
{
combination=combination+1;
Combinations[combination][pulse] = y;
printf("%d,",y);
z=z + 1;
}
y=y + 1;
}
index=index + 1;
}
x=x + 1;
pulse=pulse+1;
}

/* READING A WHOLE COMBINATION */
int selectedcombination,selectedpulse,use;

for (selectedcombination=1;selectedcombination<=a;selectedcombination++)
{
printf("Combination: %d   ",selectedcombination);
	for (selectedpulse=0;selectedpulse<bitsize;selectedpulse++)
	{
	printf("%d,",Combinations[selectedcombination][selectedpulse]);
	}
	printf("\n");
}

printf("Combination: %d   %d,%d,%d,\n",a,numeralsystem-1,numeralsystem-1,numeralsystem-1);

}
