#include "debug.h"
    #include <stdio.h>
    #include <stdlib.h>
    #include <sqlite3.h>
#include <string.h>

    static int callback(void *NotUsed, int argc, char **argv, char **azColName){
if (BEZZLE_DEBUG == 1){
      int i;
      for(i=0; i<argc; i++){
        printf("%s = %s\n", azColName[i], argv[i] ? argv[i]: "NULL");
      }
      printf("\n");
}
      return 0;
    }

    int main(int argc, char **argv){
      sqlite3 *db;
      char *zErrMsg = 0;
      int rc;

      if( argc!=4 ){
        fprintf(stderr, "Usage: %s DATABASE KEY VALUE\n", argv[0]);
        exit(1);
      }
      rc = sqlite3_open(argv[1], &db);
      if( rc ){
if (BEZZLE_DEBUG == 1)
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        exit(1);
      }

char *command = malloc(sizeof(char) * (50 + strlen(argv[2]) + strlen(argv[3])));
strcpy(command, "INSERT INTO data(LookupKey, Value) VALUES(");
strcat(command, "\"");
strcat(command, argv[2]);
strcat(command, "\", \"");
strcat(command, argv[3]);
strcat(command, "\")");
printf("%s\n",command);
      rc = sqlite3_exec(db, command, callback, 0, &zErrMsg);
      if( rc!=SQLITE_OK ){
if (BEZZLE_DEBUG == 1)
        fprintf(stderr, "SQL error: %s\n", zErrMsg);
        /* This will free zErrMsg if assigned */
        if (zErrMsg)
           free(zErrMsg);
      }
      sqlite3_close(db);
      return 0;
    }
