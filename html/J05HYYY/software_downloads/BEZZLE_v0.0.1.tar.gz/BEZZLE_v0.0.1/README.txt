
Bezzle is a connected key/value database, currently licenced under the GNU General Public Licence v2.

You query for a key, that query is sent to your contacts to which you have their certificate, you need their certificate because connections
are encrypted with ssl, (more specifically mbedtls), if they don't have the answer to your query, the query is forwarded to their contacts. This
is known as flooding. To get around flooding loops, Bezzle stores the hash of the query with the time and date. This hash is then checked to see
if the packet has already been routed by a node (or not).

The results for the query are ordered by consensus. If many of _your_ contacts agree on the result of a query, this will usually be top of the
list. These settings can be changed to give weightings to different contacts based on how much you may or may not trust them.

If enough people add data to their database, people will hopefully find that they have a kind-of connected source of information. Information
can be DNS lookups, magnet links or other urls, queries for other contacts or anything else with a short text size. Essentially, this could lead 
to many things.

sqllite is also used and the requests formatted in a very basic XML. There may be some errors, some memory leaks (haven't checked), so
really this is just a proof-of-concept, please feel free to fork and fix any errors you may find, or make any improvements.

