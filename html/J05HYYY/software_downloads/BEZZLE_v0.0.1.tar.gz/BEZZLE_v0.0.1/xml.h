//this needs to be modified to use strncmp
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
char *encodeXMLString(char *stringIn, int length)
{
	char *xmlOut = malloc(sizeof(char));
	int inIndex, outIndex = 0;
	for(inIndex=0; inIndex < length; ++inIndex)
	{
		if (stringIn[inIndex] == '>')
		{
			xmlOut=realloc(xmlOut, (outIndex + 4) * sizeof(char));
			xmlOut[outIndex] = '&';
			++outIndex;
			xmlOut[outIndex] = 'g';
			++outIndex;
			xmlOut[outIndex] = 't';
			++outIndex;
			xmlOut[outIndex] = ';';
		}
		else if (stringIn[inIndex] == '<')
		{
			xmlOut=realloc(xmlOut, (outIndex + 4) * sizeof(char));
			xmlOut[outIndex] = '&';
			++outIndex;
			xmlOut[outIndex] = 'l';
			++outIndex;
			xmlOut[outIndex] = 't';
			++outIndex;
			xmlOut[outIndex] = ';';
		}
		else if (stringIn[inIndex] == '&')
		{
			xmlOut=realloc(xmlOut, (outIndex + 5) * sizeof(char));
			xmlOut[outIndex] = '&';
			++outIndex;
			xmlOut[outIndex] = 'a';
			++outIndex;
			xmlOut[outIndex] = 'm';
			++outIndex;
			xmlOut[outIndex] = 'p';
			++outIndex;
			xmlOut[outIndex] = ';';
		}
		else if (stringIn[inIndex] == '%')
		{
			xmlOut=realloc(xmlOut, (outIndex + 5) * sizeof(char));
			xmlOut[outIndex] = '&';
			++outIndex;
			xmlOut[outIndex] = '#';
			++outIndex;
			xmlOut[outIndex] = '3';
			++outIndex;
			xmlOut[outIndex] = '7';
			++outIndex;
			xmlOut[outIndex] = ';';
		}
		else
		{
			xmlOut=realloc(xmlOut, (outIndex + 1) * sizeof(char));
			xmlOut[outIndex] = stringIn[inIndex];
		}

			if (inIndex < (length - 1));
			++outIndex;
	}

	if ((length - 1) != '\0')
	{
	xmlOut=realloc(xmlOut, (outIndex + 1) * sizeof(char));
	xmlOut[outIndex] = '\0';
	}

return xmlOut;
}

char *decodeXMLString(char *xmlIn, int xmlInLength)
{
	char *stringOut = malloc(sizeof(char));
	int inIndex, outIndex = 0;
	for(inIndex=0; inIndex < xmlInLength; ++inIndex)
	{
		stringOut=realloc(stringOut, (outIndex + 1) * sizeof(char));
		if (xmlIn[inIndex] == '&' && inIndex + 1 < xmlInLength)
		{
			if (xmlInLength >= inIndex + 3 && xmlIn[inIndex+1] == 'g')
			{
				/*&gt;*/
				stringOut[outIndex] = '>';
				inIndex += 3;
			}
			else if (xmlInLength >= inIndex + 3 && xmlIn[inIndex+1] == 'l')
			{
				/*&lt;*/
				stringOut[outIndex] = '<';
				inIndex += 3;
			}
			else if (xmlInLength >= inIndex + 4 && xmlIn[inIndex+1] == 'a')
			{
				/*&amp;*/
				stringOut[outIndex] = '&';
				inIndex += 4;
			}
			else if (xmlInLength >= inIndex + 4 && xmlIn[inIndex+1] == '#')
			{
				/*&#37;*/
				stringOut[outIndex] = '%';
				inIndex += 4;
			}
		}
		else
		{
			stringOut[outIndex] = xmlIn[inIndex];
		}

			if (inIndex < (xmlInLength - 1));
			++outIndex;
	}

	if ((xmlInLength - 1) != '\0')
	{
	stringOut=realloc(stringOut, (outIndex + 1) * sizeof(char));
	stringOut[outIndex] = '\0';
	}

return stringOut;
}

