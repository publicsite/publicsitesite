/*
 *  SSL server demonstration program
 *
 *  Copyright (C) 2006-2013, Brainspark B.V.
 *
 *  This file is part of PolarSSL (http://www.polarssl.org)
 *  Lead Maintainer: Paul Bakker <polarssl_maintainer at polarssl.org>
 *
 *  All rights reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include "debug.h"

#include "polarssl/config.h"

#if defined(_WIN32)
#include <windows.h>
#endif

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "xml.h"
    #include <sqlite3.h>

#include "polarssl/entropy.h"
#include "polarssl/ctr_drbg.h"
#include "polarssl/certs.h"
#include "polarssl/x509.h"
#include "polarssl/ssl.h"
#include "polarssl/net.h"
#include "polarssl/error.h"

#include "ssl_query.h"

#if defined(POLARSSL_SSL_CACHE_C)
#include "polarssl/ssl_cache.h"
#endif

#if !defined(POLARSSL_BIGNUM_C) || !defined(POLARSSL_CERTS_C) ||    \
    !defined(POLARSSL_ENTROPY_C) || !defined(POLARSSL_SSL_TLS_C) || \
    !defined(POLARSSL_SSL_SRV_C) || !defined(POLARSSL_NET_C) ||     \
    !defined(POLARSSL_RSA_C) || !defined(POLARSSL_CTR_DRBG_C) ||    \
    !defined(POLARSSL_X509_CRT_PARSE_C)
int main( int argc, char *argv[] )
{
    ((void) argc);
    ((void) argv);

if (BEZZLE_DEBUG == 1)
    printf("POLARSSL_BIGNUM_C and/or POLARSSL_CERTS_C and/or POLARSSL_ENTROPY_C "
           "and/or POLARSSL_SSL_TLS_C and/or POLARSSL_SSL_SRV_C and/or "
           "POLARSSL_NET_C and/or POLARSSL_RSA_C and/or "
           "POLARSSL_CTR_DRBG_C and/or POLARSSL_X509_CRT_PARSE_C "
           "not defined.\n");
    return( 0 );
}
#else

#define HTTP_RESPONSE \
    "HTTP/1.0 200 OK\r\nContent-Type: text/html\r\n\r\n" \
    "<h2>PolarSSL Test Server</h2>\r\n" \
    "<p>Successful connection using: %s</p>\r\n"

#if (BEZZLE_DEBUG == 1)
#define DEBUG_LEVEL 0
#endif

    static int responseCallback(void *responseVoid, int argc, char **argv, char **azColName){
      char **response = (char **)responseVoid;
if (argv[2])
{
		*response = realloc(*response, strlen(argv[2]));
		sprintf(*response, "%s", argv[2]);
}
      return 0;
    }

    static int hashCallback(void *foundHashVoid, int argc, char **argv, char **azColName){
      int *foundHash = (int *)foundHashVoid;
if (argv[1])
{
		*foundHash = 1;
}
else
{
		*foundHash = -1;
}
return 0;
    }

    static int insertCallback(void *NotUsed, int argc, char **argv, char **azColName){
if (BEZZLE_DEBUG == 1){
      int i;
      for(i=0; i<argc; i++){
        printf("%s = %s\n", azColName[i], argv[i] ? argv[i]: "NULL");
      }
      printf("\n");
}
      return 0;
    }


int sendResponse(char *response, ssl_context ssl, unsigned char buf[1024], int len, int ret){
char *responseEncoded;
responseEncoded = encodeXMLString(response, strlen(response));
    /*
     * 7. Write the 200 Response
     */
if (BEZZLE_DEBUG == 1){
    printf( "  > Write to client:" );
    fflush( stdout );
}
    len = sprintf( (char *) buf, "%s", responseEncoded );

    while( ( ret = ssl_write( &ssl, buf, len ) ) <= 0 )
    {
        if( ret == POLARSSL_ERR_NET_CONN_RESET )
        {
if (BEZZLE_DEBUG == 1)
            printf( " failed\n  ! peer closed the connection\n\n" );

            return 1;
            //goto reset;
        }

        if( ret != POLARSSL_ERR_NET_WANT_READ && ret != POLARSSL_ERR_NET_WANT_WRITE )
        {
if (BEZZLE_DEBUG == 1)
            printf( " failed\n  ! ssl_write returned %d\n\n", ret );
            return -1;
            //goto exit;
        }
    }

    len = ret;
if (BEZZLE_DEBUG == 1)
    printf( " %d bytes written\n\n%s\n", len, (char *) buf );
    
    ret = 0;
    return 1;
    //goto reset;
}

int main( int argc, char *argv[] )
{
      sqlite3 *serverDB;
      char *zErrMsg = 0;
      int rc;

if (argc != 6)
{
printf("requires the database, cert file, keyfile, ip and port as arguments 1,2,3 and 4, 5 respectively.");
exit(1);
}

      rc = sqlite3_open(argv[1], &serverDB);
      if( rc!=SQLITE_OK ){
if (BEZZLE_DEBUG == 1)
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(serverDB));
        sqlite3_close(serverDB);
        exit(1);
      }

    int ret, len;
    int listen_fd;
    int client_fd = -1;
    unsigned char buf[1024];
    const char *pers = "ssl_server";

    entropy_context entropy;
    ctr_drbg_context ctr_drbg;
    ssl_context ssl;
    x509_crt srvcert;
    pk_context pkey;
#if defined(POLARSSL_SSL_CACHE_C)
    ssl_cache_context cache;
#endif

    ((void) argc);
    ((void) argv);

#if defined(POLARSSL_SSL_CACHE_C)
    ssl_cache_init( &cache );
#endif

    /*
     * 1. Load the certificates and private RSA key
     */
if (BEZZLE_DEBUG == 1){
    printf( "\n  . Loading the server cert. and key..." );
    fflush( stdout );
}
    x509_crt_init( &srvcert );

    /*
     * This demonstration program uses embedded test certificates.
     * Instead, you may want to use x509_crt_parse_file() to read the
     * server and CA certificates, as well as pk_parse_keyfile().
     */
    ret = x509_crt_parse_file( &srvcert, argv[2] );
    if( ret != 0 )
    {
if (BEZZLE_DEBUG == 1)
        printf( " failed\n  !  x509_crt_parse returned %d\n\n", ret );
        goto exit;
    }

    ret = x509_crt_parse( &srvcert, (const unsigned char *) test_ca_list,
                          strlen( test_ca_list ) );
    if( ret != 0 )
    {
if (BEZZLE_DEBUG == 1)
        printf( " failed\n  !  x509_crt_parse returned %d\n\n", ret );
        goto exit;
    }

    pk_init( &pkey );
    ret =  pk_parse_keyfile( &pkey, argv[3], NULL);
    if( ret != 0 )
    {
if (BEZZLE_DEBUG == 1)
        printf( " failed\n  !  pk_parse_key returned %d\n\n", ret );
        goto exit;
    }

if (BEZZLE_DEBUG == 1){
    printf( " ok\n" );

    /*
     * 2. Setup the listening TCP socket
     */
    printf( "  . Bind on %s/%s ...", argv[4], argv[5] );
    fflush( stdout );

}
    if( ( ret = net_bind( &listen_fd, argv[4], atoi(argv[5]) ) ) != 0 )
    {
if (BEZZLE_DEBUG == 1)
        printf( " failed\n  ! net_bind returned %d\n\n", ret );
        goto exit;
    }

if (BEZZLE_DEBUG == 1){
    printf( " ok\n" );

    /*
     * 3. Seed the RNG
     */
    printf( "  . Seeding the random number generator..." );
    fflush( stdout );
}

    entropy_init( &entropy );
    if( ( ret = ctr_drbg_init( &ctr_drbg, entropy_func, &entropy,
                               (const unsigned char *) pers,
                               strlen( pers ) ) ) != 0 )
    {
if (BEZZLE_DEBUG == 1)
        printf( " failed\n  ! ctr_drbg_init returned %d\n", ret );
        goto exit;
    }

if (BEZZLE_DEBUG == 1)
    printf( " ok\n" );

    /*
     * 4. Setup stuff
     */
if (BEZZLE_DEBUG == 1){
    printf( "  . Setting up the SSL data...." );
    fflush( stdout );
}

    if( ( ret = ssl_init( &ssl ) ) != 0 )
    {
if (BEZZLE_DEBUG == 1)
        printf( " failed\n  ! ssl_init returned %d\n\n", ret );
        goto exit;
    }

    ssl_set_endpoint( &ssl, SSL_IS_SERVER );
    ssl_set_authmode( &ssl, SSL_VERIFY_NONE );

    ssl_set_rng( &ssl, ctr_drbg_random, &ctr_drbg );
if (BEZZLE_DEBUG == 1)
    ssl_set_dbg( &ssl, my_debug, stdout );

#if defined(POLARSSL_SSL_CACHE_C)
    ssl_set_session_cache( &ssl, ssl_cache_get, &cache,
                                 ssl_cache_set, &cache );
#endif

    ssl_set_ca_chain( &ssl, srvcert.next, NULL, NULL );
    ssl_set_own_cert( &ssl, &srvcert, &pkey );

if (BEZZLE_DEBUG == 1)
    printf( " ok\n" );

/*buffers*/
int *foundHash = malloc(sizeof(int));
int readNumber;
char *packetHash;
packetHash = malloc(sizeof(char));
char *hashCommand;
hashCommand = malloc(sizeof(char));

reset:

#ifdef POLARSSL_ERROR_C
    if( ret != 0 )
    {
if (BEZZLE_DEBUG == 1){
        char error_buf[100];
        polarssl_strerror( ret, error_buf, 100 );
        printf("Last error was: %d - %s\n\n", ret, error_buf );
}
    }
#endif


readNumber = 0;

    if( client_fd != -1 )
        net_close( client_fd );

    ssl_session_reset( &ssl );

    /*
     * 3. Wait until a client connects
     */
    client_fd = -1;
if (BEZZLE_DEBUG == 1){
    printf( "  . Waiting for a remote connection ..." );
    fflush( stdout );
}
    if( ( ret = net_accept( listen_fd, &client_fd, NULL ) ) != 0 )
    {
if (BEZZLE_DEBUG == 1)
        printf( " failed\n  ! net_accept returned %d\n\n", ret );
        goto exit;
    }

    ssl_set_bio( &ssl, net_recv, &client_fd,
                       net_send, &client_fd );

if (BEZZLE_DEBUG == 1)
    printf( " ok\n" );

    /*
     * 5. Handshake
     */
if (BEZZLE_DEBUG == 1){
    printf( "  . Performing the SSL/TLS handshake..." );
    fflush( stdout );
}

    while( ( ret = ssl_handshake( &ssl ) ) != 0 )
    {
        if( ret != POLARSSL_ERR_NET_WANT_READ && ret != POLARSSL_ERR_NET_WANT_WRITE )
        {
if (BEZZLE_DEBUG == 1)
            printf( " failed\n  ! ssl_handshake returned %d\n\n", ret );
            goto reset;
        }
    }

if (BEZZLE_DEBUG == 1){
    printf( " ok\n" );

    /*
     * 6. Read the HTTP Request
     */
    printf( "  < Read from client:" );
    fflush( stdout );
}

    do
    {
        len = sizeof( buf ) - 1;
        memset( buf, 0, sizeof( buf ) );
        ret = ssl_read( &ssl, buf, len );

        if( ret == POLARSSL_ERR_NET_WANT_READ || ret == POLARSSL_ERR_NET_WANT_WRITE )
            continue;

if (BEZZLE_DEBUG == 1)
        if( ret <= 0 )
        {
            switch( ret )
            {
                case POLARSSL_ERR_SSL_PEER_CLOSE_NOTIFY:
                    printf( " connection was closed gracefully\n" );
                    break;

                case POLARSSL_ERR_NET_CONN_RESET:
                    printf( " connection was reset by peer\n" );
                    break;

                default:
                    printf( " ssl_read returned -0x%x\n", -ret );
                    break;
            }

            break;
        }

        len = ret;
if (BEZZLE_DEBUG == 1)
        printf( " %d bytes read\n\n%s", len, (char *) buf );

        if( ret > 0 && readNumber == 0)
	{

packetHash = realloc(packetHash, sizeof(char) * len + 1);
		if (!packetHash) {
if (BEZZLE_DEBUG == 1)
			printf("Realloc failed!\n");
			goto exit;
		}

sprintf(packetHash, "%s", (char *) buf);

		++readNumber;
	}
	else if (ret > 0 && readNumber == 1)
            break;
    }
    while( 1 );

		if (strcmp(packetHash, "localSearch") == 0)
		{
			/* now check database for response */

			char *response;
			response = malloc(sizeof(char));
			if (!response) {
if (BEZZLE_DEBUG == 1)
				printf("Realloc failed!\n");
				goto exit;
			}
			response[0]=0;

			char *command;

			command = malloc(sizeof(char) * (38 + strlen(buf)));

			if (!command) {
if (BEZZLE_DEBUG == 1)
				printf("Realloc failed!\n");
				goto exit;
			}

			sprintf(command, "SELECT * FROM data WHERE LookupKey=\"%s\"",buf);

 	     		rc = sqlite3_exec(serverDB, command, responseCallback, (void *) &response, &zErrMsg);
 	   	 	 if( rc!=SQLITE_OK ){
if (BEZZLE_DEBUG == 1)
 	  	 	    fprintf(stderr, "SQL error 5: %s\n", zErrMsg);
 			       goto exit;
 			     }

			if (response[0] != 0 && strlen(response) != 0)
				if (sendResponse(response, ssl, buf, len, ret) == 1 ) goto reset;
				else goto exit;

			ret = 0;
			goto reset;

		}
		else
		{

			/* check if the packetHash (with the time of sending) is already in the database */

			hashCommand = realloc(hashCommand, sizeof(char) * (36 + HASHSIZE));

			if (!hashCommand) {
if (BEZZLE_DEBUG == 1)
				printf("Realloc failed!\n");
				goto exit;
			}

			sprintf(hashCommand, "SELECT * FROM packets WHERE Hash=\"%s\"", packetHash);

*foundHash = -1;
			rc = sqlite3_exec(serverDB, hashCommand, hashCallback, (void *)foundHash, &zErrMsg);
      			if( rc!=SQLITE_OK )
			{
if (BEZZLE_DEBUG == 1)
        			fprintf(stderr, "SQL error 3: %s\n", zErrMsg);
				goto exit;
			
			}


			if (*foundHash == -1)
			{

				/*TODO: recalculate hash*/

				/*hash has not been found, so add it to the database*/
				char *addHashCommand;

				addHashCommand = malloc(sizeof(char) * (37 + strlen(packetHash)));

				if (!addHashCommand) {
if (BEZZLE_DEBUG == 1)
					printf("Realloc failed!\n");
					goto exit;
				}
				sprintf(addHashCommand, "INSERT INTO packets(Hash) VALUES(\"%s\")",packetHash);

				      rc = sqlite3_exec(serverDB, addHashCommand, insertCallback, 0, &zErrMsg);
				      if( rc!=SQLITE_OK ){
if (BEZZLE_DEBUG == 1)
				        fprintf(stderr, "SQL error 4: %s\n", zErrMsg);
        				goto exit;
				      }
				if (addHashCommand)
				free(addHashCommand);


if (BEZZLE_DEBUG == 1)
				printf("NOT FOUND IN DATABASE! QUERYING OTHERS.\n");

		      		userDataStruct *userData = malloc(sizeof(userDataStruct));
				userData->query = malloc(sizeof(char) * (len + 1));
				strcpy(userData->query, buf);
				userData->response = malloc(sizeof(char *));
				userData->numberOfResponses = 0;
				strcpy(userData->hexHash, packetHash);

		      		rc = sqlite3_exec(serverDB, "SELECT * FROM contacts", queryCallback, (void *) userData, &zErrMsg);
		      		if( rc!=SQLITE_OK ){
if (BEZZLE_DEBUG == 1)
		      		  fprintf(stderr, "SQL error 2: %s\n", zErrMsg);
					goto exit;
		      		}

				int responsesIterator;
				for (responsesIterator = 0; responsesIterator < userData->numberOfResponses; ++responsesIterator)
				{
					if (userData->response[0][0] != 0)
					{
if (BEZZLE_DEBUG == 1)
						printf("GOTRESPONSE: %s\n", userData->response[responsesIterator]);
						if (sendResponse(userData->response[0], ssl, buf, len, ret) == 1 ) goto reset;
						else goto exit;
						break;
					}
				}

				int totalResponses = userData->numberOfResponses;
				userData->numberOfResponses = 0;

		      		rc = sqlite3_exec(serverDB, "SELECT * FROM contacts", queryCallback2, (void *) userData, &zErrMsg);
		      		if( rc!=SQLITE_OK ){
if (BEZZLE_DEBUG == 1)
		      		  fprintf(stderr, "SQL error 2: %s\n", zErrMsg);
					goto exit;
		      		}


				for (responsesIterator = 0; responsesIterator < totalResponses; ++responsesIterator)
				{
					if (userData->response[0][0] != 0)
					{
if (BEZZLE_DEBUG == 1)
						printf("GOTRESPONSE: %s\n", userData->response[responsesIterator]);
						if (sendResponse(userData->response[0], ssl, buf, len, ret) == 1 ) goto reset;
						else goto exit;
						break;
					}
				}

				error:
		        	/* This will free zErrMsg if assigned */
		        	if (zErrMsg)
		        	   free(zErrMsg);

		    		ret = 0;
		    		goto reset;

			}
			else
			{
if (BEZZLE_DEBUG == 1)
{
			 printf("Already asked me!\n");
			 fflush(stdout);
}
		   	 ret = 0;
		  	  goto reset;
			}
		}

exit:
        		/* This will free zErrMsg if assigned */
if (zErrMsg)
				free(zErrMsg);
      sqlite3_close(serverDB);

#ifdef POLARSSL_ERROR_C
    if( ret != 0 )
    {
if (BEZZLE_DEBUG == 1){
        char error_buf[100];
        polarssl_strerror( ret, error_buf, 100 );
        printf("Last error was: %d - %s\n\n", ret, error_buf );
}
    }
#endif

    net_close( client_fd );
    x509_crt_free( &srvcert );
    pk_free( &pkey );
    ssl_free( &ssl );
#if defined(POLARSSL_SSL_CACHE_C)
    ssl_cache_free( &cache );
#endif
    entropy_free( &entropy );

#if defined(_WIN32)
    printf( "  Press Enter to exit this program.\n" );
    fflush( stdout ); getchar();
#endif

    return( ret );
}
#endif /* POLARSSL_BIGNUM_C && POLARSSL_CERTS_C && POLARSSL_ENTROPY_C &&
          POLARSSL_SSL_TLS_C && POLARSSL_SSL_SRV_C && POLARSSL_NET_C &&
          POLARSSL_RSA_C && POLARSSL_CTR_DRBG_C */
