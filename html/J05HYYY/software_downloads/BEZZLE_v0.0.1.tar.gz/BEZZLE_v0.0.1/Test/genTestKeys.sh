#!/bin/sh

generateKeys()
{
#1 name of contact without spaces

#generate a private key
../gen_key filename=keys/${1}.key

#create a certificate, containing a public key
../cert_write selfsign=1 issuer_name="O=${1}" issuer_key=keys/${1}.key
mv cert.crt keys/${1}.crt
}

#init the initial main database
../createInitialDatabase database

#make a folder for storing keys and certificates
mkdir keys

#add some test contacts, and create a database for each contact, and add a test value

#bob won't know the answer to "What is your name?"
../createInitialDatabase keys/bobDatabase
generateKeys bob
../addContact database bob 127.0.0.1 4433 ${PWD}/keys/bob.crt

../createInitialDatabase keys/coatDatabase
generateKeys coat
#coat will have the wrong certificate
../addContact database coat 127.0.0.8 4433 ${PWD}/keys/sun.crt
../addKeyValue keys/coatDatabase "What is your name?" "coat"

../createInitialDatabase keys/jimDatabase
generateKeys jim
#./addContact database jim 127.0.0.2 4433 ${PWD}/keys/jim.crt
../addKeyValue keys/jimDatabase "What is your name?" "jim"
#Jim does not know you, but knows twenty.

../createInitialDatabase keys/queerDatabase
generateKeys queer
../addContact database queer 127.0.0.5 4433 ${PWD}/keys/queer.crt
#this one is queer because it doesn't have an answer to the question.

../createInitialDatabase keys/twentyDatabase
generateKeys twenty
../addContact database twenty 127.0.0.6 4433 ${PWD}/keys/twenty.crt
../addContact keys/twentyDatabase jim 127.0.0.2 4433 ${PWD}/keys/jim.crt
../addContact keys/twentyDatabase hatty 127.0.0.3 4433 ${PWD}/keys/hatty.crt
#twenty doesn't have an answer to the question, but can ask jim and hatty.

../createInitialDatabase keys/hattyDatabase
generateKeys hatty
../addContact database hatty 127.0.0.3 4433 ${PWD}/keys/hatty.crt
../addKeyValue keys/hattyDatabase "What is your name?" "hatty"

../createInitialDatabase keys/sunDatabase
generateKeys sun
../addContact database sun 127.0.0.7 4433 ${PWD}/keys/sun.crt
../addKeyValue keys/sunDatabase "What is your name?" "sun"

../createInitialDatabase keys/aliceDatabase
generateKeys alice
../addContact database alice 127.0.0.4 4433 ${PWD}/keys/alice.crt
#alice is from wonderland so has some funky xml type tags for her name
../addKeyValue keys/aliceDatabase "What is your name?" "<mynameis>alice</thatsmyname>"
