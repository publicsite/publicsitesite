#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "xml.h"

int main(int argc, char *argv[])
{
char *encodedString = encodeXMLString(argv[1], strlen(argv[1]));
char *decodedString = decodeXMLString(encodedString, strlen(encodedString));

printf("%s\n", encodedString);
printf("%s\n", decodedString);
return 1;
}

