#!/bin/sh
../serverSide keys/bobDatabase keys/bob.crt keys/bob.key 127.0.0.1 4433 &
pid1=$!
../serverSide keys/jimDatabase keys/jim.crt keys/jim.key 127.0.0.2 4433 &
pid2=$!
../serverSide keys/hattyDatabase keys/hatty.crt keys/hatty.key 127.0.0.3 4433 &
pid3=$!
../serverSide keys/aliceDatabase keys/alice.crt keys/alice.key 127.0.0.4 4433 &
pid4=$!
../serverSide keys/queerDatabase keys/queer.crt keys/queer.key 127.0.0.5 4433 &
pid5=$!
../serverSide keys/twentyDatabase keys/twenty.crt keys/twenty.key 127.0.0.6 4433 &
pid6=$!
../serverSide keys/sunDatabase keys/sun.crt keys/sun.key 127.0.0.7 4433 &
pid7=$!
../serverSide keys/coatDatabase keys/coat.crt keys/coat.key 127.0.0.8 4433 &
pid8=$!
trap "kill -s TERM $pid1 $pid2 $pid3 $pid4 $pid5 $pid6 $pid7 $pid8; exit 1" 2
wait
