#!/bin/sh
gcc $1.c -o $1 -lpolarssl -lsqlite3
