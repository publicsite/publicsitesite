#include "debug.h"

#include "polarssl/net.h"
#include "polarssl/debug.h"
#include "polarssl/ssl.h"
#include "polarssl/entropy.h"
#include "polarssl/ctr_drbg.h"
#include "polarssl/error.h"
#include "polarssl/certs.h"

#include "polarssl/sha256.h"

#define HASHSIZE 8 * 32

typedef struct 
{
 char *query;
 char hexHash[HASHSIZE];
 char **response;
 int numberOfResponses;
} userDataStruct;

static void my_debug( void *ctx, int level, const char *str )
{
    ((void) level);

    fprintf( (FILE *) ctx, "%s", str );
    fflush(  (FILE *) ctx  );
}

int connectBySSL(userDataStruct *userData, char* contactIPAddress, int contactPort, char *contactCRTFile, int searchType)
{
    int ret, len, server_fd = -1;
    unsigned char buf[1024];
    const char *pers = "ssl_client1";

    entropy_context entropy;
    ctr_drbg_context ctr_drbg;
    ssl_context ssl;
    x509_crt cacert;

    /*
     * 0. Initialize the RNG and the session data
     */
    memset( &ssl, 0, sizeof( ssl_context ) );
    x509_crt_init( &cacert );

if (BEZZLE_DEBUG == 1){
    printf( "\n  . Seeding the random number generator..." );
    fflush( stdout );
}

    entropy_init( &entropy );
    if( ( ret = ctr_drbg_init( &ctr_drbg, entropy_func, &entropy,
                               (const unsigned char *) pers,
                               strlen( pers ) ) ) != 0 )
    {
if (BEZZLE_DEBUG == 1)
        printf( " failed\n  ! ctr_drbg_init returned %d\n", ret );
        goto exit;
    }

if (BEZZLE_DEBUG == 1)
    printf( " ok\n" );

    /*
     * 0. Initialize certificates
     */

if (BEZZLE_DEBUG == 1){
    printf( "  . Loading the CA root certificate ..." );
    fflush( stdout );
}

#if defined(POLARSSL_CERTS_C)
    ret = x509_crt_parse_file( &cacert, contactCRTFile );
#else
    ret = 1;
    printf("POLARSSL_CERTS_C not defined.");
#endif

    if( ret < 0 )
    {
if (BEZZLE_DEBUG == 1)
        printf( " failed\n  !  x509_crt_parse returned -0x%x\n\n", -ret );
        goto exit;
    }

if (BEZZLE_DEBUG == 1)
    printf( " ok (%d skipped)\n", ret );

    /*
     * 1. Start the connection
     */
if (BEZZLE_DEBUG == 1){
    printf( "  . Connecting to tcp/%s/%4d...", contactIPAddress,
                                               contactPort );
    fflush( stdout );
}

    if( ( ret = net_connect( &server_fd, contactIPAddress,
                                         contactPort ) ) != 0 )
    {
if (BEZZLE_DEBUG == 1)
        printf( " failed\n  ! net_connect returned %d\n\n", ret );
        goto exit;
    }

if (BEZZLE_DEBUG == 1){
    printf( " ok\n" );

    /*
     * 2. Setup stuff
     */
    printf( "  . Setting up the SSL/TLS structure..." );
    fflush( stdout );
}

    if( ( ret = ssl_init( &ssl ) ) != 0 )
    {
if (BEZZLE_DEBUG == 1)
        printf( " failed\n  ! ssl_init returned %d\n\n", ret );
        goto exit;
    }

if (BEZZLE_DEBUG == 1)
    printf( " ok\n" );

    ssl_set_endpoint( &ssl, SSL_IS_CLIENT );
    /* OPTIONAL is not optimal for security,
     * but makes interop easier in this simplified example */
    ssl_set_authmode( &ssl, SSL_VERIFY_REQUIRED );
    ssl_set_ca_chain( &ssl, &cacert, NULL, NULL );

    ssl_set_rng( &ssl, ctr_drbg_random, &ctr_drbg );
if (BEZZLE_DEBUG == 1)
    ssl_set_dbg( &ssl, my_debug, stdout );
    ssl_set_bio( &ssl, net_recv, &server_fd,
                       net_send, &server_fd );

    /*
     * 4. Handshake
     */
if (BEZZLE_DEBUG == 1){
    printf( "  . Performing the SSL/TLS handshake..." );
    fflush( stdout );
}

    while( ( ret = ssl_handshake( &ssl ) ) != 0 )
    {
        if( ret != POLARSSL_ERR_NET_WANT_READ && ret != POLARSSL_ERR_NET_WANT_WRITE )
        {
if (BEZZLE_DEBUG == 1)
            printf( " failed\n  ! ssl_handshake returned -0x%x\n\n", -ret );
            goto exit;
        }
    }

if (BEZZLE_DEBUG == 1)
    printf( " ok\n" );

    /*
     * 5. Verify the server certificate
     */
if (BEZZLE_DEBUG == 1)
    printf( "  . Verifying peer X.509 certificate..." );

    /* In real life, we may want to bail out when ret != 0 */

    if( ( ret = ssl_get_verify_result( &ssl ) ) != 0 )
    {
if (BEZZLE_DEBUG == 1){
        printf( " failed\n" );

        if( ( ret & BADCERT_EXPIRED ) != 0 )
            printf( "  ! server certificate has expired\n" );

        if( ( ret & BADCERT_REVOKED ) != 0 )
            printf( "  ! server certificate has been revoked\n" );

        if( ( ret & BADCERT_CN_MISMATCH ) != 0 )
            printf( "  ! CN mismatch (expected CN=%s)\n", "PolarSSL Server 1" );

        if( ( ret & BADCERT_NOT_TRUSTED ) != 0 )
            printf( "  ! self-signed or not signed by a trusted CA\n" );

        printf( "\n" );
}
    }
    else
if (BEZZLE_DEBUG == 1)
        printf( " ok\n" );

    /*
     * 3. Write the GET request
     */
if (BEZZLE_DEBUG == 1){
    printf( "  > Write hexHash or typelocal to server:" );
    fflush( stdout );
}

if (searchType == 1)
{
	/*global search, so send the hash*/
    len = sprintf( (char *) buf, "%s", userData->hexHash );
}
else
{
      len = sprintf( (char *) buf, "%s", "localSearch" );
}
    while( ( ret = ssl_write( &ssl, buf, len ) ) <= 0 )
    {
        if( ret != POLARSSL_ERR_NET_WANT_READ && ret != POLARSSL_ERR_NET_WANT_WRITE )
        {
if (BEZZLE_DEBUG == 1)
            printf( "Writing hexHash failed\n  ! ssl_write returned %d\n\n", ret );
            goto exit;
        }
    }

    len = ret;
if (BEZZLE_DEBUG == 1){
    printf( " %d bytes written\n\n%s", len, (char *) buf );

    printf( "  > Write to server:" );
    fflush( stdout );
}

    len = sprintf( (char *) buf, "%s", userData->query );

    while( ( ret = ssl_write( &ssl, buf, len ) ) <= 0 )
    {
        if( ret != POLARSSL_ERR_NET_WANT_READ && ret != POLARSSL_ERR_NET_WANT_WRITE )
        {
if (BEZZLE_DEBUG == 1)
            printf( "Writing  failed\n  ! ssl_write returned %d\n\n", ret );
            goto exit;
        }
    }

    len = ret;
if (BEZZLE_DEBUG == 1){
    printf( " %d bytes written\n\n%s", len, (char *) buf );

    /*
     * 7. Read the HTTP response
     */
    printf( "  < Read from server:" );
    fflush( stdout );
}

    do
    {
        len = sizeof( buf ) - 1;
        memset( buf, 0, sizeof( buf ) );
        ret = ssl_read( &ssl, buf, len );

        if( ret == POLARSSL_ERR_NET_WANT_READ || ret == POLARSSL_ERR_NET_WANT_WRITE )
            continue;

        if( ret == POLARSSL_ERR_SSL_PEER_CLOSE_NOTIFY )
            break;

        if( ret < 0 )
        {
if (BEZZLE_DEBUG == 1)
            printf( "failed\n  ! ssl_read returned %d\n\n", ret );
            break;
        }

        if( ret == 0 )
        {
if (BEZZLE_DEBUG == 1)
            printf( "\n\nEOF\n\n" );
            break;
        }

        len = ret;
if (BEZZLE_DEBUG == 1)
        printf( " %d bytes read\n\n%s", len, (char *) buf );

if (len > 0)
{
		char *bufDecoded = decodeXMLString(buf, len);
		userData->response[userData->numberOfResponses] = realloc(userData->response[userData->numberOfResponses], sizeof(char) * ( strlen(bufDecoded) + 13) );
		strcat(userData->response[userData->numberOfResponses], bufDecoded);
}

    }
    while( 1 );

    ssl_close_notify( &ssl );

exit:

#ifdef POLARSSL_ERROR_C
    if( ret != 0 )
    {
        char error_buf[100];
        polarssl_strerror( ret, error_buf, 100 );
if (BEZZLE_DEBUG == 1)
        printf("Last error was: %d - %s\n\n", ret, error_buf );
    }
#endif

    if( server_fd != -1 )
        net_close( server_fd );

    x509_crt_free( &cacert );
    ssl_free( &ssl );
    /* ctr_drbg_free( ctr_drbg ); */
    entropy_free( &entropy );

    memset( &ssl, 0, sizeof( ssl ) );

#if defined(_WIN32)
    printf( "  + Press Enter to exit this program.\n" );
    fflush( stdout ); getchar();
#endif



    return( ret );
}

    static int queryCallback(void *userDataVoid, int argc, char **argv, char **azColName){

	userDataStruct *userData = (userDataStruct *)userDataVoid;
if (BEZZLE_DEBUG == 1)
      printf("Asking %s \"%s\".\n", argv[1],  userData->query);

userData->response = realloc(userData->response, sizeof(char *) * (userData->numberOfResponses + 1));

		userData->response[userData->numberOfResponses] = malloc(sizeof(char));
		userData->response[userData->numberOfResponses][0]=0;

int ret = -1, retries = 0;
			while (ret < 0 && retries < 3)
			{			
				ret = connectBySSL(userData, argv[2], atoi(argv[3]), argv[4], 0);
				usleep(10);
				++retries;
			}
	++userData->numberOfResponses;

      return 0;
    }

    static int queryCallback2(void *userDataVoid, int argc, char **argv, char **azColName){

	userDataStruct *userData = (userDataStruct *)userDataVoid;

		if (userData->response[userData->numberOfResponses][0] == 0)
		{
if (BEZZLE_DEBUG == 1){
		      printf("Asking for a second time, %s \"%s\".\n", argv[1],  userData->query);
fflush(stdout);
}
			free(userData->response[userData->numberOfResponses]);
			userData->response[userData->numberOfResponses] = malloc(sizeof(char *));
			userData->response[userData->numberOfResponses][0]=0;
			int ret = -1, retries = 0;
			while (ret < 0 && retries < 3)
			{			
				ret = connectBySSL(userData, argv[2], atoi(argv[3]), argv[4], 1);
				usleep(10);
				++retries;
			}
		}
		else
		{
			free(userData->response[userData->numberOfResponses]);
			userData->response[userData->numberOfResponses] = malloc(sizeof(char *));
			userData->response[userData->numberOfResponses][0]=0;			
		}
	++userData->numberOfResponses;

      return 0;
    }
