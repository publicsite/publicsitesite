/*
 *  SSL client demonstration program
 *
 *  Copyright (C) 2006-2013, Brainspark B.V.
 *
 *  This file is part of PolarSSL (http://www.polarssl.org)
 *  Lead Maintainer: Paul Bakker <polarssl_maintainer at polarssl.org>
 *
 *  All rights reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#if !defined(POLARSSL_CONFIG_FILE)
#include "polarssl/config.h"
#else
#include POLARSSL_CONFIG_FILE
#endif

#include "debug.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "xml.h"
    #include <sqlite3.h>
#include "ssl_query.h"

#if !defined(POLARSSL_BIGNUM_C) || !defined(POLARSSL_ENTROPY_C) ||  \
    !defined(POLARSSL_SSL_TLS_C) || !defined(POLARSSL_SSL_CLI_C) || \
    !defined(POLARSSL_NET_C) || !defined(POLARSSL_RSA_C) ||         \
    !defined(POLARSSL_CTR_DRBG_C) || !defined(POLARSSL_X509_CRT_PARSE_C)

int main( int argc, char *argv[] )
{
    ((void) argc);
    ((void) argv);
if (BEZZLE_DEBUG == 1)
    printf("POLARSSL_BIGNUM_C and/or POLARSSL_ENTROPY_C and/or "
           "POLARSSL_SSL_TLS_C and/or POLARSSL_SSL_CLI_C and/or "
           "POLARSSL_NET_C and/or POLARSSL_RSA_C and/or "
           "POLARSSL_CTR_DRBG_C and/or POLARSSL_X509_CRT_PARSE_C "
           "not defined.\n");
    return( 0 );
}
#else

#define GET_REQUEST "GET / HTTP/1.0\r\n\r\n"

#if (BEZZLE_DEBUG == 1)
#define DEBUG_LEVEL 1
#endif

    static int insertCallback(void *NotUsed, int argc, char **argv, char **azColName){
      if (BEZZLE_DEBUG == 1){
      int i;
      for(i=0; i<argc; i++){
        printf("%s = %s\n", azColName[i], argv[i] ? argv[i]: "NULL");
      }
      printf("\n");
}
      return 0;
    }

int main( int argc, char *argv[] )
{

      sqlite3 *db;
      char *zErrMsg = 0;
      int rc;

	if ( argc != 3 )
	{
		printf("arg1 = databasefile query\n");
		return -1;
	}

      rc = sqlite3_open(argv[1], &db);
      if( rc ){
if (BEZZLE_DEBUG == 1)
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        exit(1);
      }

      userDataStruct *userData = malloc(sizeof(userDataStruct));

	userData->query = malloc(sizeof(char) * (strlen(argv[2]) + 1));
	strcpy(userData->query, argv[2]);

	userData->response = malloc(sizeof(char *));
	userData->numberOfResponses = 0;

/* first we add the hash to the packet list */
    char nonFormattedHash[32];

time_t theTime = time(0);
const time_t *theTimePtr = &theTime; 
    char *toHash = malloc(sizeof(char) * (strlen(argv[2]) + strlen(ctime(theTimePtr)) + 1));
    strcpy(toHash, argv[2]);
    strcat(toHash, ctime(theTimePtr));
    sha256(toHash, strlen(toHash), nonFormattedHash, 1 );


int i;
for(i = 0; i < 32; i++)
{
       sprintf(userData->hexHash, "%s%02x ", userData->hexHash, nonFormattedHash[i]);
}

char *command = malloc(sizeof(char) * (36 + sizeof(userData->hexHash)));
strcpy(command, "INSERT INTO packets(Hash) VALUES(");
strcat(command, "\"");
strcat(command, userData->hexHash);
strcat(command, "\")");

      rc = sqlite3_exec(db, command, insertCallback, 0, &zErrMsg);
      if( rc!=SQLITE_OK ){
if (BEZZLE_DEBUG == 1)
        fprintf(stderr, "SQL error 1: %s\n", zErrMsg);
        goto error;
      }

/*then ask each contact to do a local search*/

      rc = sqlite3_exec(db, "SELECT * FROM contacts", queryCallback, (void *) userData, &zErrMsg);
      if( rc!=SQLITE_OK ){
if (BEZZLE_DEBUG == 1)
        fprintf(stderr, "SQL error 2: %s\n", zErrMsg);
	goto error;
      }

	int responsesIterator;
	for (responsesIterator = 0; responsesIterator < userData->numberOfResponses; ++responsesIterator)
	{
		if (userData->response[responsesIterator][0] != 0)
		printf("%s\n", userData->response[responsesIterator]);
	}

/*then ask each contact that didn't respond with an answer, to do a deep search*/

	int totalResponses = userData->numberOfResponses;
	userData->numberOfResponses = 0;

      rc = sqlite3_exec(db, "SELECT * FROM contacts", queryCallback2, (void *) userData, &zErrMsg);
      if( rc!=SQLITE_OK ){
if (BEZZLE_DEBUG == 1)
        fprintf(stderr, "SQL error 2: %s\n", zErrMsg);
	goto error;
      }


      sqlite3_close(db);

	for (responsesIterator = 0; responsesIterator < totalResponses; ++responsesIterator)
	{
		if (userData->response[responsesIterator][0] != 0)
		printf("%s\n", userData->response[responsesIterator]);
	}

error:
        /* This will free zErrMsg if assigned */
        if (zErrMsg)
           free(zErrMsg);

    return 0;
}

#endif /* POLARSSL_BIGNUM_C && POLARSSL_ENTROPY_C && POLARSSL_SSL_TLS_C &&
          POLARSSL_SSL_CLI_C && POLARSSL_NET_C && POLARSSL_RSA_C &&
          POLARSSL_CTR_DRBG_C */
