#!/bin/sh
./compile.sh serverSide
./compile.sh clientSide
./compile.sh gen_key
./compile.sh createInitialDatabase
./compile.sh cert_write
./compile.sh addKeyValue
./compile.sh addContact
