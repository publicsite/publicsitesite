#include "debug.h"
    #include <stdio.h>
    #include <stdlib.h>
    #include <sqlite3.h>


    static int callback(void *NotUsed, int argc, char **argv, char **azColName){
      NotUsed=0;
      int i;
      for(i=0; i<argc; i++){
        printf("%s = %s\n", azColName[i], argv[i] ? argv[i]: "NULL");
      }
      printf("\n");
      return 0;
    }

    int main(int argc, char **argv){
      sqlite3 *db;
      char *zErrMsg = 0;
      int rc;

      if( argc!=2 ){
        fprintf(stderr, "Usage: %s DATABASE\n", argv[0]);
        exit(1);
      }
      rc = sqlite3_open(argv[1], &db);
      if( rc ){
if (BEZZLE_DEBUG == 1)
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        exit(1);
      }
      rc = sqlite3_exec(db, "CREATE TABLE contacts(PrimaryKey INTEGER PRIMARY KEY, Name TEXT, IPAddress TEXT, Port TEXT, Cert TEXT)", callback, 0, &zErrMsg);
      if( rc!=SQLITE_OK ){
if (BEZZLE_DEBUG == 1)
        fprintf(stderr, "SQL error: %s\n", zErrMsg);
        /* This will free zErrMsg if assigned */
        /*if (zErrMsg)
           free(zErrMsg);*/
      }
      rc = sqlite3_exec(db, "CREATE TABLE data(PrimaryKey INTEGER PRIMARY KEY, LookupKey TEXT, Value TEXT)", callback, 0, &zErrMsg);
      if( rc!=SQLITE_OK ){
if (BEZZLE_DEBUG == 1)
        fprintf(stderr, "SQL error: %s\n", zErrMsg);
        /* This will free zErrMsg if assigned */
        /*if (zErrMsg)
           free(zErrMsg);*/
      }
      rc = sqlite3_exec(db, "CREATE TABLE packets(PrimaryKey INTEGER PRIMARY KEY, Hash TEXT)", callback, 0, &zErrMsg);
      if( rc!=SQLITE_OK ){
if (BEZZLE_DEBUG == 1)
        fprintf(stderr, "SQL error: %s\n", zErrMsg);
        /* This will free zErrMsg if assigned */
      }
        if (zErrMsg)
           free(zErrMsg);
      sqlite3_close(db);
      return 0;
    }
