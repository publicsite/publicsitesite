#include <stdlib.h>
#include <stdio.h>
#include <gmp.h>

int main(int argc, char *argv[]){

	/* Converts from base 10 to any base(s)
		The first argument is the number to convert
		The second, third, fourth ... x is the bases for the numeral system
			eg. arguments: 100 2 2 2 2 2 2 2
			for the conversion of the number 100 to base 2
			(output: 1 1 0 0 1 0 0)

		TODO:
		Requre the labelling of arguments.
	*/

	if (argc < 2) return -1;

	mpz_t numberToConvert;
	mpz_init_set_str(numberToConvert, argv[1], 10);

	int variableBaseArrayCount = argc-2;
	mpz_t variableBaseArray[variableBaseArrayCount];
	mpz_t powers[variableBaseArrayCount];
	int indexOne, indexTwo;

	for( indexOne = 2; indexOne < argc; ++indexOne) mpz_init_set_str(variableBaseArray[indexOne-2], argv[indexOne], 10);
	
	mpz_t max;
	mpz_init_set_ui(max, 1);

	for( indexOne = 1; indexOne < variableBaseArrayCount; ++indexOne )
	{
		mpz_init_set_ui(powers[indexOne-1], 1);
		for ( indexTwo = indexOne; indexTwo < variableBaseArrayCount; ++indexTwo )
		mpz_mul(powers[indexOne-1], powers[indexOne-1], variableBaseArray[indexTwo]);
		mpz_mul(max, max, powers[indexOne-1]);
	}

	mpz_sub_ui(max, max, 1);

	mpz_init_set_ui(powers[variableBaseArrayCount-1], 1);

	if (mpz_cmp(numberToConvert, max) == 1)
	{
		gmp_printf("Cannot proceed - not enough bases specified to represent given number!\n(Max number is %Zd for these bases).\n", max);
		return -1;
	}

	mpz_t remainder;
	mpz_init_set(remainder, numberToConvert);

	mpz_t outputNumber[variableBaseArrayCount];

	for (indexOne = 0; indexOne < variableBaseArrayCount; ++indexOne ) mpz_init_set_ui(outputNumber[indexOne], 0);

	while (mpz_cmp_ui(remainder, 0) == 1)
	{
		short found = 0;
		for (indexOne = 0; indexOne < variableBaseArrayCount; ++indexOne)
		{
			mpz_t temp;
			mpz_init(temp);
			mpz_sub(temp, remainder, powers[indexOne]);
			if ( (mpz_cmp_ui(temp, 0) == 1) || (mpz_cmp_ui(temp, 0) == 0) )
			{
				mpz_sub(remainder, remainder, powers[indexOne]);
				mpz_add_ui(outputNumber[indexOne],outputNumber[indexOne],1);
				found = 1;
				break;
			}
			mpz_clear(temp);
		}
	}

	for (indexOne = 0; indexOne < variableBaseArrayCount; ++indexOne ) 
		if (indexOne < variableBaseArrayCount - 1) gmp_printf("%Zd ", outputNumber[indexOne]);
		else
		gmp_printf("%Zd\n",outputNumber[indexOne]);
	return 0;
}