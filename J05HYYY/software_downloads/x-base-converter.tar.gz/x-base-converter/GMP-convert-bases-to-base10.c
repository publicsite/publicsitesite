#include <stdlib.h>
#include <stdio.h>
#include <gmp.h>
#include <string.h>

int main(int argc, char *argv[]){

	/* converts from any base(s) into base 10 using GMP
		arguments are:
		--bases (followed by each base)
		--numbers (followed by numbers in said base)
		e.g.
		./convert-bases-to-base10 --bases 2 2 2 2 2 2 2 --numbers 1 1 0 0 1 0 0

		TODO:
		1) Check to see if each number is below given base.
	*/

	if (argc < 2) return -1;

	int numbersArrayCount = 0;
	int variableBaseArrayCount = 0;
	mpz_t *variableBaseArray = malloc(sizeof(mpz_t));
	mpz_t *numbersArray = malloc(sizeof(mpz_t));
	int indexOne, indexTwo;
	short type;

	if (strcmp(argv[1], "--bases") == 0) type = -1;
	else if (strcmp(argv[1], "--numbers") ==0) type = 1;
	else {
		printf("Please specify --bases and --numbers\n");
		return -1;
	}
		for( indexOne = 2; indexOne < argc; ++indexOne)
		{
			if (strcmp(argv[indexOne],"--numbers") == 0)
				if ( variableBaseArrayCount == 0 )
				{
					printf("No bases were specified!\n",indexOne);
					return -1;
				}
				else
				{
					if (indexOne + 1 < argc) ++indexOne;
					else
					{
						printf("No numbers were specified!\n");
						return -1;
					}
					type = 1;
				}

			if (strcmp(argv[indexOne], "--bases") == 0)
				if ( numbersArrayCount == 0 )
				{
					printf("No numbers were specified!\n");
					return -1;
				}
				else
				{
					if (indexOne + 1 < argc) ++indexOne;
					else
					{
						printf("No bases were specified!\n");
						return -1;
					}
					type = -1;
				}

			if (type == -1)
			{
				variableBaseArray = realloc(variableBaseArray, sizeof(mpz_t) * (variableBaseArrayCount + 1));
				mpz_init_set_str(variableBaseArray[variableBaseArrayCount], argv[indexOne], 10);
				++variableBaseArrayCount;
			}
			else
			{
				numbersArray = realloc(numbersArray, sizeof(mpz_t) * (numbersArrayCount + 1));
				mpz_init_set_str(numbersArray[numbersArrayCount], argv[indexOne], 10);
				++numbersArrayCount;
			}
		}

	if (numbersArrayCount > variableBaseArrayCount || variableBaseArrayCount == 0)
	{
		printf("Not enough bases specified for the conversion.\n");
		return -1;
	}

	if (numbersArrayCount == 0)
	{
		printf("No numbers specified for the conversion!\n");
		return -1;
	}
	

	mpz_t powers[variableBaseArrayCount];

	for( indexOne = 1; indexOne < variableBaseArrayCount; ++indexOne )
	{
		mpz_init_set_ui(powers[indexOne-1], 1);
		for ( indexTwo = indexOne; indexTwo < variableBaseArrayCount; ++indexTwo )
		mpz_mul(powers[indexOne-1], powers[indexOne-1], variableBaseArray[indexTwo]);
		/* gmp_printf("%Zd\n", powers[indexOne-1]); */
	}

	mpz_init_set_ui(powers[variableBaseArrayCount-1], 1);

	mpz_t number;
	mpz_init(number);

	for (indexOne = variableBaseArrayCount - numbersArrayCount; indexOne < variableBaseArrayCount; ++indexOne)
	{
		mpz_t temp;
		mpz_init(temp);
		mpz_mul(temp, powers[indexOne], numbersArray[indexOne-(variableBaseArrayCount - numbersArrayCount)]);
		mpz_add(number, number, temp);
		mpz_clear(temp);
	}

	gmp_printf("%Zd\n", number);

	return 0;
}