#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]){

	/* converts from any base(s) into base 10
		arguments are:
		--bases (followed by each base)
		--numbers (followed by numbers in said base)
		e.g.
		./convert-bases-to-base10 --bases 2 2 2 2 2 2 2 --numbers 1 1 0 0 1 0 0

		TODO:
		1) Check to see if each number is below given base.
	*/

	if (argc < 2) return -1;

	int numbersArrayCount = 0;
	int variableBaseArrayCount = 0;
	int *variableBaseArray = malloc(sizeof(int));
	int *numbersArray = malloc(sizeof(int));
	int indexOne, indexTwo;
	short type;

	if (strcmp(argv[1], "--bases") == 0) type = -1;
	else if (strcmp(argv[1], "--numbers") ==0) type = 1;
	else {
		printf("Please specify --bases and --numbers\n", argv[1]);
		return -1;
	}
		for( indexOne = 2; indexOne < argc; ++indexOne)
		{
			if (strcmp(argv[indexOne],"--numbers") == 0)
				if ( variableBaseArrayCount == 0 )
				{
					printf("No bases were specified!\n",indexOne);
					return -1;
				}
				else
				{
					if (indexOne + 1 < argc) ++indexOne;
					else
					{
						printf("No numbers were specified!\n");
						return -1;
					}
					type = 1;
				}

			if (strcmp(argv[indexOne], "--bases") == 0)
				if ( numbersArrayCount == 0 )
				{
					printf("No numbers were specified!\n");
					return -1;
				}
				else
				{
					if (indexOne + 1 < argc) ++indexOne;
					else
					{
						printf("No bases were specified!\n");
						return -1;
					}
					type = -1;
				}

			if (type == -1)
			{
				variableBaseArray = realloc(variableBaseArray, sizeof(int) * (variableBaseArrayCount + 1));
				variableBaseArray[variableBaseArrayCount] = atoi(argv[indexOne]);
				++variableBaseArrayCount;
			}
			else
			{
				numbersArray = realloc(numbersArray, sizeof(int) * (numbersArrayCount + 1));
				numbersArray[numbersArrayCount] = atoi(argv[indexOne]);
				++numbersArrayCount;
			}
		}

	if (numbersArrayCount > variableBaseArrayCount || variableBaseArrayCount == 0)
	{
		printf("Not enough bases specified for the conversion.\n");
		return -1;
	}

	if (numbersArrayCount == 0)
	{
		printf("No numbers specified for the conversion!\n");
		return -1;
	}
	

	int powers[variableBaseArrayCount];

	for( indexOne = 1; indexOne < variableBaseArrayCount; ++indexOne )
	{
		powers[indexOne-1] = 1;
		for ( indexTwo = indexOne; indexTwo < variableBaseArrayCount; ++indexTwo )
		powers[indexOne-1] = powers[indexOne-1] * variableBaseArray[indexTwo];
		 printf("%d\n",powers[indexOne-1]);
	}

	powers[variableBaseArrayCount-1] = 1;

	long number = 0;

	for (indexOne = variableBaseArrayCount - numbersArrayCount; indexOne < variableBaseArrayCount; ++indexOne)
	{
		number += powers[indexOne] * numbersArray[indexOne-(variableBaseArrayCount - numbersArrayCount)];
	}

	printf("%d\n",number);

	return 0;
}