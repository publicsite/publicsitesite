#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[]){

	/* Converts from base 10 to any base(s)
		The first argument is the number to convert
		The second, third, fourth ... x is the bases for the numeral system
			eg. arguments: 100 2 2 2 2 2 2 2
			for the conversion of the number 100 to base 2
			(output: 1 1 0 0 1 0 0)

		TODO:
		Requre the labelling of arguments.
	*/

	if (argc < 2) return -1;

	long numberToConvert = atol(argv[1]);
	int variableBaseArrayCount = argc-2;
	int variableBaseArray[variableBaseArrayCount];
	long powers[variableBaseArrayCount];
	int indexOne, indexTwo;

	for( indexOne = 2; indexOne < argc; ++indexOne) variableBaseArray[indexOne-2] = atoi(argv[indexOne]);
	
	long max = 1;

	for( indexOne = 1; indexOne < variableBaseArrayCount; ++indexOne )
	{
		powers[indexOne-1] = 1;
		for ( indexTwo = indexOne; indexTwo < variableBaseArrayCount; ++indexTwo )
		powers[indexOne-1] = powers[indexOne-1] * variableBaseArray[indexTwo];
		max *= powers[indexOne-1];
	}

	max -= 1;

	powers[variableBaseArrayCount-1] = 1;

	if ( numberToConvert > max)
	{
		printf("Cannot proceed - not enough bases specified to represent given number!\n(Max number is %d for these bases).\n", max);
		return -1;
	}

	long remainder = numberToConvert;

	int outputNumber[variableBaseArrayCount];

	for (indexOne = 0; indexOne < variableBaseArrayCount; ++indexOne ) outputNumber[indexOne] = 0;

	while (remainder > 0)
	{
		short found = 0;
		for (indexOne = 0; indexOne < variableBaseArrayCount; ++indexOne)
		if ( remainder - powers[indexOne] >= 0 )
		{
			remainder = remainder - powers[indexOne];
			++outputNumber[indexOne];
			found = 1;
			break;
		}
	}

	for (indexOne = 0; indexOne < variableBaseArrayCount; ++indexOne ) 
		if (indexOne < variableBaseArrayCount - 1) printf("%d ",outputNumber[indexOne]);
		else
		printf("%d\n",outputNumber[indexOne]);
	return 0;
}