/**
 * @file rtp.c
 * @brief Real-Time Protocol (RTP) demux module for VLC media player
 */
/*****************************************************************************
 * Copyright (C) 2001-2005 the VideoLAN team
 * Copyright © 2007-2009 Rémi Denis-Courmont
 * Copyright (C) 2013 J05HYYY
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 ****************************************************************************/

#include "outoftree1.h"

#include <libzrtp/zrtp.h>

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif
#include <stdarg.h>
#include <assert.h>
#include <errno.h>

#include <vlc_common.h>
#include <vlc_demux.h>
#include <vlc_network.h>
#include <vlc_plugin.h>
#include <vlc_dialog.h>

/*input.c extra headers*/
#include <vlc_block.h>
#include <limits.h>
#include <unistd.h>
#include <poll.h>

#include "rtp.h"

typedef struct testcon_t
{
int numOfZrtpInputStreams;
zrtp_session_t  *zrtp_session;
zrtp_stream_t *zrtp_streams[ZRTP_MAX_STREAMS_PER_SESSION];
int rtp_fd[ZRTP_MAX_STREAMS_PER_SESSION];
int zrtp_secured;
int fdsend;
} testcon_t;

typedef struct threadData
{
testcon_t safe_connection;
demux_t *demux;
} threadData;

int zrtpStreamID; 
zrtp_global_t *zrtp_global;          /* Persistent storage for libzrtp data */

static int on_send_packet(const zrtp_stream_t *stream, char *packet, unsigned int length)
{
	testcon_t* safe_connection = zrtp_stream_get_userdata(stream);
	int result = send( safe_connection->fdsend, packet, length, 0 );
return result;
}

static void on_zrtp_secure(zrtp_stream_t *stream, unsigned event){
		testcon_t* safe_connection = zrtp_stream_get_userdata(stream);
		safe_connection->zrtp_secured = 1;
}

/*from input.c - start*/
/**
 * Processes a packet received from the RTP socket.
 */
static void rtp_process (demux_t *demux, block_t *block)
{
    demux_sys_t *sys = demux->p_sys;

    if (block->i_buffer < 2)
        goto drop;
    const uint8_t ptype = rtp_ptype (block);
    if (ptype >= 72 && ptype <= 76)
        goto drop; /* Muxed RTCP, ignore for now FIXME */

    /* TODO: use SDP and get rid of this hack */
    if (unlikely(sys->autodetect))
    {   /* Autodetect payload type, _before_ rtp_queue() */
        rtp_autodetect (demux, sys->session, block);
        sys->autodetect = false;
    }

    rtp_queue (demux, sys->session, block);
    return;
drop:
    block_Release (block);
}

static int rtp_timeout (mtime_t deadline)
{
    if (deadline == VLC_TS_INVALID)
        return -1; /* infinite */

    mtime_t t = mdate ();
    if (t >= deadline)
        return 0;

    t = (deadline - t) / (CLOCK_FREQ / INT64_C(1000));
    if (unlikely(t > INT_MAX))
        return INT_MAX;
    return t;
}

/**
 * RTP/RTCP session thread for datagram sockets
 */
void *rtp_dgram_thread (void *opaque)
{
	threadData * theThreadData = (threadData *)opaque;
	demux_t * demux = (demux_t *)theThreadData->demux;
	demux_sys_t *sys = demux->p_sys;
	testcon_t safe_connection = (testcon_t)theThreadData->safe_connection;

    mtime_t deadline = VLC_TS_INVALID;

    int rtp_fd = sys->fd;

    struct pollfd ufd[1];
    ufd[0].fd = rtp_fd;
    ufd[0].events = POLLIN;

	int dontDequeue;

    for (;;)
    {

dontDequeue = 0;

        int n = poll (ufd, 1, rtp_timeout (deadline));

        if (n == -1)
            continue;

        int canc = vlc_savecancel ();

        if (n == 0)
            goto dequeue;

        if (ufd[0].revents)
        {
            n--;
            if (unlikely(ufd[0].revents & POLLHUP))
                break; /* RTP socket dead (DCCP only) */

            block_t *block = block_Alloc (0xffff); /* TODO: p_sys->mru */
            if (unlikely(block == NULL))
                break; /* we are totallly screwed */

		char *packet = malloc(sizeof(char) * 9999);
            unsigned int len = recv (rtp_fd, packet, 9999, 0);
if (len != -1)
{
            if (zrtp_process_srtp(safe_connection.zrtp_streams[zrtpStreamID],
 packet,
 &len) == zrtp_status_ok)
            {

	ZRTP_UNALIGNED(zrtp_rtp_hdr_t) rtp_hdr;

	memcpy(&rtp_hdr, packet, sizeof(zrtp_rtp_hdr_t));

union 
{ 
uint32_t ssrc32;
uint8_t ssrc8[4];
} ssrc;

ssrc.ssrc32 = zrtp_ntoh32(rtp_hdr.ssrc );

uint16_t seq = zrtp_ntoh16(rtp_hdr.seq );
uint32_t ts = zrtp_ntoh32(rtp_hdr.ts );

    block->i_buffer = (len - sizeof(zrtp_rtp_hdr_t)) + 12;

    block->p_buffer[0] = 0x80;
    block->p_buffer[1] = 142;
    block->p_buffer[2] = ( seq >> 8)&0xff;
    block->p_buffer[3] = ( seq     )&0xff;
    block->p_buffer[4] = ( ts >> 24 )&0xff;
    block->p_buffer[5] = ( ts >> 16 )&0xff;
    block->p_buffer[6] = ( ts >>  8 )&0xff;
    block->p_buffer[7] = ( ts       )&0xff;
    memcpy( block->p_buffer + 8, ssrc.ssrc8, 4 );

		memcpy(block->p_buffer + 12, packet + sizeof(zrtp_rtp_hdr_t), len - sizeof(zrtp_rtp_hdr_t));
                rtp_process (demux, block);
            }
}
            else
            {
		dontDequeue = 1;
                msg_Warn (demux, "RTP network error: %m");
                block_Release (block);
            }
free(packet);

        }

    dequeue:
	if (dontDequeue != 1)
	{
        	if (!rtp_dequeue (demux, sys->session, &deadline))
            	deadline = VLC_TS_INVALID;
        	vlc_restorecancel (canc);
	}

    }
    return NULL;
}

/**
 * RTP/RTCP session thread for stream sockets (framed RTP)
 */
void *rtp_stream_thread (void *opaque)
{
#ifndef WIN32
	threadData *theThreadData = opaque;
	demux_t * demux = (demux_t *)theThreadData->demux;
	demux_sys_t *sys = sys;
	testcon_t safe_connection = (testcon_t)theThreadData->safe_connection;

    int fd = sys->fd;

    for (;;)
    {
        /* There is no reordering on stream sockets, so no timeout. */
        ssize_t val;

        uint16_t frame_len;
	int result, len;
	result = recv (fd, &frame_len, 2, MSG_WAITALL);
	zrtp_process_srtp(safe_connection.zrtp_streams[zrtpStreamID], &frame_len, result);
        if (result != 2)
{
            break;
}
        block_t *block = block_Alloc (ntohs (frame_len));
        if (unlikely(block == NULL))
            break;

        block_cleanup_push (block);
        val = recv (fd, block->p_buffer, block->i_buffer, MSG_WAITALL);
	zrtp_process_srtp(safe_connection.zrtp_streams[zrtpStreamID], block->p_buffer, val);
        vlc_cleanup_pop ();

        if (val != (ssize_t)block->i_buffer)
        {
            block_Release (block);
            break;
        }

        int canc = vlc_savecancel ();
        rtp_process (demux, block);
        rtp_dequeue_force (demux, sys->session);
        vlc_restorecancel (canc);
    }
#else
    (void) opaque;
#endif
    return NULL;
}

/*from input.c end*/ 

#define PORT_TEXT N_("Outgoing port")
#define PORT_LONGTEXT N_( \
    "This allows you to specify the outgoing port for the ZRTP streaming." )
#define DEST_TEXT N_("Outgoing destination")
#define DEST_LONGTEXT N_( \
    "This is the outgoing URL that will be used." )
#define RTCP_PORT_TEXT N_("RTCP (local) port")
#define RTCP_PORT_LONGTEXT N_( \
    "RTCP packets will be received on this transport protocol port. " \
    "If zero, multiplexed RTP/RTCP is used.")

#define RTP_MAX_SRC_TEXT N_("Maximum RTP sources")
#define RTP_MAX_SRC_LONGTEXT N_( \
    "How many distinct active RTP sources are allowed at a time." )

#define RTP_TIMEOUT_TEXT N_("RTP source timeout (sec)")
#define RTP_TIMEOUT_LONGTEXT N_( \
    "How long to wait for any packet before a source is expired.")

#define RTP_MAX_DROPOUT_TEXT N_("Maximum RTP sequence number dropout")
#define RTP_MAX_DROPOUT_LONGTEXT N_( \
    "RTP packets will be discarded if they are too much ahead (i.e. in the " \
    "future) by this many packets from the last received packet." )

#define RTP_MAX_MISORDER_TEXT N_("Maximum RTP sequence number misordering")
#define RTP_MAX_MISORDER_LONGTEXT N_( \
    "RTP packets will be discarded if they are too far behind (i.e. in the " \
    "past) by this many packets from the last received packet." )

#define RTP_DYNAMIC_PT_TEXT N_("RTP payload format assumed for dynamic " \
                               "payloads")
#define RTP_DYNAMIC_PT_LONGTEXT N_( \
    "This payload format will be assumed for dynamic payload types " \
    "(between 96 and 127) if it can't be determined otherwise with " \
    "out-of-band mappings (SDP)" )

static const char *const dynamic_pt_list[] = { "theora" };
static const char *const dynamic_pt_list_text[] = { "Theora Encoded Video" };

static int  Open (vlc_object_t *);
static void Close (vlc_object_t *);

/*
 * Module descriptor
 */
vlc_module_begin ()
    set_shortname (N_("ZRTP"))
    set_description (N_("Real-Time Protocol (ZRTP) input"))
    set_category (CAT_INPUT)
    set_subcategory (SUBCAT_INPUT_DEMUX)
    set_capability ("access_demux", 0)
    set_callbacks (Open, Close)

    add_integer ("rtcp-port", 0, RTCP_PORT_TEXT,
                 RTCP_PORT_LONGTEXT, false)

    add_integer( "outgoing-port", 5004, PORT_TEXT,
                 PORT_LONGTEXT, true )

        change_integer_range (0, 65535)
        change_safe ()

    add_integer ("rtp-max-src", 1, RTP_MAX_SRC_TEXT,
                 RTP_MAX_SRC_LONGTEXT, true)
        change_integer_range (1, 255)
    add_integer ("rtp-timeout", 5, RTP_TIMEOUT_TEXT,
                 RTP_TIMEOUT_LONGTEXT, true)
    add_integer ("rtp-max-dropout", 3000, RTP_MAX_DROPOUT_TEXT,
                 RTP_MAX_DROPOUT_LONGTEXT, true)
        change_integer_range (0, 32767)
    add_integer ("rtp-max-misorder", 100, RTP_MAX_MISORDER_TEXT,
                 RTP_MAX_MISORDER_LONGTEXT, true)
        change_integer_range (0, 32767)
    add_string ("rtp-dynamic-pt", NULL, RTP_DYNAMIC_PT_TEXT,
                RTP_DYNAMIC_PT_LONGTEXT, true)
        change_string_list (dynamic_pt_list, dynamic_pt_list_text, NULL)

    add_string( "outgoing-dst", "", DEST_TEXT,
                DEST_LONGTEXT, true )
    /*add_shortcut ("sctp")*/
    add_shortcut ("dccp", "rtptcp", /* "tcp" is already taken :( */
                  "zrtp", "udplite")
vlc_module_end ()

/*
 * TODO: so much stuff
 * - send RTCP-RR and RTCP-BYE
 * - dynamic payload types (need SDP parser)
 * - multiple medias (need SDP parser, and RTCP-SR parser for lip-sync)
 * - support for stream_filter in case of stream_Demux (MPEG-TS)
 */

#ifndef IPPROTO_DCCP
# define IPPROTO_DCCP 33 /* IANA */
#endif

#ifndef IPPROTO_UDPLITE
# define IPPROTO_UDPLITE 136 /* from IANA */
#endif


/*
 * Local prototypes
 */
static int Control (demux_t *, int i_query, va_list args);
static int extract_port (char **phost);

/**
 * Probes and initializes.
 */
static int Open (vlc_object_t *obj)
{
    demux_t *demux = (demux_t *)obj;

    char *outgoing_dst = var_InheritString( obj, "outgoing-dst" );
    int outgoing_port = var_CreateGetInteger( obj, "outgoing-port" );

    int tp; /* transport protocol */

    if (!strcmp (demux->psz_access, "dccp"))
        tp = IPPROTO_DCCP;
    else
    if (!strcmp (demux->psz_access, "rtptcp"))
        tp = IPPROTO_TCP;
    else
    if (!strcmp (demux->psz_access, "zrtp"))
        tp = IPPROTO_UDP;
    else
    if (!strcmp (demux->psz_access, "udplite"))
        tp = IPPROTO_UDPLITE;
    else
        return VLC_EGENERIC;

    char *tmp = strdup (demux->psz_location);
    if (tmp == NULL)
        return VLC_ENOMEM;

    char *shost;
    char *dhost = strchr (tmp, '@');
    if (dhost != NULL)
    {
        *(dhost++) = '\0';
        shost = tmp;
    }
    else
    {
        dhost = tmp;
        shost = NULL;
    }

    /* Parses the port numbers */
    int sport = 0, dport = 0;
    if (shost != NULL)
        sport = extract_port (&shost);
    if (dhost != NULL)
        dport = extract_port (&dhost);
    if (dport == 0)
        dport = 5004; /* avt-profile-1 port */

    int rtcp_dport = var_CreateGetInteger (obj, "rtcp-port");

testcon_t safe_connection;          /* Secure channel instance */

char *temp = var_GetString( obj, "numOfZrtpInputStreams" );

if (temp != NULL )
{
	safe_connection.numOfZrtpInputStreams = atoi(temp);
	free(temp);
}
else safe_connection.numOfZrtpInputStreams = -1;

safe_connection.fdsend = -1;

    /* Try to connect */
    int fd = -1, rtcp_fd = -1;

    switch (tp)
    {
        case IPPROTO_UDP:
        case IPPROTO_UDPLITE:
	if (safe_connection.numOfZrtpInputStreams == -1 )
	{
		safe_connection.fdsend = net_ConnectDgram( obj, outgoing_dst,
                                           outgoing_port, -1, tp );
setsockopt (safe_connection.fdsend, SOL_SOCKET, SO_RCVBUF, &(int){ 0 },
                            sizeof (int));
}
            fd = net_OpenDgram (obj, dhost, dport, shost, sport, tp);
            if (fd == -1)
                break;
            if (rtcp_dport > 0) /* XXX: source port is unknown */
                rtcp_fd = net_OpenDgram (obj, dhost, rtcp_dport, shost, 0, tp);
            break;

         case IPPROTO_DCCP:
	if (safe_connection.numOfZrtpInputStreams == -1 )
	{
safe_connection.fdsend = net_ConnectDgram( obj, outgoing_dst,
                                           outgoing_port, -1, tp );
setsockopt (safe_connection.fdsend, SOL_SOCKET, SO_RCVBUF, &(int){ 0 },
                            sizeof (int));
}
#ifndef SOCK_DCCP /* provisional API (FIXME) */
# ifdef __linux__
#  define SOCK_DCCP 6
# endif
#endif
#ifdef SOCK_DCCP
            var_Create (obj, "dccp-service", VLC_VAR_STRING);
            var_SetString (obj, "dccp-service", "RTPV"); /* FIXME: RTPA? */
            fd = net_Connect (obj, dhost, dport, SOCK_DCCP, tp);
#else
            msg_Err (obj, "DCCP support not included");
#endif
            break;

        case IPPROTO_TCP:
	if (safe_connection.numOfZrtpInputStreams == -1 )
	{
		safe_connection.fdsend = net_Accept( obj, net_Listen( obj,
						outgoing_dst, outgoing_port,
						SOCK_STREAM,
						tp ) );
		setsockopt (safe_connection.fdsend, SOL_SOCKET, SO_RCVBUF, &(int){ 0 },
                            sizeof (int));
	}
            fd = net_Connect (obj, dhost, dport, SOCK_STREAM, tp);
            break;
    }

#if 0 /* No payload formats sets this at the moment */
    int cscov = -1;
    if( cscov != -1 )
        cscov += 8 /* UDP */ + 12 /* RTP */;
    if( id->sinkc > 0 )
        net_SetCSCov( safe_connection.fdsend, cscov, -1 );
#endif

    free (tmp);
    if (fd == -1)
        return VLC_EGENERIC;
    net_SetCSCov (fd, -1, 12);

    /* Initializes demux */
    demux_sys_t *p_sys = malloc (sizeof (*p_sys));
    if (p_sys == NULL)
    {
        net_Close (fd);
        if (rtcp_fd != -1)
            net_Close (rtcp_fd);
        return VLC_EGENERIC;
    }

    p_sys->fd           = fd;
    p_sys->rtcp_fd      = rtcp_fd;
    p_sys->max_src      = var_CreateGetInteger (obj, "rtp-max-src");
    p_sys->timeout      = var_CreateGetInteger (obj, "rtp-timeout")
                        * CLOCK_FREQ;
    p_sys->max_dropout  = var_CreateGetInteger (obj, "rtp-max-dropout");
    p_sys->max_misorder = var_CreateGetInteger (obj, "rtp-max-misorder");
    p_sys->thread_ready = false;
    p_sys->autodetect   = true;

    demux->pf_demux   = NULL;
    demux->pf_control = Control;
    demux->p_sys      = p_sys;

    p_sys->session = rtp_session_create (demux);
    if (p_sys->session == NULL)
        goto error;

uint32_t zrtp_ssrc;
vlc_rand_bytes (&zrtp_ssrc, sizeof (uint32_t));

		zrtp_status_t s = zrtp_status_ok;

	if (safe_connection.numOfZrtpInputStreams == -1 )
	{
		zrtp_config_t zrtp_config;
		zrtp_string128_t zstr_cache_path;

		/* Initialize zrtp config with default values */
		zrtp_config_defaults(&zrtp_config);
	
		/* Generate random ZID and copy it to libzrtp config */
		zrtp_zid_t zid;
		zrtp_randstr2(zid, sizeof(zid));
		zrtp_memcpy(zrtp_config.zid, zid, sizeof(zrtp_zid_t));

		/** Make some adjustments:
		 * - Set Client ID to identify ourself
		 * - Set appropriate license mode
		 * - We going to use  default zrtp cache implementation, so let's specify cache file path
		 */
		strcpy(zrtp_config.client_id, "Client");
		zrtp_config.lic_mode = ZRTP_LICENSE_MODE_UNLIMITED;
		zrtp_zstrcpyc( ZSTR_GV(zstr_cache_path), "/tmp/zrtp");

		/* Define interface callback functions */
		zrtp_config.cb.misc_cb.on_send_packet           = on_send_packet;
		zrtp_config.cb.event_cb.on_zrtp_secure          = on_zrtp_secure;
		//zrtp_config.cb.event_cb.on_zrtp_security_event  = on_zrtp_event;

		/* Everything is ready - initialize libzrtp. */        
		s = zrtp_init(&zrtp_config, &zrtp_global);
		if (zrtp_status_ok != s) {
			// Check error code and debug logs  
		}

		/* The library has been initialized and is ready to use

		*
		* Allocate zrtp session with default parameters
		*
		*/

		zrtp_signaling_role_t role;

		s = zrtp_session_init(zrtp_global, NULL, role, &safe_connection.zrtp_session);

		if (zrtp_status_ok != s) {
		    /* Check error code and debug logs */
		}

	/* Set call-back pointer to our parent structure */
	zrtp_session_set_userdata(safe_connection.zrtp_session, &safe_connection); // the NULL here is void *udata

		safe_connection.numOfZrtpInputStreams = -1;
	}

	++safe_connection.numOfZrtpInputStreams;

	var_Create(obj, "numOfZrtpInputStreams", VLC_VAR_STRING);
char tmpstr[8];
sprintf(tmpstr, "%d", safe_connection.numOfZrtpInputStreams);
	var_SetString( obj, "numOfZrtpInputStreams", tmpstr );

	zrtpStreamID = safe_connection.numOfZrtpInputStreams;

	safe_connection.rtp_fd[zrtpStreamID] = fd;

	safe_connection.zrtp_secured = -1;

	// Attach Stream
	s = zrtp_stream_attach(safe_connection.zrtp_session, &safe_connection.zrtp_streams[zrtpStreamID]);
	if (zrtp_status_ok != s) {
	    // Check error code and debug logs
	}

	zrtp_stream_set_userdata(safe_connection.zrtp_streams[zrtpStreamID], &safe_connection); //and again, the NULL here is void *udata

		zrtp_stream_start(safe_connection.zrtp_streams[zrtpStreamID], zrtp_ssrc);

		//zrtp_stream_secure(safe_connection.zrtp_streams[zrtpStreamID]);

    mtime_t deadline = VLC_TS_INVALID;
    struct pollfd ufd[1];
    ufd[0].fd = fd;
    ufd[0].events = POLLIN;

		while (safe_connection.zrtp_secured == -1){
		char *packet = malloc(sizeof(char) * 9999);
        poll (ufd, 1, rtp_timeout (deadline));
        if (ufd[0].revents)
        {
			//recieve the initiation packets
			int err = -1;
			err = recv (safe_connection.rtp_fd[zrtpStreamID], packet, 9999, 0);
if (err != -1)
				zrtp_process_srtp(safe_connection.zrtp_streams[zrtpStreamID], packet, &err);
}
		free(packet);
		}

	threadData *theThreadData = malloc(sizeof(threadData));
	theThreadData->demux = demux;
	theThreadData->safe_connection = safe_connection;

if(vlc_clone (&p_sys->thread,
                   (tp != IPPROTO_TCP) ? rtp_dgram_thread : rtp_stream_thread,
                   theThreadData, VLC_THREAD_PRIORITY_INPUT))
	goto error;
    p_sys->thread_ready = true;
    return VLC_SUCCESS;

error:
    Close (obj);
    return VLC_EGENERIC;
}


/**
 * Releases resources
 */
static void Close (vlc_object_t *obj)
{
    demux_t *demux = (demux_t *)obj;
    demux_sys_t *p_sys = demux->p_sys;

    if (p_sys->thread_ready)
    {
        vlc_cancel (p_sys->thread);
        vlc_join (p_sys->thread, NULL);
    }

    if (p_sys->session)
        rtp_session_destroy (demux, p_sys->session);
    if (p_sys->rtcp_fd != -1)
        net_Close (p_sys->rtcp_fd);
    net_Close (p_sys->fd);
    free (p_sys);
}


/**
 * Extracts port number from "[host]:port" or "host:port" strings,
 * and remove brackets from the host name.
 * @param phost pointer to the string upon entry,
 * pointer to the hostname upon return.
 * @return port number, 0 if missing.
 */
static int extract_port (char **phost)
{
    char *host = *phost, *port;

    if (host[0] == '[')
    {
        host = ++*phost; /* skip '[' */
        port = strchr (host, ']');
        if (port)
            *port++ = '\0'; /* skip ']' */
    }
    else
        port = strchr (host, ':');

    if (port == NULL)
        return 0;
    *port++ = '\0'; /* skip ':' */
    return atoi (port);
}


/**
 * Control callback
 */
static int Control (demux_t *demux, int i_query, va_list args)
{
    switch (i_query)
    {
        case DEMUX_GET_POSITION:
        {
            float *v = va_arg (args, float *);
            *v = 0.;
            return VLC_SUCCESS;
        }

        case DEMUX_GET_LENGTH:
        case DEMUX_GET_TIME:
        {
            int64_t *v = va_arg (args, int64_t *);
            *v = 0;
            return VLC_SUCCESS;
        }

        case DEMUX_GET_PTS_DELAY:
        {
            int64_t *v = va_arg (args, int64_t *);
            *v = INT64_C(1000) * var_InheritInteger (demux, "network-caching");
            return VLC_SUCCESS;
        }

        case DEMUX_CAN_PAUSE:
        case DEMUX_CAN_SEEK:
        case DEMUX_CAN_CONTROL_PACE:
        {
            bool *v = (bool*)va_arg( args, bool * );
            *v = false;
            return VLC_SUCCESS;
        }
    }

    return VLC_EGENERIC;
}


/*
 * Generic packet handlers
 */

void *codec_init (demux_t *demux, es_format_t *fmt)
{
    return es_out_Add (demux->out, fmt);
}

void codec_destroy (demux_t *demux, void *data)
{
    if (data)
        es_out_Del (demux->out, (es_out_id_t *)data);
}

/* Send a packet to decoder */
void codec_decode (demux_t *demux, void *data, block_t *block)
{
    if (data)
    {
        block->i_dts = VLC_TS_INVALID; /* RTP does not specify this */
        es_out_Control (demux->out, ES_OUT_SET_PCR, block->i_pts );
        es_out_Send (demux->out, (es_out_id_t *)data, block);
    }
    else
        block_Release (block);
}

static void *stream_init (demux_t *demux, const char *name)
{
    return stream_DemuxNew (demux, name, demux->out);
}

static void stream_destroy (demux_t *demux, void *data)
{
    if (data)
        stream_Delete ((stream_t *)data);
    (void)demux;
}

/* Send a packet to a chained demuxer */
static void stream_decode (demux_t *demux, void *data, block_t *block)
{
    if (data)
        stream_DemuxSend ((stream_t *)data, block);
    else
        block_Release (block);
    (void)demux;
}

static void *demux_init (demux_t *demux)
{
    return stream_init (demux, demux->psz_demux);
}

/*
 * Static payload types handler
 */

/* PT=0
 * PCMU: G.711 µ-law (RFC3551)
 */
static void *pcmu_init (demux_t *demux)
{
    es_format_t fmt;

    es_format_Init (&fmt, AUDIO_ES, VLC_CODEC_MULAW);
    fmt.audio.i_rate = 8000;
    fmt.audio.i_channels = 1;
    return codec_init (demux, &fmt);
}

/* PT=3
 * GSM
 */
static void *gsm_init (demux_t *demux)
{
    es_format_t fmt;

    es_format_Init (&fmt, AUDIO_ES, VLC_CODEC_GSM);
    fmt.audio.i_rate = 8000;
    fmt.audio.i_channels = 1;
    return codec_init (demux, &fmt);
}

/* PT=8
 * PCMA: G.711 A-law (RFC3551)
 */
static void *pcma_init (demux_t *demux)
{
    es_format_t fmt;

    es_format_Init (&fmt, AUDIO_ES, VLC_CODEC_ALAW);
    fmt.audio.i_rate = 8000;
    fmt.audio.i_channels = 1;
    return codec_init (demux, &fmt);
}

/* PT=10,11
 * L16: 16-bits (network byte order) PCM
 */
static void *l16s_init (demux_t *demux)
{
    es_format_t fmt;

    es_format_Init (&fmt, AUDIO_ES, VLC_CODEC_S16B);
    fmt.audio.i_rate = 44100;
    fmt.audio.i_channels = 2;
    return codec_init (demux, &fmt);
}

static void *l16m_init (demux_t *demux)
{
    es_format_t fmt;

    es_format_Init (&fmt, AUDIO_ES, VLC_CODEC_S16B);
    fmt.audio.i_rate = 44100;
    fmt.audio.i_channels = 1;
    return codec_init (demux, &fmt);
}

/* PT=12
 * QCELP
 */
static void *qcelp_init (demux_t *demux)
{
    es_format_t fmt;

    es_format_Init (&fmt, AUDIO_ES, VLC_CODEC_QCELP);
    fmt.audio.i_rate = 8000;
    fmt.audio.i_channels = 1;
    return codec_init (demux, &fmt);
}

/* PT=14
 * MPA: MPEG Audio (RFC2250, §3.4)
 */
static void *mpa_init (demux_t *demux)
{
    es_format_t fmt;

    es_format_Init (&fmt, AUDIO_ES, VLC_CODEC_MPGA);
    fmt.audio.i_channels = 2;
    fmt.b_packetized = false;
    return codec_init (demux, &fmt);
}

static void mpa_decode (demux_t *demux, void *data, block_t *block)
{
    if (block->i_buffer < 4)
    {
        block_Release (block);
        return;
    }

    block->i_buffer -= 4; /* 32-bits RTP/MPA header */
    block->p_buffer += 4;

    codec_decode (demux, data, block);
}


/* PT=32
 * MPV: MPEG Video (RFC2250, §3.5)
 */
static void *mpv_init (demux_t *demux)
{
    es_format_t fmt;

    es_format_Init (&fmt, VIDEO_ES, VLC_CODEC_MPGV);
    fmt.b_packetized = false;
    return codec_init (demux, &fmt);
}

static void mpv_decode (demux_t *demux, void *data, block_t *block)
{
    if (block->i_buffer < 4)
    {
        block_Release (block);
        return;
    }

    block->i_buffer -= 4; /* 32-bits RTP/MPV header */
    block->p_buffer += 4;
#if 0
    if (block->p_buffer[-3] & 0x4)
    {
        /* MPEG2 Video extension header */
        /* TODO: shouldn't we skip this too ? */
    }
#endif
    codec_decode (demux, data, block);
}


/* PT=33
 * MP2: MPEG TS (RFC2250, §2)
 */
static void *ts_init (demux_t *demux)
{
    return stream_init (demux, *demux->psz_demux ? demux->psz_demux : "ts");
}


/* Not using SDP, we need to guess the payload format used */
/* see http://www.iana.org/assignments/rtp-parameters */
void rtp_autodetect (demux_t *demux, rtp_session_t *session,
                     const block_t *block)
{
    uint8_t ptype = rtp_ptype (block);
    rtp_pt_t pt = {
        .init = NULL,
        .destroy = codec_destroy,
        .decode = codec_decode,
        .frequency = 0,
        .number = ptype,
    };

    /* Remember to keep this in sync with modules/services_discovery/sap.c */
    switch (ptype)
    {
      case 0:
        msg_Dbg (demux, "detected G.711 mu-law");
        pt.init = pcmu_init;
        pt.frequency = 8000;
        break;

      case 3:
        msg_Dbg (demux, "detected GSM");
        pt.init = gsm_init;
        pt.frequency = 8000;
        break;

      case 8:
        msg_Dbg (demux, "detected G.711 A-law");
        pt.init = pcma_init;
        pt.frequency = 8000;
        break;

      case 10:
        msg_Dbg (demux, "detected stereo PCM");
        pt.init = l16s_init;
        pt.frequency = 44100;
        break;

      case 11:
        msg_Dbg (demux, "detected mono PCM");
        pt.init = l16m_init;
        pt.frequency = 44100;
        break;

      case 12:
        msg_Dbg (demux, "detected QCELP");
        pt.init = qcelp_init;
        pt.frequency = 8000;
        break;

      case 14:
        msg_Dbg (demux, "detected MPEG Audio");
        pt.init = mpa_init;
        pt.decode = mpa_decode;
        pt.frequency = 90000;
        break;

      case 32:
        msg_Dbg (demux, "detected MPEG Video");
        pt.init = mpv_init;
        pt.decode = mpv_decode;
        pt.frequency = 90000;
        break;

      case 33:
        msg_Dbg (demux, "detected MPEG2 TS");
        pt.init = ts_init;
        pt.destroy = stream_destroy;
        pt.decode = stream_decode;
        pt.frequency = 90000;
        break;

      default:
        /*
         * If the rtp payload type is unknown then check demux if it is specified
         */
        if (!strcmp(demux->psz_demux, "h264")
         || !strcmp(demux->psz_demux, "ts"))
        {
            msg_Dbg (demux, "dynamic payload format %s specified by demux",
                     demux->psz_demux);
            pt.init = demux_init;
            pt.destroy = stream_destroy;
            pt.decode = stream_decode;
            pt.frequency = 90000;
            break;
        }
        if (ptype >= 96)
        {
            char *dynamic = var_InheritString(demux, "rtp-dynamic-pt");
            if (dynamic == NULL)
                ;
            else if (!strcmp(dynamic, "theora"))
            {
                msg_Dbg (demux, "assuming Theora Encoded Video");
                pt.init = theora_init;
                pt.destroy = xiph_destroy;
                pt.decode = xiph_decode;
                pt.frequency = 90000;
            }
            else
                msg_Err (demux, "unknown dynamic payload format `%s' "
                                "specified", dynamic);
            free (dynamic);
        }

        msg_Err (demux, "unspecified payload format (type %"PRIu8")", ptype);
        msg_Info (demux, "A valid SDP is needed to parse this RTP stream.");
        dialog_Fatal (demux, N_("SDP required"),
             N_("A description in SDP format is required to receive the RTP "
                "stream. Note that rtp:// URIs cannot work with dynamic "
                "RTP payload format (%"PRIu8")."), ptype);
        return;
    }
    rtp_add_type (demux, session, &pt);
}

/*
 * Dynamic payload type handlers
 * Hmm, none implemented yet apart from Xiph ones.
 */
