/*****************************************************************************
 * Copyright (C) 2013 J05HYYY
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
 *****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]){

if (argc < 2)
{
printf("Please enter the number you want to go up to.\n");
return -1;
}

	int **factors = malloc(sizeof(int **));
	int *numberOfFactors =  malloc(sizeof(int));
	int **pointers = malloc(sizeof(int **));
	int *numberOfPointers = malloc(sizeof(int));

	int i;

	int workingNumber; /* first prime after 2 */
	for (workingNumber = 3; workingNumber <= atoi(argv[1]); ++workingNumber)
	{

		int current = 1;

		printf("%d: ",workingNumber);

		factors = realloc(factors, sizeof(int *) * (workingNumber-2));
			if ( factors == NULL ) exit(-1);
		pointers = realloc(pointers, sizeof(int *) * (workingNumber-2));
			if ( pointers == NULL ) exit(-1);
		numberOfFactors = realloc(numberOfFactors, (workingNumber-2) * sizeof(int));
			if ( numberOfFactors == NULL ) exit(-1);
		numberOfPointers = realloc(numberOfPointers, sizeof(int) * (workingNumber-2));
			if ( numberOfPointers == NULL ) exit(-1);

		numberOfFactors[workingNumber-3] = 0;
		numberOfPointers[workingNumber-3] = 0;

		int number = workingNumber;
		int max;
		for (max=number/2; max > 1; --max) /* if number is odd, it'll get rounded down */
		{
			if ( current * max <= workingNumber && number % max == 0 ) /* if remainder is 0 */
			{
				if (max-3 < 0 || ( numberOfFactors[max-3] == 0 && numberOfPointers[max-3] == 0 ))
				{
					/* max is a prime */
					if ( numberOfFactors[number-3] == 0 ) factors[number-3] = malloc(sizeof(int));
					else factors[number-3] = realloc(factors[number-3], (numberOfFactors[number-3] + 1) * sizeof(int));
					factors[number-3][numberOfFactors[number-3]] = max; /* add to the list of factors */
					++numberOfFactors[number-3];
					current *= max;
					printf("%d, ",max);

					if ((number/max)-3 < 0 || ( numberOfFactors[(number/max)-3] == 0 && numberOfPointers[(number/max)-3] == 0 )) /* if pair is prime too */
					{
						factors[number-3] = realloc(factors[number-3], (numberOfFactors[number-3] + 1) * sizeof(int));
						factors[number-3][numberOfFactors[number-3]] = number/max; /* add to the list of factors */
						++numberOfFactors[number-3];
						current *= max;
						printf("%d, ",number/max);

						max = number/max; /* to quicken algorithm up! */
					}
				}
				else
				{
					/* max points to some other number (which may or may not be prime) */

					if ( numberOfFactors[number-3] == 0 ) factors[number-3] = malloc( numberOfFactors[max-3] * sizeof(int));
					factors[number-3] = realloc(factors[number-3], (numberOfFactors[number-3] + numberOfFactors[max-3]) * sizeof(int));
					
					for (i=0; i < numberOfFactors[max-3]; ++i)
					{
						factors[number-3][numberOfFactors[number-3]] = factors[max-3][i];
						printf("%d, ",factors[max-3][i]);
						current *= factors[max-3][i];
						++numberOfFactors[number-3];
					}

				}
			}
		}

		printf("\n");
	}

return 1;
}