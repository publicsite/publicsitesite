#!/bin/sh
# Copyright (C) 2025 J05HYYY

OLD_UMASK="$(umask)"
umask 0022

CROSSTOOL_FILENAME=crosstool-ng-1.20.0.tar.bz2
wget http://crosstool-ng.org/download/crosstool-ng/$CROSSTOOL_FILENAME
tar xvjf $CROSSTOOL_FILENAME
cd crosstool-ng*
##DO NOT INSTALL CROSSTOOL_NG, RUN IT LOCALLY##
./configure --enable-local
make
cd ..

umask "${OLD_UMASK}"