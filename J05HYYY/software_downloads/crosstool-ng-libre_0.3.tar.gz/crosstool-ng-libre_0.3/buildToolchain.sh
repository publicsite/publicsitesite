#!/bin/sh
# Copyright (C) 2025 J05HYYY

OLD_UMASK="$(umask)"
umask 0022

cd crosstool-ng*
CT_DEBUG_CT=y CT_DEBUG_CT_SAVE_STEPS=y CT_DEBUG_CT_SAVE_STEPS_GZIP=y ./ct-ng build
cd ..

umask "${OLD_UMASK}"