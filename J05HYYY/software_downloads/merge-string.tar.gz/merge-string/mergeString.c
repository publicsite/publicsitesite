/*****************************************************************************
 * Copyright (C) 2013 J05HYYY
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
 *****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]){

	if (argc < 2)
	{
		printf("mergeString requires two strings for input.");
		return -1;
	}

	int lengthOne = strlen(argv[1]), lengthTwo = strlen(argv[2]);
	char myStringOne[lengthOne];
	char myStringTwo[lengthTwo];

	memcpy(myStringOne, argv[1], lengthOne);
	memcpy(myStringTwo, argv[2], lengthTwo);

	int indexOne, indexTwo, indexThree, indexFour;

	char *from = malloc(sizeof(char));
	char *to = malloc(sizeof(char));

	int *ruleStart = malloc(sizeof(int));
	int *ruleEnd = malloc(sizeof(int));
	int *numerator = malloc(sizeof(int));
	int *denominator = malloc(sizeof(int));
	short *ruleFound = malloc(sizeof(short));
	int ruleCount = 0;
	int totalNumberMatching = 0;

	/*GET 'RULES'*/
	for (indexOne = 0; indexOne < lengthOne; ++indexOne)
	{
		int count = 0, count2;
		short *foundIt = malloc(sizeof(short));

		/*GENERATE PATTERNS FOR A*/
		for (indexTwo = 0; indexTwo < lengthOne; ++indexTwo)
		{
			if (indexTwo != indexOne)
			{
				foundIt = realloc(foundIt, sizeof(short) * (count+1));
				from = realloc(from, sizeof(char) * ( count + 1 ));
				to = realloc(to, sizeof(char) * ( count + 1 ));
				if (indexOne < indexTwo)
				{
					from[count] = myStringOne[indexOne];
					to[count] = myStringOne[indexTwo];
				}
				else
				{
					from[count] = myStringOne[indexTwo];
					to[count] = myStringOne[indexOne];
				}

				++count;
			}
		}

		/*GENERATE PATTERNS FOR B*/
		for (indexTwo = 0; indexTwo < lengthTwo; ++indexTwo)
		{

			for (indexThree = 0; indexThree < count; ++indexThree) foundIt[indexThree] = 0;

			int numberMatching = 0;
			count2 = 0;

			for (indexThree = 0; indexThree < lengthTwo; ++indexThree)
			{
				if (indexThree != indexTwo)
				{
					++count2;

					for (indexFour = 0; indexFour < count; ++indexFour)
					{
						if (indexTwo < indexThree)
						{
							if (foundIt[indexFour] == 0 && from[indexFour] == myStringTwo[indexTwo] && to[indexFour] == myStringTwo[indexThree])
							{
								foundIt[indexFour] = 1;
								++numberMatching;
								++totalNumberMatching;
								break;
							}
						}
						else if (foundIt[indexFour] == 0 && from[indexFour] == myStringTwo[indexThree] && to[indexFour] == myStringTwo[indexTwo])
						{
							foundIt[indexFour] = 1;
							++numberMatching;
							++totalNumberMatching;
							break;
						}
					}
				}
			}

			if (numberMatching > 0)	
			{
				ruleStart = realloc(ruleStart, sizeof(int) * (ruleCount + 1));
				ruleEnd = realloc(ruleEnd, sizeof(int) * (ruleCount + 1));
				numerator = realloc(numerator, sizeof(int) * (ruleCount + 1));
				denominator = realloc(denominator, sizeof(int) * (ruleCount + 1));
				ruleFound = realloc(ruleFound, sizeof(short) * (ruleCount + 1));

				ruleStart[ruleCount] = indexOne;
				ruleEnd[ruleCount] = indexTwo;
				numerator[ruleCount] = numberMatching;
				denominator[ruleCount] = count + count2;
				ruleFound[ruleCount] = 0;

				++ruleCount;
			}

		}
	}

	int rule = -1;
	int previousDenom;
	double next;

	int outputSize;
	if ( lengthOne > lengthTwo ) outputSize = lengthOne; else outputSize = lengthTwo;
	char output[outputSize];
	for (indexOne = 0; indexOne < outputSize; ++indexOne) output[indexOne] = '?';

	double threshold = 0.25;

	short foundEndRule[outputSize];
	for (indexOne = 0; indexOne < outputSize; ++indexOne) foundEndRule[indexOne] = 0;

	while(next != -1){

		next = -1;
		previousDenom = -1;

		for (indexOne = 0; indexOne < ruleCount; ++indexOne)
		{
			if ( ((double)numerator[indexOne] / (double)denominator[indexOne]) > threshold && ((double)numerator[indexOne] / (double)denominator[indexOne]) > next && ruleFound[indexOne] == 0)
			{
				next = (double)numerator[indexOne]/(double)denominator[indexOne];
				previousDenom = denominator[indexOne];
				rule = indexOne;

			}
		}

		ruleFound[rule] = 1;
		if (output[ruleStart[rule]] == '?' && foundEndRule[ruleEnd[rule]] == 0 && next > threshold)
		{
			output[ruleStart[rule]] = myStringTwo[ruleEnd[rule]];
			foundEndRule[ruleEnd[rule]] = 1;
		}
	}

for(indexOne = 0; indexOne < outputSize; ++indexOne)
if (output[indexOne] != '?') printf("%c",output[indexOne]);
printf("\n");

return 1;

}