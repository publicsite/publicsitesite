/*****************************************************************************
 * Copyright (C) 2013 J05HYYY
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
 *****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

struct comparison{
   float average;
   int row, column;
};

/* qsort struct comparision function (price float field) */ 
int average_cmp(const void *a, const void *b) 
{ 
    struct comparison *ia = (struct comparison *)a;
    struct comparison *ib = (struct comparison *)b;
    return (int)(100.f*ia->average - 100.f*ib->average);
	/* float comparison: returns negative if b > a 
	and positive if a > b. We multiplied result by 100.0
	to preserve decimal fraction */ 
}

int getBestRank(int **grid, int numOfRows, int numOfColumns)
{

/* START RANKING PROCESS */
/* Get average for each row and store distance from averages */
	long totalForRow[numOfRows];
	float averages[numOfRows];

	struct comparison structs[numOfRows*numOfColumns];

	int i = 0;
	for (a=0; a < numOfRows; ++a)
	{
		totalForRow[a] = 0;
		for (b=0; b < numOfColumns; ++b)
		{
			totalForRow[a] += grid[a][b];
		}
		averages[a] = (float)totalForRow[a] / numOfColumns;

		for (b=0; b < numOfColumns; ++b)
		{
			structs[i].average = averages[a] - (float)grid[a][b];
			structs[i].row = a;
			structs[i].column = b;
			++i;
		}
	}

	qsort(structs, numOfRows*numOfColumns, sizeof(struct comparison), average_cmp);

	int foundAlready;

	int foundRows[numOfRows];
	int foundColumns[numOfColumns];

	int numberFound = 0;

	int total = 0;

	for (a=(numOfRows*numOfColumns)-1; 0 <= a; --a)
		{
			foundAlready = 0;
			for (b=0; b < numberFound; ++b)
			{
				if (structs[a].row == foundRows[b] || structs[a].column == foundColumns[b])
				{
					foundAlready = 1;
					break;
				}
			}
			if (foundAlready == 0){
				total += grid[structs[a].row][structs[a].column];
				foundRows[numberFound] = structs[a].row;
				foundColumns[numberFound] = structs[a].column;
				++numberFound;
			}
			if ( numberFound == numOfRows ) break;
		}
return total;
}

int main ()
{
	int sizeOne = 50;
	int sizeTwo = 50;
srand(time(NULL)); /*seed the generator*/
	int arrayOne[sizeOne];
	int arrayTwo[sizeTwo];
int k;
for(k = 0; k < sizeOne; k++)
{
     arrayOne[k] = rand() % 10 + 1;
}
for(k = 0; k < sizeTwo; k++)
{
     arrayTwo[k] = rand() % 10 + 1;
}

	int **gridOne = malloc(sizeof(int*)*(sizeTwo));
	int **gridTwo = malloc(sizeof(int*)*(sizeTwo));
	int a, b, c, d, distanceTwo, differenceTwo, distanceOne, differenceOne, totalDistance, totalDifference, i, j;

	for (a=0; a < sizeTwo; ++a)
	{
		gridOne[a] = malloc(sizeof(int)*(sizeOne));
		gridTwo[a] = malloc(sizeof(int)*(sizeOne));
	}

		a=0; /* can get rid of this when below is no longer commented. */
		for (a=0; a < sizeOne; ++a)
		{
			printf("Working %d ...\n",a);
			fflush(stdout);
					for (c=0; c < sizeTwo; ++c)
					{
						i = 0;
						for (d=0; d<sizeTwo; ++d)
						{

							if (d != c)
							{
								distanceTwo = c-d;
								differenceTwo = arrayTwo[c]-arrayTwo[d];
								j=0;
										for (b=0; b < sizeOne; ++b)
										{
											if (b != a)
											{
												distanceOne = a - b;
												differenceOne = arrayOne[a] - arrayOne[b];

												if (distanceOne > distanceTwo) totalDistance = distanceOne - distanceTwo;
												else totalDistance = (distanceTwo - distanceOne)+1;

												if (differenceOne > differenceTwo) totalDifference = differenceOne - differenceTwo;
												else totalDifference = (differenceTwo - differenceOne)+1;

												gridOne[i][j] = totalDistance*totalDifference;
												++j;
											}
										}
								++i;
							}
						}
						gridTwo[a][c] = getBestRank(gridOne,sizeTwo-1,sizeOne-1);
					}
		}
int finalResult = getBestRank(gridTwo,sizeTwo,sizeOne) - sizeOne * (sizeTwo-1);
printf("Final Result = %d\n",finalResult);
	return finalResult;
}