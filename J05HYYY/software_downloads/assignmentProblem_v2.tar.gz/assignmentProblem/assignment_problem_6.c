/*****************************************************************************
 * Copyright (C) 2017 J05HYYY
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
 *****************************************************************************/

#include <stdlib.h>
#include <math.h>
#include <stdio.h>

int main(){
	double *arrayOne;
	double *arrayTwo;

	int arrayLengthOne=5;
	int arrayLengthTwo=10;

	int topLength;
if(arrayLengthOne > arrayLengthTwo) topLength = arrayLengthOne; else topLength = arrayLengthTwo;

	arrayOne = malloc(sizeof(double) * arrayLengthOne);
	arrayTwo = malloc(sizeof(double) * arrayLengthTwo);

printf("Input Arrays:\n\n");
	int a;
	for (a=0; a < arrayLengthOne; ++a)
	{
		arrayOne[a]=(double)(a*3);
		//arrayOne[a]=(double)12-(a*3);
printf("%f\n",arrayOne[a]);
	}
printf("\n");
	for (a=0; a < arrayLengthTwo; ++a)
	{
		//arrayTwo[a]=(double)pow(a,2);
		arrayTwo[a]=(double)a*2;
printf("%f\n",arrayTwo[a]);
	}
printf("\n");

	int *arrayOneIndex = malloc(sizeof(int) * topLength);
	int *arrayTwoIndex = malloc(sizeof(int) * topLength);

	for (a=0; a<arrayLengthTwo; ++a)
	{
			arrayTwoIndex[a] = a;
			//arrayTwo[a] = NULL;
	}

	for (a=arrayLengthTwo; a<arrayLengthOne; ++a)
	{
			arrayTwoIndex[a] = -1;
			//arrayTwo[a] = NULL;
	}


	for (a=0; a<arrayLengthOne; ++a)
	{
			arrayOneIndex[a] = a;
			//arrayTwo[a] = NULL;
	}

	for (a=arrayLengthOne; a<arrayLengthTwo; ++a)
	{
			arrayOneIndex[a] = -1;
			//arrayOne[a] = NULL;
	}


for (a = 0; a < topLength-1; a++) 
  {

if (arrayOneIndex[a] == -1) break;

    int iMin = a;
    int i;

    for (i = a+1; i < topLength; i++) {
	double alpha = 0;
	double bravo = 0;

	if (arrayOneIndex[i] != -1 && arrayTwoIndex[i] != -1 && arrayOneIndex[iMin] != -1 && arrayTwoIndex[iMin] != -1)
	{
//printf("%f %f %f %f\n",arrayOne[arrayOneIndex[i]], arrayTwo[arrayTwoIndex[i]], arrayOne[arrayOneIndex[iMin]], arrayTwo[arrayTwoIndex[iMin]]);
//printf("A\n");
//iimm
		alpha = sqrt(pow(arrayOne[arrayOneIndex[i]] - arrayTwo[arrayTwoIndex[i]],2));
		bravo = sqrt(pow(arrayOne[arrayOneIndex[i]] - arrayTwo[arrayTwoIndex[iMin]],2));
		alpha += sqrt(pow(arrayOne[arrayOneIndex[iMin]] - arrayTwo[arrayTwoIndex[iMin]],2));
		bravo += sqrt(pow(arrayOne[arrayOneIndex[iMin]] - arrayTwo[arrayTwoIndex[i]],2));

	}
	else if (arrayOneIndex[i] != -1 && arrayTwoIndex[i] != -1 && arrayTwoIndex[iMin] != -1)
	{
//printf("%f %f %s %f\n",arrayOne[arrayOneIndex[i]], arrayTwo[arrayTwoIndex[i]], "NULL", arrayTwo[arrayTwoIndex[iMin]]);
//printf("B\n");
//iiNm
		alpha = sqrt(pow(arrayOne[arrayOneIndex[i]] - arrayTwo[arrayTwoIndex[i]],2));
		bravo = sqrt(pow(arrayOne[arrayOneIndex[i]] - arrayTwo[arrayTwoIndex[iMin]],2));
	}
	else if (arrayTwoIndex[i] != -1 && arrayOneIndex[iMin] != -1 && arrayTwoIndex[iMin] != -1)
	{
//printf("%s %f %f %f\n","NULL", arrayTwo[arrayTwoIndex[i]], arrayOne[arrayOneIndex[iMin]], arrayTwo[arrayTwoIndex[iMin]]);
//printf("C\n");
//Nimm
		alpha = sqrt(pow(arrayOne[arrayOneIndex[iMin]] - arrayTwo[arrayTwoIndex[iMin]],2));
		bravo = sqrt(pow(arrayOne[arrayOneIndex[iMin]] - arrayTwo[arrayTwoIndex[i]],2));
	}
	else if (arrayOneIndex[i] != -1 && arrayOneIndex[iMin] != -1 && arrayTwoIndex[iMin] != -1)
	{
//printf("%f %s %f %f\n",arrayOne[arrayOneIndex[i]], "NULL", arrayOne[arrayOneIndex[iMin]], arrayTwo[arrayTwoIndex[iMin]]);
//printf("D\n");
//iNmm
		bravo = sqrt(pow(arrayOne[arrayOneIndex[i]] - arrayTwo[arrayTwoIndex[iMin]],2));
		alpha = sqrt(pow(arrayOne[arrayOneIndex[iMin]] - arrayTwo[arrayTwoIndex[iMin]],2));
	}
	else if (arrayOneIndex[i] != -1 && arrayTwoIndex[i] != -1 && arrayOneIndex[iMin] != -1)
	{
//printf("%f %f %f %s\n",arrayOne[arrayOneIndex[i]], arrayTwo[arrayTwoIndex[i]], arrayOne[arrayOneIndex[iMin]], "NULL");
//printf("E\n");
//iimN
		alpha = sqrt(pow(arrayOne[arrayOneIndex[i]] - arrayTwo[arrayTwoIndex[i]],2));
		bravo = sqrt(pow(arrayOne[arrayOneIndex[iMin]] - arrayTwo[arrayTwoIndex[i]],2));

	}
	else alpha = -1;

//printf("alpha=%f, bravo=%f\n", alpha, bravo);

        if (alpha >= bravo) {
            		iMin = i;
        }
    }

    if(iMin != a) 
    {
	/* swap */
	int temp = arrayOneIndex[iMin];
	arrayOneIndex[iMin] = arrayOneIndex[a];
	arrayOneIndex[a] = temp;
    }
}

printf("\nSolution:\n\n");

for (a=0; a < topLength; ++a){
	if (arrayOneIndex[a] != -1 && arrayTwoIndex[a] != -1)
	{
		printf("%f %f\n",arrayOne[arrayOneIndex[a]], arrayTwo[arrayTwoIndex[a]]);
	}

	else if (arrayOneIndex[a] != -1)
	{
		printf("%f NULL\n", arrayOne[arrayOneIndex[a]]);
	}
	else if (arrayTwoIndex[a] != -1)
	{
		printf("NULL %f\n", arrayTwo[arrayTwoIndex[a]]);
	}
	else
	{
		printf("NULL NULL\n");
	}

}

   if (arrayOneIndex) free(arrayOneIndex);
   if (arrayTwoIndex) free(arrayTwoIndex);
   if (arrayOne) free(arrayOne);
   if (arrayTwo) free(arrayTwo);

return 1;
}