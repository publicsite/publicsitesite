This is a solution to the assignment problem, I think it is optimal. It is based on the selection sort algorithm. It could probably be parallelised. It could also probably be
modified easily for the quadratic assignment problem.

There are two versions, you can pick which you think is best suited for your purposes.

Compile with:

gcc -g <program>.c -o assignmentProblem -lm

Both programs have been run through valgrind and tested ok.
______________________________________________________
v2 - fixed bug with selection sort algorithm.