/*****************************************************************************
 * Copyright (C) 2017 J05HYYY
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
 *****************************************************************************/

#include <stdlib.h>
#include <math.h>
#include <stdio.h>

int main(){
	double *arrayOne;
	double *arrayTwo;

	int arrayLengthOne=5;
	int arrayLengthTwo=10;

	arrayOne = malloc(sizeof(double) * arrayLengthOne);
	arrayTwo = malloc(sizeof(double) * arrayLengthTwo);

printf("Input arrays:\n\n");
	int a;
	for (a=0; a < arrayLengthOne; ++a)
	{
		arrayOne[a]=(double)(a*3);
		//arrayOne[a]=(double)12-(a*3); //
printf("%f\n",arrayOne[a]);
	}
printf("\n");
	for (a=0; a < arrayLengthTwo; ++a)
	{
		//arrayTwo[a]=(double)pow(a,2); //
		arrayTwo[a]=(double)a*2;
printf("%f\n",arrayTwo[a]);
	}
printf("\n");

int topLength, bottomLength;

if(arrayLengthOne > arrayLengthTwo)
{
topLength = arrayLengthOne;
bottomLength = arrayLengthTwo;
}
else
{
topLength = arrayLengthTwo;
bottomLength = arrayLengthOne;
}

	int *arrayIndex = malloc(sizeof(int) * topLength);

	for (a=0; a<bottomLength; ++a)
	{
			arrayIndex[a] = a;
	}

	for (a=bottomLength; a<topLength; ++a)
	{
			arrayIndex[a] = -1;
	}

for (a = 0; a < topLength-1; a++) 
  {

if (arrayIndex[a] == -1) break;

    int iMin = a;
    int i;

    for (i = a+1; i < topLength; i++) {

	double alpha = 0;
	double bravo = 0;

	if (arrayIndex[i] != -1 && arrayIndex[iMin] != -1)
	{
		alpha = sqrt(pow(arrayOne[arrayIndex[i]] - arrayTwo[i],2));
		alpha += sqrt(pow(arrayOne[arrayIndex[iMin]] - arrayTwo[iMin],2));
		bravo = sqrt(pow(arrayOne[arrayIndex[i]] - arrayTwo[iMin],2));
		bravo += sqrt(pow(arrayOne[arrayIndex[iMin]] - arrayTwo[i],2));

//printf("e1=%f e2=%f d=%f d2=%f ae=%f bd=%f\n", arrayOne[arrayIndex[iMin]], arrayOne[arrayIndex[i]], arrayTwo[iMin], arrayTwo[i], alpha, bravo);
	}
	else if (arrayIndex[i] != -1)
	{
		alpha = sqrt(pow(arrayOne[arrayIndex[i]] - arrayTwo[i],2));
		bravo = sqrt(pow(arrayOne[arrayIndex[i]] - arrayTwo[iMin],2));

//printf("e1=NULL e2=%f d1=%f d2=%f ae=%f bd=%f\n", arrayOne[arrayIndex[i]], arrayTwo[iMin], arrayTwo[i], alpha, bravo);
	}
	else if (arrayIndex[iMin] != -1)
	{
		alpha = sqrt(pow(arrayOne[arrayIndex[iMin]] - arrayTwo[iMin],2));
		bravo = sqrt(pow(arrayOne[arrayIndex[iMin]] - arrayTwo[i],2));

//printf("e=%f e2=NULL d=%f d2=%f ae=%f bd=%f\n", arrayOne[arrayIndex[iMin]], arrayTwo[iMin], arrayTwo[i], alpha, bravo);
	}
	else alpha = -1;

        if (alpha >= bravo) {
		//printf("swap!\n");
            		iMin = i;
        }
    }

    	if(iMin != a) 
    	{
		/* swap */
		int temp = arrayIndex[iMin];
		arrayIndex[iMin] = arrayIndex[a];
		arrayIndex[a] = temp;
    	}


}

printf("Solution:\n\n");

for (a=0; a < topLength; ++a){
	if (arrayIndex[a] != -1)
	{
		printf("%f %f\n",arrayOne[arrayIndex[a]], arrayTwo[a]);
	}
	else
	{
		printf("NULL %f\n", arrayTwo[a]);
	}
}

   if (arrayIndex) free(arrayIndex);
   if (arrayOne) free(arrayOne);
   if (arrayTwo) free(arrayTwo);

return 1;
}