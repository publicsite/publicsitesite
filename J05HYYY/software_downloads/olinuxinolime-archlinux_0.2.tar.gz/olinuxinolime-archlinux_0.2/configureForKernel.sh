#!/bin/sh

OLD_UMASK="$(umask)"
umask 0022

askForToolChainConfig(){
if [ -z "$1" ]; then #if hasn't already been specified.
echo "Please type a number or type the name of the toolchain configuration you'd like to use."
read selectedToolchainConfig
	if [ `expr $selectedToolchainConfig + 1 2> /dev/null` ]; then #if it's a numeric value
		eval selectedToolchainConfig="\$array$selectedToolchainConfig"
	fi
else
selectedToolchainConfig="$1"
fi

selectedToolchainConfigPath="samples/$selectedToolchainConfig/crosstool.config"

if [ ! -f "$selectedToolchainConfigPath" ]; then #if file exists
echo "Unrecognised toolchain configuration."
askForToolChainConfig $1
fi
}

configureForKernel(){
#$1 kernel path
#$2 toolchain configuration

if [ $# -lt 1 ]; then #if hasn't already been specified.
echo "No kernel sources specified."
exit
fi;

cd crosstool-ng*/samples/

#store in array
numOfTypes=0 # number of types of toolchain configuration.
for toolchainConfig in `ls -d */`
do
	length=`expr length $toolchainConfig`
	length=`expr $length - 1`
	toolchainConfig=`echo "$toolchainConfig" | cut -c -$length`
	eval array$numOfTypes="$toolchainConfig"
	if [ -z "$2" ]; then #if hasn't already been specified.
		eval echo "[$numOfTypes] \$array$numOfTypes"
	fi
	numOfTypes=`expr $numOfTypes + 1`
done

cd ..

askForToolChainConfig $2

echo "CT_KERNEL_LINUX_CUSTOM_LOCATION=\"$1\"" >> samples/$2/crosstool.config

./ct-ng $selectedToolchainConfig

cd ..
}

umask "${OLD_UMASK}"