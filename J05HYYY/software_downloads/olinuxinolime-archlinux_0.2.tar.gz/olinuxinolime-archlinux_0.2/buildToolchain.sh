#!/bin/sh

OLD_UMASK="$(umask)"
umask 0022

cd crosstool-ng*
./ct-ng build
cd ..

umask "${OLD_UMASK}"