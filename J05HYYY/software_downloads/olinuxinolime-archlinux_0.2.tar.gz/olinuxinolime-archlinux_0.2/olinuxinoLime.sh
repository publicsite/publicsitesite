#!/bin/sh

OLD_UMASK="$(umask)"
umask 0022

###GET MKIMAGE FOR BUILDING THE KERNEL###

sudo apt-get install uboot-mkimage

###BUILD THE TOOLCHAIN###

#get and configure crosstool-ng
. ./getCrossTool.sh

#set toolchain type
toolChainType="arm-olinuxinoLIME-linux-gnueabi"

#copy the i386 configuration into the samples directory
cp -r $toolChainType crosstool-ng-*/samples/

#get the linux kernel
git clone -b sunxi-3.4 https://github.com/linux-sunxi/linux-sunxi.git

#include
. ./configureForKernel.sh

#configure crosstool-ng for our sunxi kernel
configureForKernel "${PWD}/linux-sunxi" "$toolChainType"

#build our toolchain
. ./buildToolchain.sh

###BUILD UBOOT###

#get u-boot
git clone -b sunxi https://github.com/linux-sunxi/u-boot-sunxi.git

cd u-boot-sunxi

make CROSS_COMPILE=$HOME/x-tools/$toolChainType/bin/$toolChainType- A10-OLinuXino-Lime_config
make CROSS_COMPILE=$HOME/x-tools/$toolChainType/bin/$toolChainType-

cd ..

###BUILD THE KERNEL###

cp a10lime_defconfig linux-sunxi/arch/arm/configs/

cd linux-sunxi
make ARCH=arm CROSS_COMPILE=$HOME/x-tools/$toolChainType/bin/$toolChainType- a10lime_defconfig

##REMOVED, NO LONGER NEEDED##patch -p0 < ../sunxi-i2c.patch
##REMOVED, NO LONGER NEEDED##patch -p0 < ../a10_sound.patch

make  -j2 ARCH=arm CROSS_COMPILE=$HOME/x-tools/$toolChainType/bin/$toolChainType- uImage modules

make ARCH=arm CROSS_COMPILE=$HOME/x-tools/$toolChainType/bin/$toolChainType- INSTALL_MOD_PATH=out modules_install

cd ..

###BUILD SCRIPT.BIN###
wget https://raw.githubusercontent.com/linux-sunxi/sunxi-boards/master/sys_config/a10/a10-olinuxino-lime.fex
git clone git://github.com/linux-sunxi/sunxi-tools.git
cd sunxi-tools
make fex2bin
cd..
sunxi-tools/fex2bin a10-olinuxino-lime.fex script.bin

###MAKE BOOT.SCR###
mkimage -C none -A arm -T script -d boot.cmd boot.scr


###GET ARCH LINUX ARM ROOTFS###

wget http://archlinuxarm.org/os/ArchLinuxARM-sun4i-latest.tar.gz

umask "${OLD_UMASK}"
