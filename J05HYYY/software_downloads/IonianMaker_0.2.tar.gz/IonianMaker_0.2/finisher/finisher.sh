#!/bin/sh

unset DEBCONF_REDIR
unset DEBCONF_FRONTEND
unset DEBIAN_HAS_FRONTEND
unset DEBIAN_FRONTEND

mount /dev/cdrom

#Make a new local repository from the cdrom
#cd /media/cdrom/finisher/var/cache/apt/archives
#dpkg-scanpackages ./ /dev/null |gzip > /var/cache/apt/archives/Packages.gz
#Backup a copy of sources.list
cp /etc/apt/sources.list /etc/apt/sourcescopy.list
#And delete the old one
rm /etc/apt/sources.list
# Make new sources.list with local repository
echo "deb file:/media/cdrom/finisher/var/cache/apt/archives/ ./" >> /etc/apt/sources.list
#And update
apt-get update

#install all programs
 
#install the rest
apt-get install xorg --no-install-recommends -y --allow-unauthenticated
apt-get install openbox --no-install-recommends -y --allow-unauthenticated
apt-get install obconf --no-install-recommends -y --allow-unauthenticated
apt-get install gnome-menus --no-install-recommends -y --allow-unauthenticated
apt-get install pcmanfm --no-install-recommends -y --allow-unauthenticated
apt-get install wmbattery --no-install-recommends -y --allow-unauthenticated #would be nice to have a cross-platform battery applet
apt-get install leafpad --no-install-recommends -y --allow-unauthenticated
apt-get install vlc --no-install-recommends -y --allow-unauthenticated
apt-get install vlc-plugin-pulse --no-install-recommends -y --allow-unauthenticated
apt-get install libreoffice-gtk3 --no-install-recommends -y --allow-unauthenticated
apt-get install xdm --no-install-recommends -y --allow-unauthenticated
apt-get install htop --no-install-recommends -y --allow-unauthenticated #would be nice to have a cross-platform gtk equivilent
apt-get install linphone --no-install-recommends -y --allow-unauthenticated
apt-get install gnome-paint --no-install-recommends -y --allow-unauthenticated #would be nice if all features were implemented
apt-get install isomaster --no-install-recommends -y --allow-unauthenticated
apt-get install gparted --no-install-recommends -y --allow-unauthenticated
apt-get install evince-gtk --no-install-recommends -y --allow-unauthenticated
apt-get install roxterm-gtk3 --no-install-recommends -y --allow-unauthenticated
apt-get install python-xdg --no-install-recommends -y --allow-unauthenticated
apt-get install pulseaudio -y --allow-unauthenticated
apt-get install libao4 -y --allow-unauthenticated
apt-get install paprefs -y --allow-unauthenticated
apt-get install libpulse-mainloop-glib0 -y --allow-unauthenticated
apt-get install pulseaudio-module-jack -y --allow-unauthenticated
apt-get install pavucontrol -y --allow-unauthenticated
apt-get install pulseaudio-module-hal -y --allow-unauthenticated
apt-get install pulseaudio-module-x11 -y --allow-unauthenticated
apt-get install gstreamer0.10-pulseaudio -y --allow-unauthenticated
apt-get install pulseaudio-utils -y --allow-unauthenticated
apt-get install libasound2-plugins -y --allow-unauthenticated
apt-get install paman -y --allow-unauthenticated
apt-get install pulseaudio-module-gconf -y --allow-unauthenticated
apt-get install libgconfmm-2.6-1c2 -y --allow-unauthenticated
apt-get install libpulse-browse0 -y --allow-unauthenticated
apt-get install pavumeter -y --allow-unauthenticated
apt-get install libglademm-2.4-1c2a -y --allow-unauthenticated
apt-get install pulseaudio-esound-compat -y --allow-unauthenticated
apt-get install libpulse0 -y --allow-unauthenticated
apt-get install libpulse-dev -y --allow-unauthenticated
apt-get install pulseaudio-module-bluetooth -y --allow-unauthenticated
apt-get install pulseaudio-module-zeroconf -y --allow-unauthenticated
apt-get install padevchooser -y --allow-unauthenticated
apt-get install gksu -y --allow-unauthenticated
apt-get install wicd -y --allow-unauthenticated
apt-get install gnome-brave-icon-theme --no-install-recommends -y --allow-unauthenticated
apt-get install grandr --no-install-recommends -y --allow-unauthenticated
apt-get install gvfs -y --allow-unauthenticated
apt-get install gvfs-fuse -y --allow-unauthenticated
apt-get install policykit-1 -y --allow-unauthenticated
apt-get install policykit-1-gnome -y --allow-unauthenticated
apt-get install xarchiver -y --allow-unauthenticated
apt-get install mirage --no-install-recommends -y --allow-unauthenticated
apt-get install transmission --no-install-recommends -y --allow-unauthenticated
apt-get install galculator --no-install-recommends -y --allow-unauthenticated
apt-get install default-jre --no-install-recommends -y --allow-unauthenticated
apt-get install feh myspell-en-gb --no-install-recommends -y --allow-unauthenticated
apt-get install gnash --no-install-recommends -y --allow-unauthenticated
apt-get install chromium-browser --no-install-recommends -y --allow-unauthenticated
apt-get install audacity --no-install-recommends -y --allow-unauthenticated
apt-get install gimp --no-install-recommends -y --allow-unauthenticated
apt-get install xchat --no-install-recommends -y --allow-unauthenticated
apt-get install gftp --no-install-recommends -y --allow-unauthenticated
apt-get install gtk-gnutella --no-install-recommends -y --allow-unauthenticated
apt-get install wine --no-install-recommends -y --allow-unauthenticated
apt-get install fbpanel --no-install-recommends -y --allow-unauthenticated
apt-get install icedove --no-install-recommends -y --allow-unauthenticated
apt-get install enigmail --no-install-recommends -y --allow-unauthenticated
apt-get install streamtuner2 --no-install-recommends -y --allow-unauthenticated
#additions, version 0.1
apt-get install gnunet-gtk --no-install-recommends -y --allow-unauthenticated
apt-get install blueman --no-install-recommends -y --allow-unauthenticated
apt-get install dosfstools --no-install-recommends -y --allow-unauthenticated
#additions, version 0.2
apt-get install clipit --no-install-recommends -y --allow-unauthenticated
apt-get install get-flash-videos --no-install-recommends -y --allow-unauthenticated
#additions to come 
#apt-get install vlc-plugin-pulse --no-install-recommends -y --allow-unauthenticated

DEBIAN_FRONTEND=noninteractive apt-get install wicd -y --allow-unauthenticated

#missing: A cross-platform gtk soulseek client and a gtk cd burner, both written in C

#Edit for portaudio
echo "pcm.!default plug:pulse" >> /etc/asound.conf
echo "pcm.pulse {" >> /etc/asound.conf
echo "    type pulse" >> /etc/asound.conf
echo "}" >> /etc/asound.conf
echo "" >> /etc/asound.conf
echo "ctl.pulse {" >> /etc/asound.conf
echo "    type pulse" >> /etc/asound.conf
echo "}" >> /etc/asound.conf
echo "" >> /etc/asound.conf
echo "pcm.!default {" >> /etc/asound.conf
echo "    type pulse" >> /etc/asound.conf
echo "}" >> /etc/asound.conf
echo "" >> /etc/asound.conf
echo "ctl.!default {" >> /etc/asound.conf
echo "    type pulse" >> /etc/asound.conf
echo "}" >> /etc/asound.conf

rm /etc/X11/xdm/Xresources
cp /media/cdrom/finisher/xdm/Xresources /etc/X11/xdm/Xresources

mkdir -p /usr/share/X11/xdm/pixmaps
cp /media/cdrom/finisher/xdm/bubbles.xpm /usr/share/X11/xdm/pixmaps/bubbles.xpm

#make some symbolic links for xdg-menus
ln -s /etc/xdg/menus/gnome-applications.menu /etc/xdg/menus/applications.menu
ln -s /etc/xdg/menus/gnome-preferences.menu /etc/xdg/menus/preferences.menu
ln -s /etc/xdg/menus/gnome-settings.menu /etc/xdg/menus/settings.menu

installToHome(){

pwd=$1
username=$2

echo 'gtk-icon-theme-name="gnome-brave"' >> $pwd/$username/.gtkrc-2.0
mkdir -p $pwd/$username/.config/gtk-3.0
echo 'gtk-icon-theme-name="gnome-brave"' >> $pwd/$username/.config/gtk-3.0/settings.ini

#copy wallpaper
cp /media/cdrom/finisher/wallpaper.jpg $pwd/$username/wallpaper.jpg

#load settings for programs
if [ ! -d "$pwd/$username/.config" ]; then
	mkdir $pwd/$username/.config
	if [ "$username" != "root" ]; then
		chown $username:$username $pwd/$username/.config
	fi
fi
if [ ! -d "$pwd/$username/.config/fbpanel" ]; then
	mkdir $pwd/$username/.config/fbpanel
	if [ "$username" != "root" ]; then
		chown $username:$username $pwd/$username/.config/fbpanel
	fi
fi
if [ ! -d "$pwd/$username/.config/pcmanfm" ]; then
	mkdir $pwd/$username/.config/pcmanfm
	if [ "$username" != "root" ]; then
		chown $username:$username $pwd/$username/.config/pcmanfm
	fi
fi
if [ ! -d "$pwd/$username/.config/openbox" ]; then
    mkdir $pwd/$username/.config/openbox
	if [ "$username" != "root" ]; then
		chown $username:$username $pwd/$username/.config/openbox
	fi
fi

cp /media/cdrom/finisher/openbox/rc.xml $pwd/$username/.config/openbox/rc.xml
cp /media/cdrom/finisher/fbpanel/default $pwd/$username/.config/fbpanel/default
cp /media/cdrom/finisher/pcmanfm/pcmanfm.conf $pwd/$username/.config/pcmanfm/pcmanfm.conf

if [ "$username" != "root" ]; then
	chown $username:$username $pwd/$username/.config/openbox/rc.xml
	chown $username:$username $pwd/$username/.config/fbpanel/default
	chown $username:$username $pwd/$username/.config/pcmanfm/pcmanfm.conf
fi

if [ ! -d "$pwd/$username/.local" ]; then
	mkdir $pwd/$username/.local
	if [ "$username" != "root" ]; then
		chown $username:$username $pwd/$username/.local
	fi
fi
if [ ! -d "$pwd/$username/.local/share" ]; then
	mkdir $pwd/$username/.local/share
	if [ "$username" != "root" ]; then
		chown $username:$username $pwd/$username/.local/share
	fi
fi
if [ ! -d "$pwd/$username/.local/share/applications" ]; then
	mkdir $pwd/$username/.local/share/applications
	if [ "$username" != "root" ]; then
		chown $username:$username $pwd/$username/.local/share/applications
	fi
fi
        cp /media/cdrom/finisher/pcmanfm/mimeapps.list $pwd/$username/.local/share/applications/mimeapps.list
	if [ "$username" != "root" ]; then
		chown $username:$username $pwd/$username/.local/share/applications/mimeapps.list
	fi

# .icedove/*.default directory does not exist yet, so this has been removed.
#cd $pwd/$username/.icedove/*.default
#cp /media/cdrom/finisher/icedove/mimeTypes.rdf $pwd/$username/mimeTypes.rdf
#chown $username:$username $pwd/$username/mimeTypes.rdf
#cd $pwd/$username

# configure vlc to use pulseaudio #for use in the next version.
#mkdir $pwd/$username/.config/vlc
#echo "" >> $pwd/$username/.config/vlc/vlcrc
#echo "[main] # main program" >> $pwd/$username/.config/vlc/vlcrc
#echo "" >> $pwd/$username/.config/vlc/vlcrc
#echo "# Audio output module (string)" >> $pwd/$username/.config/vlc/vlcrc
#echo "aout=pulse" >> $pwd/$username/.config/vlc/vlcrc

chmod -R 777 $pwd/$username/.config

#Add user to XAUTHORITY so that root can run programs
echo "export XAUTHORITY=/home/$username/.Xauthority" >> /root/.bashrc

ln -s /etc/asound.conf $pwd/$username/.asoundrc

if [ "$username" != "root" ]; then
#Make Desktop Folder
mkdir $pwd/$username/Desktop
chmod -R 777 $pwd/$username/Desktop

#Add user to netdev group
usermod -a -G netdev $username
fi

#Create .xinitrc
sudo echo '#!/usr/bin/env bash' > $pwd/$username/.xinitrc
sudo echo '' >> $pwd/$username/.xinitrc
sudo echo '# test for an existing bus daemon, just to be safe' >> $pwd/$username/.xinitrc
sudo echo 'if test -z "$DBUS_SESSION_BUS_ADDRESS" ; then' >> $pwd/$username/.xinitrc
sudo echo '## if not found, launch a new one' >> $pwd/$username/.xinitrc
sudo echo "eval 'dbus-launch --sh-syntax --exit-with-session'" >> $pwd/$username/.xinitrc
sudo echo 'echo "D-Bus per-session daemon address is: $DBUS_SESSION_BUS_ADDRESS"' >> $pwd/$username/.xinitrc
sudo echo 'fi' >> $pwd/$username/.xinitrc
sudo echo '/usr/lib/policykit-1-gnome/polkit-gnome-authentication-agent-1 &' >> $pwd/$username/.xinitrc
sudo echo '' >> $pwd/$username/.xinitrc
sudo echo 'export wallpapermode=`grep "wallpaper_mode" ~/.config/pcmanfm/pcmanfm.conf`' >> $pwd/$username/.xinitrc
sudo echo 'if [ "$wallpapermode" == "wallpaper_mode=0" ]; then' >> $pwd/$username/.xinitrc
sudo echo '	export wallpaperR=`grep "desktop_bg" ~/.config/pcmanfm/pcmanfm.conf | cut -c 13-14`' >> $pwd/$username/.xinitrc
sudo echo '	export wallpaperG=`grep "desktop_bg" ~/.config/pcmanfm/pcmanfm.conf | cut -c 15-16`' >> $pwd/$username/.xinitrc
sudo echo '	export wallpaperB=`grep "desktop_bg" ~/.config/pcmanfm/pcmanfm.conf | cut -c 17-18`' >> $pwd/$username/.xinitrc
sudo echo '	bsetbg -solid rgb:$wallpaperR/$wallpaperG/$wallpaperB' >> $pwd/$username/.xinitrc
sudo echo 'elif [ "$wallpapermode" == "wallpaper_mode=1" ]; then' >> $pwd/$username/.xinitrc
sudo echo '	export wallpaper=`grep "wallpaper=" ~/.config/pcmanfm/pcmanfm.conf | cut -c 11-`' >> $pwd/$username/.xinitrc
sudo echo '	feh --bg-scale $wallpaper' >> $pwd/$username/.xinitrc
sudo echo 'elif [ "$wallpapermode" == "wallpaper_mode=2" ]; then' >> $pwd/$username/.xinitrc
sudo echo '#no mode for this in feh so setting the background color is the best alternative' >> $pwd/$username/.xinitrc
sudo echo '	export wallpaperR=`grep "desktop_bg" ~/.config/pcmanfm/pcmanfm.conf | cut -c 13-14`' >> $pwd/$username/.xinitrc
sudo echo '	export wallpaperG=`grep "desktop_bg" ~/.config/pcmanfm/pcmanfm.conf | cut -c 15-16`' >> $pwd/$username/.xinitrc
sudo echo '	export wallpaperB=`grep "desktop_bg" ~/.config/pcmanfm/pcmanfm.conf | cut -c 17-18`' >> $pwd/$username/.xinitrc
sudo echo '	bsetbg -solid rgb:$wallpaperR/$wallpaperG/$wallpaperB' >> $pwd/$username/.xinitrc
sudo echo 'elif [ "$wallpapermode" == "wallpaper_mode=3" ]; then' >> $pwd/$username/.xinitrc
sudo echo '	export wallpaper=`grep "wallpaper=" ~/.config/pcmanfm/pcmanfm.conf | cut -c 11-`' >> $pwd/$username/.xinitrc
sudo echo '	feh --bg-center $wallpaper' >> $pwd/$username/.xinitrc
sudo echo 'elif [ "$wallpapermode" == "wallpaper_mode=4" ]; then' >> $pwd/$username/.xinitrc
sudo echo '	export wallpaper=`grep "wallpaper=" ~/.config/pcmanfm/pcmanfm.conf | cut -c 11-`' >> $pwd/$username/.xinitrc
sudo echo '	feh --bg-tile $wallpaper' >> $pwd/$username/.xinitrc
sudo echo 'fi' >> $pwd/$username/.xinitrc
sudo echo 'pcmanfm --desktop &' >> $pwd/$username/.xinitrc
sudo echo 'pulseaudio -D &' >> $pwd/$username/.xinitrc
sudo echo 'padevchooser &' >> $pwd/$username/.xinitrc
sudo echo 'wicd-client --tray &' >> $pwd/$username/.xinitrc
sudo echo 'wmbattery -w &' >> $pwd/$username/.xinitrc
sudo echo 'fbpanel &' >> $pwd/$username/.xinitrc
sudo echo 'clipit &' >> $pwd/$username/.xinitrc
sudo echo 'exec openbox' >> $pwd/$username/.xinitrc

ln -s $pwd/$username/.xinitrc $pwd/$username/.xsession
chmod +x $pwd/$username/.xsession
chown $username:$username $pwd/$username/.xinitrc
chown $username:$username $pwd/$username/.xsession

}

cd /home/*
pwdlength=`expr length $PWD`
username=`echo "$PWD" | cut -c 7-$pwdlength`
pwd="/home"

installToHome $pwd $username

pwd=""
username="root"

installToHome $pwd $username

#######
#Delete the new sources.list that we made earlier in the finisher.sh script
rm /etc/apt/sources.list
#Renew the backed up copy of sources.list
cp /etc/apt/sourcescopy.list /etc/apt/sources.list
#And delete the backup
rm /etc/apt/sourcescopy.list

apt-get clean
apt-get update

umount /dev/cdrom
